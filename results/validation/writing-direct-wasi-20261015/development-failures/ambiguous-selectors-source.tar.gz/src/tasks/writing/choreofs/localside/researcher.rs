//! The four literal protocol lifetimes are visible here. No phase variable.
use super::super::global::*;
use crate::{shell::{ShellError, ShellResult, imp::service::{Domain, File, Validation}}, tasks::writing::global::SectionMessages};
use hibana::Endpoint;
use hibana_wasip1_runtime::protocol;
use serde_json::json;

/// Original task input, not protocol progress or an authorization table.
pub(crate) struct Assignment {
    pub agent: &'static str,
    pub topic: &'static str,
    pub section: &'static str,
    pub sections: [&'static str; 2],
}

pub(crate) async fn run<const ROLE: u8, F: SectionMessages, S: SectionMessages, D: Domain>(
    endpoint: &mut Endpoint<'_, ROLE>,
    domain: &D,
    validation: &Validation,
    assignment: &Assignment,
) -> ShellResult<()> {

    // read_literature: the Endpoint admits this lifetime, including reconsideration.
    let mut file = File::new(b"service/read_literature", SERVICE_FD);
    loop {
        endpoint.send::<ReadRequest>(&()).await?;
        endpoint.send::<RequestReady>(&()).await?;
        let branch = endpoint.offer().await?;
        match branch.label() {
            100 => {
                let request = branch.recv::<Open>().await?;
                endpoint.send::<Opened>(&file.open(request)).await?;
            }
            102 => {
                let request = branch.recv::<Write>().await?;
                endpoint.send::<Written>(&file.write(request)).await?;
            }
            104 => {
                let request = branch.recv::<Commit>().await?;
                validation.record(file.arguments(request.0, "topic").and_then(|arguments| {
                    if arguments["topic"] == assignment.topic {
                        Ok(arguments)
                    } else {
                        Err(ShellError::message("arguments name a different task object"))
                    }
                }));
                let decision = endpoint.offer().await?;
                match decision.label() {
                    111 => {
                        decision.recv::<Validate>().await?;
                        endpoint.send::<Admitted>(&()).await?;
                        break;
                    }
                    106 => {
                        let bytes = serde_json::to_vec(&json!({"status":"invalid_arguments", "error":validation.rejection()?}))
                            .map_err(|error| ShellError::message(error.to_string()))?;
                        decision.send::<Rejected<'_>>(&bytes.as_slice()).await?;
                    }
                    _ => return Err(ShellError::message("unexpected validation branch")),
                }
            }
            _ => return Err(ShellError::message("unexpected read_literature request")),
        }
    }
    endpoint.send::<ReadEffect>(&()).await?;
    let result = domain.execute(assignment.agent, "read_literature", validation.take()?).await.map_err(ShellError::message)?;
    if result["success"] != true {
        return Err(ShellError::message(format!("domain read_literature failed: {result}")));
    }
    let bytes = serde_json::to_vec(&result).map_err(|error| ShellError::message(error.to_string()))?;
    endpoint.send::<Completed<'_>>(&bytes.as_slice()).await?;
    endpoint.send::<ServiceDone>(&()).await?;

    // draft_content: the Endpoint admits this lifetime, including reconsideration.
    let mut file = File::new(b"service/draft_content", SERVICE_FD);
    loop {
        endpoint.send::<DraftRequest>(&()).await?;
        endpoint.send::<RequestReady>(&()).await?;
        let branch = endpoint.offer().await?;
        match branch.label() {
            100 => {
                let request = branch.recv::<Open>().await?;
                endpoint.send::<Opened>(&file.open(request)).await?;
            }
            102 => {
                let request = branch.recv::<Write>().await?;
                endpoint.send::<Written>(&file.write(request)).await?;
            }
            104 => {
                let request = branch.recv::<Commit>().await?;
                validation.record(file.arguments(request.0, "section_name").and_then(|arguments| {
                    if arguments["section_name"] == assignment.section {
                        Ok(arguments)
                    } else {
                        Err(ShellError::message("arguments name a different task object"))
                    }
                }));
                let decision = endpoint.offer().await?;
                match decision.label() {
                    111 => {
                        decision.recv::<Validate>().await?;
                        endpoint.send::<Admitted>(&()).await?;
                        break;
                    }
                    106 => {
                        let bytes = serde_json::to_vec(&json!({"status":"invalid_arguments", "error":validation.rejection()?}))
                            .map_err(|error| ShellError::message(error.to_string()))?;
                        decision.send::<Rejected<'_>>(&bytes.as_slice()).await?;
                    }
                    _ => return Err(ShellError::message("unexpected validation branch")),
                }
            }
            _ => return Err(ShellError::message("unexpected draft_content request")),
        }
    }
    endpoint.send::<DraftEffect>(&()).await?;
    let result = domain.execute(assignment.agent, "draft_content", validation.take()?).await.map_err(ShellError::message)?;
    if result["success"] != true {
        return Err(ShellError::message(format!("domain draft_content failed: {result}")));
    }
    let bytes = serde_json::to_vec(&result).map_err(|error| ShellError::message(error.to_string()))?;
    endpoint.send::<Completed<'_>>(&bytes.as_slice()).await?;
    endpoint.send::<ServiceDone>(&()).await?;

    // write_to_document: the Endpoint admits this lifetime, including reconsideration.
    let mut file = File::new(b"service/write_to_document", SERVICE_FD);
    loop {
        endpoint.send::<WriteRequest>(&()).await?;
        endpoint.send::<RequestReady>(&()).await?;
        let branch = endpoint.offer().await?;
        match branch.label() {
            100 => {
                let request = branch.recv::<Open>().await?;
                endpoint.send::<Opened>(&file.open(request)).await?;
            }
            102 => {
                let request = branch.recv::<Write>().await?;
                endpoint.send::<Written>(&file.write(request)).await?;
            }
            104 => {
                let request = branch.recv::<Commit>().await?;
                validation.record(file.arguments(request.0, "sections").and_then(|arguments| {
                    if {
                        let actual: std::collections::BTreeSet<_> = arguments["sections"].as_str().unwrap().split(',').map(str::trim).collect();
                        actual == assignment.sections.into_iter().collect()
                    } {
                        Ok(arguments)
                    } else {
                        Err(ShellError::message("arguments name a different task object"))
                    }
                }));
                let decision = endpoint.offer().await?;
                match decision.label() {
                    111 => {
                        decision.recv::<Validate>().await?;
                        endpoint.send::<Admitted>(&()).await?;
                        break;
                    }
                    106 => {
                        let bytes = serde_json::to_vec(&json!({"status":"invalid_arguments", "error":validation.rejection()?}))
                            .map_err(|error| ShellError::message(error.to_string()))?;
                        decision.send::<Rejected<'_>>(&bytes.as_slice()).await?;
                    }
                    _ => return Err(ShellError::message("unexpected validation branch")),
                }
            }
            _ => return Err(ShellError::message("unexpected write_to_document request")),
        }
    }
    endpoint.recv::<F::Available>().await?;
    endpoint.send::<F::Acquire>(&()).await?;
    endpoint.recv::<F::Granted>().await?;
    endpoint.recv::<S::Available>().await?;
    endpoint.send::<S::Acquire>(&()).await?;
    endpoint.recv::<S::Granted>().await?;
    endpoint.send::<WriteEffect>(&()).await?;
    let result = domain.execute(assignment.agent, "write_to_document", validation.take()?).await.map_err(ShellError::message)?;
    if result["success"] != true {
        return Err(ShellError::message(format!("domain write_to_document failed: {result}")));
    }
    endpoint.send::<S::Return>(&()).await?;
    endpoint.send::<F::Return>(&()).await?;
    endpoint.recv::<S::Returned>().await?;
    endpoint.recv::<F::Returned>().await?;
    let bytes = serde_json::to_vec(&result).map_err(|error| ShellError::message(error.to_string()))?;
    endpoint.send::<Completed<'_>>(&bytes.as_slice()).await?;
    endpoint.send::<ServiceDone>(&()).await?;

    // review_own_work: the Endpoint admits this lifetime, including reconsideration.
    let mut file = File::new(b"service/review_own_work", SERVICE_FD);
    loop {
        endpoint.send::<ReviewRequest>(&()).await?;
        endpoint.send::<RequestReady>(&()).await?;
        let branch = endpoint.offer().await?;
        match branch.label() {
            100 => {
                let request = branch.recv::<Open>().await?;
                endpoint.send::<Opened>(&file.open(request)).await?;
            }
            102 => {
                let request = branch.recv::<Write>().await?;
                endpoint.send::<Written>(&file.write(request)).await?;
            }
            104 => {
                let request = branch.recv::<Commit>().await?;
                validation.record(file.arguments(request.0, "section_name").and_then(|arguments| {
                    if arguments["section_name"] == assignment.section {
                        Ok(arguments)
                    } else {
                        Err(ShellError::message("arguments name a different task object"))
                    }
                }));
                let decision = endpoint.offer().await?;
                match decision.label() {
                    111 => {
                        decision.recv::<Validate>().await?;
                        endpoint.send::<Admitted>(&()).await?;
                        break;
                    }
                    106 => {
                        let bytes = serde_json::to_vec(&json!({"status":"invalid_arguments", "error":validation.rejection()?}))
                            .map_err(|error| ShellError::message(error.to_string()))?;
                        decision.send::<Rejected<'_>>(&bytes.as_slice()).await?;
                    }
                    _ => return Err(ShellError::message("unexpected validation branch")),
                }
            }
            _ => return Err(ShellError::message("unexpected review_own_work request")),
        }
    }
    endpoint.send::<ReviewEffect>(&()).await?;
    let result = domain.execute(assignment.agent, "review_own_work", validation.take()?).await.map_err(ShellError::message)?;
    let bytes = serde_json::to_vec(&result).map_err(|error| ShellError::message(error.to_string()))?;
    endpoint.send::<Completed<'_>>(&bytes.as_slice()).await?;
    endpoint.send::<ServiceDone>(&()).await?;

    // Review is terminal even when its domain verdict is false.
    loop {
        endpoint.send::<RejectRequest>(&()).await?;
        endpoint.send::<RequestReady>(&()).await?;
        let branch = endpoint.offer().await?;
        match branch.label() {
            100 => {
                branch.recv::<Open>().await?;
                endpoint.send::<Opened>(&protocol::PathOpenedRet(protocol::PathOpened::new(0, 8))).await?;
            }
            102 => {
                let request = branch.recv::<Write>().await?;
                endpoint.send::<Written>(&protocol::FdWriteDoneRet(protocol::FdWriteDone::new_with_errno(request.0.fd(), 0, 8))).await?;
            }
            104 => {
                let request = branch.recv::<Commit>().await?;
                endpoint.send::<Unavailable>(&protocol::FdClosedRet(protocol::FdClosed::new_with_errno(request.0.fd(), 8))).await?;
            }
            241 => {
                let status = branch.recv::<ServiceExit>().await?;
                if status != 0 { return Err(ShellError::message("researcher guest failed")); }
                return Ok(());
            }
            _ => return Err(ShellError::message("unexpected completed-service request")),
        }
    }
}

