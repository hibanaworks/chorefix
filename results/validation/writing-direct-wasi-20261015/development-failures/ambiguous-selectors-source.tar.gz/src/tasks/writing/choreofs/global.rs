//! Actual WASI requests, task effects and physical sections share one global.
//! Service loops accept ordinary I/O errors without a second task state machine.
use hibana::{g, runtime::program::{Projectable, RoleProgram, project}};
use hibana_wasip1_runtime::protocol;
use super::super::global::{SectionMessages, Intro, Background, Related, Methods, Experiments, Results, Discussion};

pub const SERVICE_FD: u8 = 4;
pub const SERVICE_PREFIX: &[u8] = b"service/";
pub const RESULT_PATH: &[u8] = b"service/result";
pub const CHECK: u16 = 280;
pub type Open = g::Msg<100, protocol::PathOpenReq>;
pub type Opened = g::Msg<101, protocol::PathOpenedRet>;
pub type Write = g::Msg<102, protocol::FdWriteReq>;
pub type Written = g::Msg<103, protocol::FdWriteDoneRet>;
pub type Commit = g::Msg<104, protocol::FdCloseReq>;
pub type Admitted = g::Msg<105, ()>;
pub type Rejected<'a> = g::Msg<106, &'a [u8]>;
pub type Completed<'a> = g::Msg<107, &'a [u8]>;
pub type ServiceDone = g::Msg<108, ()>;
pub type Unavailable = g::Msg<109, protocol::FdClosedRet>;
pub type RequestReady = g::Msg<110, ()>;
pub type Validate = g::Msg<111, ()>;
pub type ReadRequest = g::Msg<112, ()>;
pub type DraftRequest = g::Msg<113, ()>;
pub type WriteRequest = g::Msg<114, ()>;
pub type ReviewRequest = g::Msg<115, ()>;
pub type RejectRequest = g::Msg<116, ()>;
pub type ReadEffect = g::Msg<117, ()>;
pub type DraftEffect = g::Msg<118, ()>;
pub type WriteEffect = g::Msg<119, ()>;
pub type ReviewEffect = g::Msg<120, ()>;
pub type ServiceExit = g::Msg<241, i32>;

// START makes the four distinct request lifetimes explicit at their owner.
// This fragment validates bytes, never executes the task or chooses its phase.
fn requests<const VM: u8, const OWNER: u8, START: g::Message<Payload = ()>>() -> impl Projectable {
    g::seq(g::send::<OWNER, OWNER, START>(),
        g::seq(g::send::<OWNER, VM, RequestReady>(),
            g::route(
                g::seq(g::send::<VM, OWNER, Open>(), g::send::<OWNER, VM, Opened>()),
                g::route(
                    g::seq(g::send::<VM, OWNER, Write>(), g::send::<OWNER, VM, Written>()),
                    g::seq(g::send::<VM, OWNER, Commit>(),
                        g::route(
                            g::seq(g::send::<OWNER, OWNER, Validate>(), g::send::<OWNER, VM, Admitted>()),
                            g::send::<OWNER, VM, Rejected<'static>>()
                        ).resolve::<CHECK>())
                )
            )
        )
    ).roll()
}
fn closed<const VM: u8, const OWNER: u8>() -> impl Projectable {
    g::seq(g::send::<OWNER, OWNER, RejectRequest>(),
        g::seq(g::send::<OWNER, VM, RequestReady>(),
            g::route(
                g::seq(g::send::<VM, OWNER, Open>(), g::send::<OWNER, VM, Opened>()),
                g::route(
                    g::seq(g::send::<VM, OWNER, Write>(), g::send::<OWNER, VM, Written>()),
                    g::route(
                        g::seq(g::send::<VM, OWNER, Commit>(), g::send::<OWNER, VM, Unavailable>()),
                        g::send::<VM, OWNER, ServiceExit>()
                    )
                )
            )
        )
    ).roll()
}
fn prepare<const VM: u8, const OWNER: u8>() -> impl Projectable {
    let read = g::seq(requests::<VM, OWNER, ReadRequest>(),
        g::seq(g::send::<OWNER, OWNER, ReadEffect>(),
            g::seq(g::send::<OWNER, VM, Completed<'static>>(), g::send::<OWNER, VM, ServiceDone>())));
    let draft = g::seq(requests::<VM, OWNER, DraftRequest>(),
        g::seq(g::send::<OWNER, OWNER, DraftEffect>(),
            g::seq(g::send::<OWNER, VM, Completed<'static>>(), g::send::<OWNER, VM, ServiceDone>())));
    g::seq(read, draft)
}
fn write<const VM: u8, const OWNER: u8, const FIRST: u8, const SECOND: u8, F: SectionMessages, S: SectionMessages>() -> impl Projectable {
    let preparation = g::seq(prepare::<VM, OWNER>(), requests::<VM, OWNER, WriteRequest>());
    let availability = g::par(g::send::<FIRST, OWNER, F::Available>(), g::send::<SECOND, OWNER, S::Available>());
    let acquire = g::par(
        g::seq(g::send::<OWNER, FIRST, F::Acquire>(), g::send::<FIRST, OWNER, F::Granted>()),
        g::seq(g::send::<OWNER, SECOND, S::Acquire>(), g::send::<SECOND, OWNER, S::Granted>())
    );
    let release = g::par(
        g::seq(g::send::<OWNER, FIRST, F::Return>(), g::send::<FIRST, OWNER, F::Returned>()),
        g::seq(g::send::<OWNER, SECOND, S::Return>(), g::send::<SECOND, OWNER, S::Returned>())
    );
    let write = g::seq(g::par(preparation, availability),
        g::seq(acquire, g::seq(g::send::<OWNER, OWNER, WriteEffect>(),
            g::seq(release, g::seq(g::send::<OWNER, VM, Completed<'static>>(), g::send::<OWNER, VM, ServiceDone>())))));
    let review = g::seq(requests::<VM, OWNER, ReviewRequest>(),
        g::seq(g::send::<OWNER, OWNER, ReviewEffect>(),
            g::seq(g::send::<OWNER, VM, Completed<'static>>(), g::send::<OWNER, VM, ServiceDone>())));
    g::seq(write, g::seq(review, closed::<VM, OWNER>()))
}

pub mod roles2e {
pub const A: u8 = 0;
pub const B: u8 = 1;
pub const C: u8 = 2;
pub const INTRO: u8 = 7;
pub const METHODS: u8 = 8;
pub const RESULTS: u8 = 9;
pub const A_WASI: u8 = 14;
pub const A_IO: u8 = 21;
pub const B_WASI: u8 = 15;
pub const B_IO: u8 = 22;
pub const C_WASI: u8 = 16;
pub const C_IO: u8 = 23;
}
pub struct Programs2E {
pub a: RoleProgram<{roles2e::A}>,
pub b: RoleProgram<{roles2e::B}>,
pub c: RoleProgram<{roles2e::C}>,
pub intro: RoleProgram<{roles2e::INTRO}>,
pub methods: RoleProgram<{roles2e::METHODS}>,
pub results: RoleProgram<{roles2e::RESULTS}>,
pub a_wasi: RoleProgram<{roles2e::A_WASI}>,
pub b_wasi: RoleProgram<{roles2e::B_WASI}>,
pub c_wasi: RoleProgram<{roles2e::C_WASI}>,
pub a_io: RoleProgram<{roles2e::A_IO}>,
pub b_io: RoleProgram<{roles2e::B_IO}>,
pub c_io: RoleProgram<{roles2e::C_IO}>,
}
pub fn project_2e() -> Programs2E {
use roles2e::*;
let preparation = g::par(prepare::<A_WASI, A>(), g::par(prepare::<B_WASI, B>(), prepare::<C_WASI, C>()));
let writes_0 = write::<A_WASI, A, INTRO, METHODS, Intro, Methods>();
let writes_1 = write::<B_WASI, B, METHODS, RESULTS, Methods, Results>();
let writes_2 = write::<C_WASI, C, INTRO, RESULTS, Intro, Results>();
let task = g::seq(preparation, g::seq(writes_0, g::seq(writes_1, writes_2)));
let private = g::par(crate::shell::global::private_io::<A_WASI, A_IO>(), g::par(crate::shell::global::private_io::<B_WASI, B_IO>(), crate::shell::global::private_io::<C_WASI, C_IO>()));
let protocol = g::par(task, private);
Programs2E {
a: project(&protocol),
b: project(&protocol),
c: project(&protocol),
intro: project(&protocol),
methods: project(&protocol),
results: project(&protocol),
a_wasi: project(&protocol),
b_wasi: project(&protocol),
c_wasi: project(&protocol),
a_io: project(&protocol),
b_io: project(&protocol),
c_io: project(&protocol),
}
}

pub mod roles2m {
pub const A: u8 = 0;
pub const B: u8 = 1;
pub const C: u8 = 2;
pub const D: u8 = 3;
pub const E: u8 = 4;
pub const BACKGROUND: u8 = 7;
pub const INTRO: u8 = 8;
pub const METHODS: u8 = 9;
pub const EXPERIMENTS: u8 = 10;
pub const RESULTS: u8 = 11;
pub const A_WASI: u8 = 14;
pub const A_IO: u8 = 21;
pub const B_WASI: u8 = 15;
pub const B_IO: u8 = 22;
pub const C_WASI: u8 = 16;
pub const C_IO: u8 = 23;
pub const D_WASI: u8 = 17;
pub const D_IO: u8 = 24;
pub const E_WASI: u8 = 18;
pub const E_IO: u8 = 25;
}
pub struct Programs2M {
pub a: RoleProgram<{roles2m::A}>,
pub b: RoleProgram<{roles2m::B}>,
pub c: RoleProgram<{roles2m::C}>,
pub d: RoleProgram<{roles2m::D}>,
pub e: RoleProgram<{roles2m::E}>,
pub background: RoleProgram<{roles2m::BACKGROUND}>,
pub intro: RoleProgram<{roles2m::INTRO}>,
pub methods: RoleProgram<{roles2m::METHODS}>,
pub experiments: RoleProgram<{roles2m::EXPERIMENTS}>,
pub results: RoleProgram<{roles2m::RESULTS}>,
pub a_wasi: RoleProgram<{roles2m::A_WASI}>,
pub b_wasi: RoleProgram<{roles2m::B_WASI}>,
pub c_wasi: RoleProgram<{roles2m::C_WASI}>,
pub d_wasi: RoleProgram<{roles2m::D_WASI}>,
pub e_wasi: RoleProgram<{roles2m::E_WASI}>,
pub a_io: RoleProgram<{roles2m::A_IO}>,
pub b_io: RoleProgram<{roles2m::B_IO}>,
pub c_io: RoleProgram<{roles2m::C_IO}>,
pub d_io: RoleProgram<{roles2m::D_IO}>,
pub e_io: RoleProgram<{roles2m::E_IO}>,
}
pub fn project_2m() -> Programs2M {
use roles2m::*;
let preparation = g::par(prepare::<A_WASI, A>(), g::par(prepare::<B_WASI, B>(), g::par(prepare::<C_WASI, C>(), g::par(prepare::<D_WASI, D>(), prepare::<E_WASI, E>()))));
let writes_0 = g::par(write::<A_WASI, A, BACKGROUND, INTRO, Background, Intro>(), write::<C_WASI, C, EXPERIMENTS, METHODS, Experiments, Methods>());
let writes_1 = g::par(write::<B_WASI, B, BACKGROUND, METHODS, Background, Methods>(), write::<D_WASI, D, EXPERIMENTS, RESULTS, Experiments, Results>());
let writes_2 = write::<E_WASI, E, INTRO, RESULTS, Intro, Results>();
let task = g::seq(preparation, g::seq(writes_0, g::seq(writes_1, writes_2)));
let private = g::par(crate::shell::global::private_io::<A_WASI, A_IO>(), g::par(crate::shell::global::private_io::<B_WASI, B_IO>(), g::par(crate::shell::global::private_io::<C_WASI, C_IO>(), g::par(crate::shell::global::private_io::<D_WASI, D_IO>(), crate::shell::global::private_io::<E_WASI, E_IO>()))));
let protocol = g::par(task, private);
Programs2M {
a: project(&protocol),
b: project(&protocol),
c: project(&protocol),
d: project(&protocol),
e: project(&protocol),
background: project(&protocol),
intro: project(&protocol),
methods: project(&protocol),
experiments: project(&protocol),
results: project(&protocol),
a_wasi: project(&protocol),
b_wasi: project(&protocol),
c_wasi: project(&protocol),
d_wasi: project(&protocol),
e_wasi: project(&protocol),
a_io: project(&protocol),
b_io: project(&protocol),
c_io: project(&protocol),
d_io: project(&protocol),
e_io: project(&protocol),
}
}

pub mod roles2h {
pub const A: u8 = 0;
pub const B: u8 = 1;
pub const C: u8 = 2;
pub const D: u8 = 3;
pub const E: u8 = 4;
pub const F: u8 = 5;
pub const G: u8 = 6;
pub const BACKGROUND: u8 = 7;
pub const INTRO: u8 = 8;
pub const RELATED: u8 = 9;
pub const METHODS: u8 = 10;
pub const EXPERIMENTS: u8 = 11;
pub const RESULTS: u8 = 12;
pub const DISCUSSION: u8 = 13;
pub const A_WASI: u8 = 14;
pub const A_IO: u8 = 21;
pub const B_WASI: u8 = 15;
pub const B_IO: u8 = 22;
pub const C_WASI: u8 = 16;
pub const C_IO: u8 = 23;
pub const D_WASI: u8 = 17;
pub const D_IO: u8 = 24;
pub const E_WASI: u8 = 18;
pub const E_IO: u8 = 25;
pub const F_WASI: u8 = 19;
pub const F_IO: u8 = 26;
pub const G_WASI: u8 = 20;
pub const G_IO: u8 = 27;
}
pub struct Programs2H {
pub a: RoleProgram<{roles2h::A}>,
pub b: RoleProgram<{roles2h::B}>,
pub c: RoleProgram<{roles2h::C}>,
pub d: RoleProgram<{roles2h::D}>,
pub e: RoleProgram<{roles2h::E}>,
pub f: RoleProgram<{roles2h::F}>,
pub g: RoleProgram<{roles2h::G}>,
pub background: RoleProgram<{roles2h::BACKGROUND}>,
pub intro: RoleProgram<{roles2h::INTRO}>,
pub related: RoleProgram<{roles2h::RELATED}>,
pub methods: RoleProgram<{roles2h::METHODS}>,
pub experiments: RoleProgram<{roles2h::EXPERIMENTS}>,
pub results: RoleProgram<{roles2h::RESULTS}>,
pub discussion: RoleProgram<{roles2h::DISCUSSION}>,
pub a_wasi: RoleProgram<{roles2h::A_WASI}>,
pub b_wasi: RoleProgram<{roles2h::B_WASI}>,
pub c_wasi: RoleProgram<{roles2h::C_WASI}>,
pub d_wasi: RoleProgram<{roles2h::D_WASI}>,
pub e_wasi: RoleProgram<{roles2h::E_WASI}>,
pub f_wasi: RoleProgram<{roles2h::F_WASI}>,
pub g_wasi: RoleProgram<{roles2h::G_WASI}>,
pub a_io: RoleProgram<{roles2h::A_IO}>,
pub b_io: RoleProgram<{roles2h::B_IO}>,
pub c_io: RoleProgram<{roles2h::C_IO}>,
pub d_io: RoleProgram<{roles2h::D_IO}>,
pub e_io: RoleProgram<{roles2h::E_IO}>,
pub f_io: RoleProgram<{roles2h::F_IO}>,
pub g_io: RoleProgram<{roles2h::G_IO}>,
}
pub fn project_2h() -> Programs2H {
use roles2h::*;
let preparation = g::par(prepare::<A_WASI, A>(), g::par(prepare::<B_WASI, B>(), g::par(prepare::<C_WASI, C>(), g::par(prepare::<D_WASI, D>(), g::par(prepare::<E_WASI, E>(), g::par(prepare::<F_WASI, F>(), prepare::<G_WASI, G>()))))));
let writes_0 = g::par(write::<A_WASI, A, BACKGROUND, INTRO, Background, Intro>(), g::par(write::<C_WASI, C, METHODS, RELATED, Methods, Related>(), write::<E_WASI, E, EXPERIMENTS, RESULTS, Experiments, Results>()));
let writes_1 = g::par(write::<B_WASI, B, BACKGROUND, RELATED, Background, Related>(), g::par(write::<D_WASI, D, EXPERIMENTS, METHODS, Experiments, Methods>(), write::<F_WASI, F, DISCUSSION, RESULTS, Discussion, Results>()));
let writes_2 = write::<G_WASI, G, DISCUSSION, INTRO, Discussion, Intro>();
let task = g::seq(preparation, g::seq(writes_0, g::seq(writes_1, writes_2)));
let private = g::par(crate::shell::global::private_io::<A_WASI, A_IO>(), g::par(crate::shell::global::private_io::<B_WASI, B_IO>(), g::par(crate::shell::global::private_io::<C_WASI, C_IO>(), g::par(crate::shell::global::private_io::<D_WASI, D_IO>(), g::par(crate::shell::global::private_io::<E_WASI, E_IO>(), g::par(crate::shell::global::private_io::<F_WASI, F_IO>(), crate::shell::global::private_io::<G_WASI, G_IO>()))))));
let protocol = g::par(task, private);
Programs2H {
a: project(&protocol),
b: project(&protocol),
c: project(&protocol),
d: project(&protocol),
e: project(&protocol),
f: project(&protocol),
g: project(&protocol),
background: project(&protocol),
intro: project(&protocol),
related: project(&protocol),
methods: project(&protocol),
experiments: project(&protocol),
results: project(&protocol),
discussion: project(&protocol),
a_wasi: project(&protocol),
b_wasi: project(&protocol),
c_wasi: project(&protocol),
d_wasi: project(&protocol),
e_wasi: project(&protocol),
f_wasi: project(&protocol),
g_wasi: project(&protocol),
a_io: project(&protocol),
b_io: project(&protocol),
c_io: project(&protocol),
d_io: project(&protocol),
e_io: project(&protocol),
f_io: project(&protocol),
g_io: project(&protocol),
}
}

