import Hibana

set_option maxRecDepth 10000

def parallelTree : Hibana.Choreo := Hibana.Choreo.seq (Hibana.Choreo.par (Hibana.Choreo.par (Hibana.Choreo.par (Hibana.Choreo.send 0 1 1 0) (Hibana.Choreo.send 0 2 2 0)) (Hibana.Choreo.par (Hibana.Choreo.send 0 1 3 0) (Hibana.Choreo.send 0 2 4 0))) (Hibana.Choreo.par (Hibana.Choreo.par (Hibana.Choreo.send 0 1 5 0) (Hibana.Choreo.send 0 2 6 0)) (Hibana.Choreo.par (Hibana.Choreo.send 0 1 7 0) (Hibana.Choreo.send 0 2 8 0)))) (Hibana.Choreo.send 0 1 9 0)

def parallelIndependent : Hibana.Choreo := Hibana.Choreo.par (Hibana.Choreo.par (Hibana.Choreo.roll (Hibana.Choreo.route .intrinsic (Hibana.Choreo.seq (Hibana.Choreo.send 1 0 5 0) (Hibana.Choreo.send 0 1 6 0)) (Hibana.Choreo.seq (Hibana.Choreo.send 1 0 7 0) (Hibana.Choreo.send 0 1 8 0)))) (Hibana.Choreo.par (Hibana.Choreo.send 0 2 12 0) (Hibana.Choreo.send 0 2 13 0))) (Hibana.Choreo.roll (Hibana.Choreo.seq (Hibana.Choreo.send 0 2 9 0) (Hibana.Choreo.route .intrinsic (Hibana.Choreo.send 2 0 10 0) (Hibana.Choreo.send 2 0 11 0))))

def parallelPrefix : Hibana.Choreo := Hibana.Choreo.seq (Hibana.Choreo.send 0 1 10 6) (Hibana.Choreo.par (Hibana.Choreo.send 0 1 11 6) (Hibana.Choreo.send 0 1 20 6))

def parallelNestedPrefix : Hibana.Choreo := Hibana.Choreo.seq (Hibana.Choreo.send 0 1 10 6) (Hibana.Choreo.par (Hibana.Choreo.seq (Hibana.Choreo.send 0 1 12 6) (Hibana.Choreo.par (Hibana.Choreo.send 0 1 13 6) (Hibana.Choreo.send 0 1 14 6))) (Hibana.Choreo.par (Hibana.Choreo.send 0 1 15 6) (Hibana.Choreo.send 0 1 16 6)))

def parallelPrefixRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := parallelPrefix
  topology := {
  events := [
    { action := .send 1 10 6 },
    { action := .send 1 11 6 },
    { action := .send 1 20 6 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelPrefixRole0Accepted : parallelPrefixRole0.check = true := by
  decide

theorem parallelPrefixRole0RefinesTopology : parallelPrefixRole0.RefinesTopology :=
  Hibana.projection_certificate_sound parallelPrefixRole0Accepted

def parallelPrefixRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 2
    activeLaneCount := 2
    endpointLaneSlotCount := 2
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 3
    eventCount := 3
    dependencyRowCount := 2
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 10, 6, 0, 0, 0, 0, 0, 0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 1, 20, 6, 0, 0, 0, 0, 1, 1, 0, 0, 64, 0, 2, 0, 0, 64, 1, 3, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 1, 0, 0, 0, 255, 255, 0, 64, 0, 0, 2, 0, 1, 0, 255, 255, 0, 64, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3, 0, 3]
  }
  choreo := parallelPrefix
}

theorem parallelPrefixRole0ExactAccepted : parallelPrefixRole0Exact.check = true := by
  decide

theorem parallelPrefixRole0ExactRefines : parallelPrefixRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelPrefixRole0ExactAccepted

def parallelPrefixRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set parallelPrefixRole0Exact.image.roleLaneOffset 1
  }
}

theorem parallelPrefixRole0ExactLaneMismatchRejected : parallelPrefixRole0ExactLaneMismatch.check = false := by
  decide

def parallelPrefixRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set 0 1
  }
}

theorem parallelPrefixRole0ExactEffIndexMismatchRejected : parallelPrefixRole0ExactEffIndexMismatch.check = false := by
  decide

def parallelPrefixRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set 8 1
  }
}

theorem parallelPrefixRole0ExactFrameLabelMismatchRejected : parallelPrefixRole0ExactFrameLabelMismatch.check = false := by
  decide

def parallelPrefixRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := (parallelPrefixRole0Exact.image.roleBytes.set 6 0).set 7 0
  }
}

theorem parallelPrefixRole0ExactEventScopeMismatchRejected : parallelPrefixRole0ExactEventScopeMismatch.check = false := by
  decide

def parallelPrefixRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set 9 1
  }
}

theorem parallelPrefixRole0ExactEventFlagMismatchRejected : parallelPrefixRole0ExactEventFlagMismatch.check = false := by
  decide

def parallelPrefixRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    programBytes := parallelPrefixRole0Exact.image.programBytes.set 4 1
  }
}

theorem parallelPrefixRole0ExactGlobalActionMismatchRejected : parallelPrefixRole0ExactGlobalActionMismatch.check = false := by
  decide

def parallelPrefixRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    programBytes := parallelPrefixRole0Exact.image.programBytes.set 9 1
  }
}

theorem parallelPrefixRole0ExactGlobalOriginMismatchRejected : parallelPrefixRole0ExactGlobalOriginMismatch.check = false := by
  decide

def parallelPrefixRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    programBytes := parallelPrefixRole0Exact.image.programBytes.set 10 2
  }
}

theorem parallelPrefixRole0ExactGlobalLaneMismatchRejected : parallelPrefixRole0ExactGlobalLaneMismatch.check = false := by
  decide

def parallelPrefixRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    programBytes := parallelPrefixRole0Exact.image.programBytes.set (parallelPrefixRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelPrefixRole0ExactScopeMarkerMismatchRejected : parallelPrefixRole0ExactScopeMarkerMismatch.check = false := by
  decide

def parallelPrefixRole0ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set (parallelPrefixRole0Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelPrefixRole0ExactDependencyScopeMismatchRejected : parallelPrefixRole0ExactDependencyScopeMismatch.check = false := by
  decide

def parallelPrefixRole0ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set (parallelPrefixRole0Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelPrefixRole0ExactDependencyConflictMismatchRejected : parallelPrefixRole0ExactDependencyConflictMismatch.check = false := by
  decide

def parallelPrefixRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    logicalLaneCount := 3
  }
}

theorem parallelPrefixRole0ExactLogicalLaneCountMismatchRejected : parallelPrefixRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelPrefixRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole0Exact with
  image := { parallelPrefixRole0Exact.image with
    roleBytes := parallelPrefixRole0Exact.image.roleBytes.set parallelPrefixRole0Exact.image.roleLaneBitOffset 2
  }
}

theorem parallelPrefixRole0ExactLaneBitMismatchRejected : parallelPrefixRole0ExactLaneBitMismatch.check = false := by
  decide

def parallelPrefixRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := parallelPrefix
  topology := {
  events := [
    { action := .recv 0 10 6 },
    { action := .recv 0 11 6 },
    { action := .recv 0 20 6 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelPrefixRole1Accepted : parallelPrefixRole1.check = true := by
  decide

theorem parallelPrefixRole1RefinesTopology : parallelPrefixRole1.RefinesTopology :=
  Hibana.projection_certificate_sound parallelPrefixRole1Accepted

def parallelPrefixRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 2
    activeLaneCount := 2
    endpointLaneSlotCount := 2
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 3
    eventCount := 3
    dependencyRowCount := 2
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 10, 6, 0, 0, 0, 0, 0, 0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 1, 20, 6, 0, 0, 0, 0, 1, 1, 0, 0, 64, 0, 2, 0, 0, 64, 1, 3, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 1, 0, 0, 0, 255, 255, 0, 64, 0, 0, 2, 0, 1, 0, 255, 255, 0, 64, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3, 0, 3]
  }
  choreo := parallelPrefix
}

theorem parallelPrefixRole1ExactAccepted : parallelPrefixRole1Exact.check = true := by
  decide

theorem parallelPrefixRole1ExactRefines : parallelPrefixRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelPrefixRole1ExactAccepted

def parallelPrefixRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set parallelPrefixRole1Exact.image.roleLaneOffset 1
  }
}

theorem parallelPrefixRole1ExactLaneMismatchRejected : parallelPrefixRole1ExactLaneMismatch.check = false := by
  decide

def parallelPrefixRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set 0 1
  }
}

theorem parallelPrefixRole1ExactEffIndexMismatchRejected : parallelPrefixRole1ExactEffIndexMismatch.check = false := by
  decide

def parallelPrefixRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set 8 1
  }
}

theorem parallelPrefixRole1ExactFrameLabelMismatchRejected : parallelPrefixRole1ExactFrameLabelMismatch.check = false := by
  decide

def parallelPrefixRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := (parallelPrefixRole1Exact.image.roleBytes.set 6 0).set 7 0
  }
}

theorem parallelPrefixRole1ExactEventScopeMismatchRejected : parallelPrefixRole1ExactEventScopeMismatch.check = false := by
  decide

def parallelPrefixRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set 9 1
  }
}

theorem parallelPrefixRole1ExactEventFlagMismatchRejected : parallelPrefixRole1ExactEventFlagMismatch.check = false := by
  decide

def parallelPrefixRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    programBytes := parallelPrefixRole1Exact.image.programBytes.set 4 1
  }
}

theorem parallelPrefixRole1ExactGlobalActionMismatchRejected : parallelPrefixRole1ExactGlobalActionMismatch.check = false := by
  decide

def parallelPrefixRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    programBytes := parallelPrefixRole1Exact.image.programBytes.set 9 1
  }
}

theorem parallelPrefixRole1ExactGlobalOriginMismatchRejected : parallelPrefixRole1ExactGlobalOriginMismatch.check = false := by
  decide

def parallelPrefixRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    programBytes := parallelPrefixRole1Exact.image.programBytes.set 10 2
  }
}

theorem parallelPrefixRole1ExactGlobalLaneMismatchRejected : parallelPrefixRole1ExactGlobalLaneMismatch.check = false := by
  decide

def parallelPrefixRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    programBytes := parallelPrefixRole1Exact.image.programBytes.set (parallelPrefixRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelPrefixRole1ExactScopeMarkerMismatchRejected : parallelPrefixRole1ExactScopeMarkerMismatch.check = false := by
  decide

def parallelPrefixRole1ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set (parallelPrefixRole1Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelPrefixRole1ExactDependencyScopeMismatchRejected : parallelPrefixRole1ExactDependencyScopeMismatch.check = false := by
  decide

def parallelPrefixRole1ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set (parallelPrefixRole1Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelPrefixRole1ExactDependencyConflictMismatchRejected : parallelPrefixRole1ExactDependencyConflictMismatch.check = false := by
  decide

def parallelPrefixRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    logicalLaneCount := 3
  }
}

theorem parallelPrefixRole1ExactLogicalLaneCountMismatchRejected : parallelPrefixRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelPrefixRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelPrefixRole1Exact with
  image := { parallelPrefixRole1Exact.image with
    roleBytes := parallelPrefixRole1Exact.image.roleBytes.set parallelPrefixRole1Exact.image.roleLaneBitOffset 2
  }
}

theorem parallelPrefixRole1ExactLaneBitMismatchRejected : parallelPrefixRole1ExactLaneBitMismatch.check = false := by
  decide

def parallelNestedPrefixRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := parallelNestedPrefix
  topology := {
  events := [
    { action := .send 1 10 6 },
    { action := .send 1 12 6 },
    { action := .send 1 13 6 },
    { action := .send 1 14 6 },
    { action := .send 1 15 6 },
    { action := .send 1 16 6 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelNestedPrefixRole0Accepted : parallelNestedPrefixRole0.check = true := by
  decide

theorem parallelNestedPrefixRole0RefinesTopology : parallelNestedPrefixRole0.RefinesTopology :=
  Hibana.projection_certificate_sound parallelNestedPrefixRole0Accepted

def parallelNestedPrefixRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 4
    activeLaneCount := 4
    endpointLaneSlotCount := 4
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 9
    eventCount := 6
    dependencyRowCount := 5
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 10, 6, 0, 0, 0, 0, 0, 0, 1, 12, 6, 0, 0, 0, 0, 0, 0, 1, 13, 6, 0, 0, 0, 0, 0, 0, 1, 14, 6, 0, 0, 0, 0, 1, 0, 1, 15, 6, 0, 0, 0, 0, 2, 0, 1, 16, 6, 0, 0, 0, 0, 3, 1, 0, 0, 64, 0, 2, 0, 1, 64, 0, 3, 0, 1, 64, 1, 4, 0, 1, 64, 2, 4, 0, 2, 64, 0, 4, 0, 0, 64, 1, 5, 0, 2, 64, 1, 6, 0, 2, 64, 2, 6, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 1, 0, 0, 0, 255, 255, 0, 64, 0, 0, 2, 0, 1, 0, 255, 255, 1, 64, 0, 0, 3, 0, 2, 0, 255, 255, 1, 64, 0, 0, 4, 0, 3, 0, 255, 255, 2, 64, 0, 0, 5, 0, 4, 0, 255, 255, 2, 64, 0, 0, 0, 0, 0, 1, 2, 3, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 6, 0, 15]
  }
  choreo := parallelNestedPrefix
}

theorem parallelNestedPrefixRole0ExactAccepted : parallelNestedPrefixRole0Exact.check = true := by
  decide

theorem parallelNestedPrefixRole0ExactRefines : parallelNestedPrefixRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelNestedPrefixRole0ExactAccepted

def parallelNestedPrefixRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set parallelNestedPrefixRole0Exact.image.roleLaneOffset 1
  }
}

theorem parallelNestedPrefixRole0ExactLaneMismatchRejected : parallelNestedPrefixRole0ExactLaneMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set 0 1
  }
}

theorem parallelNestedPrefixRole0ExactEffIndexMismatchRejected : parallelNestedPrefixRole0ExactEffIndexMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set 8 1
  }
}

theorem parallelNestedPrefixRole0ExactFrameLabelMismatchRejected : parallelNestedPrefixRole0ExactFrameLabelMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := (parallelNestedPrefixRole0Exact.image.roleBytes.set 6 0).set 7 0
  }
}

theorem parallelNestedPrefixRole0ExactEventScopeMismatchRejected : parallelNestedPrefixRole0ExactEventScopeMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set 9 1
  }
}

theorem parallelNestedPrefixRole0ExactEventFlagMismatchRejected : parallelNestedPrefixRole0ExactEventFlagMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    programBytes := parallelNestedPrefixRole0Exact.image.programBytes.set 4 1
  }
}

theorem parallelNestedPrefixRole0ExactGlobalActionMismatchRejected : parallelNestedPrefixRole0ExactGlobalActionMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    programBytes := parallelNestedPrefixRole0Exact.image.programBytes.set 9 1
  }
}

theorem parallelNestedPrefixRole0ExactGlobalOriginMismatchRejected : parallelNestedPrefixRole0ExactGlobalOriginMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    programBytes := parallelNestedPrefixRole0Exact.image.programBytes.set 10 2
  }
}

theorem parallelNestedPrefixRole0ExactGlobalLaneMismatchRejected : parallelNestedPrefixRole0ExactGlobalLaneMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    programBytes := parallelNestedPrefixRole0Exact.image.programBytes.set (parallelNestedPrefixRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelNestedPrefixRole0ExactScopeMarkerMismatchRejected : parallelNestedPrefixRole0ExactScopeMarkerMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set (parallelNestedPrefixRole0Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelNestedPrefixRole0ExactDependencyScopeMismatchRejected : parallelNestedPrefixRole0ExactDependencyScopeMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set (parallelNestedPrefixRole0Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelNestedPrefixRole0ExactDependencyConflictMismatchRejected : parallelNestedPrefixRole0ExactDependencyConflictMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    logicalLaneCount := 5
  }
}

theorem parallelNestedPrefixRole0ExactLogicalLaneCountMismatchRejected : parallelNestedPrefixRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelNestedPrefixRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole0Exact with
  image := { parallelNestedPrefixRole0Exact.image with
    roleBytes := parallelNestedPrefixRole0Exact.image.roleBytes.set parallelNestedPrefixRole0Exact.image.roleLaneBitOffset 14
  }
}

theorem parallelNestedPrefixRole0ExactLaneBitMismatchRejected : parallelNestedPrefixRole0ExactLaneBitMismatch.check = false := by
  decide

def parallelNestedPrefixRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := parallelNestedPrefix
  topology := {
  events := [
    { action := .recv 0 10 6 },
    { action := .recv 0 12 6 },
    { action := .recv 0 13 6 },
    { action := .recv 0 14 6 },
    { action := .recv 0 15 6 },
    { action := .recv 0 16 6 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelNestedPrefixRole1Accepted : parallelNestedPrefixRole1.check = true := by
  decide

theorem parallelNestedPrefixRole1RefinesTopology : parallelNestedPrefixRole1.RefinesTopology :=
  Hibana.projection_certificate_sound parallelNestedPrefixRole1Accepted

def parallelNestedPrefixRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 4
    activeLaneCount := 4
    endpointLaneSlotCount := 4
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 9
    eventCount := 6
    dependencyRowCount := 5
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 10, 6, 0, 0, 0, 0, 0, 0, 1, 12, 6, 0, 0, 0, 0, 0, 0, 1, 13, 6, 0, 0, 0, 0, 0, 0, 1, 14, 6, 0, 0, 0, 0, 1, 0, 1, 15, 6, 0, 0, 0, 0, 2, 0, 1, 16, 6, 0, 0, 0, 0, 3, 1, 0, 0, 64, 0, 2, 0, 1, 64, 0, 3, 0, 1, 64, 1, 4, 0, 1, 64, 2, 4, 0, 2, 64, 0, 4, 0, 0, 64, 1, 5, 0, 2, 64, 1, 6, 0, 2, 64, 2, 6, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 1, 0, 0, 0, 255, 255, 0, 64, 0, 0, 2, 0, 1, 0, 255, 255, 1, 64, 0, 0, 3, 0, 2, 0, 255, 255, 1, 64, 0, 0, 4, 0, 3, 0, 255, 255, 2, 64, 0, 0, 5, 0, 4, 0, 255, 255, 2, 64, 0, 0, 0, 0, 0, 1, 2, 3, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 6, 0, 15]
  }
  choreo := parallelNestedPrefix
}

theorem parallelNestedPrefixRole1ExactAccepted : parallelNestedPrefixRole1Exact.check = true := by
  decide

theorem parallelNestedPrefixRole1ExactRefines : parallelNestedPrefixRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelNestedPrefixRole1ExactAccepted

def parallelNestedPrefixRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set parallelNestedPrefixRole1Exact.image.roleLaneOffset 1
  }
}

theorem parallelNestedPrefixRole1ExactLaneMismatchRejected : parallelNestedPrefixRole1ExactLaneMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set 0 1
  }
}

theorem parallelNestedPrefixRole1ExactEffIndexMismatchRejected : parallelNestedPrefixRole1ExactEffIndexMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set 8 1
  }
}

theorem parallelNestedPrefixRole1ExactFrameLabelMismatchRejected : parallelNestedPrefixRole1ExactFrameLabelMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := (parallelNestedPrefixRole1Exact.image.roleBytes.set 6 0).set 7 0
  }
}

theorem parallelNestedPrefixRole1ExactEventScopeMismatchRejected : parallelNestedPrefixRole1ExactEventScopeMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set 9 1
  }
}

theorem parallelNestedPrefixRole1ExactEventFlagMismatchRejected : parallelNestedPrefixRole1ExactEventFlagMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    programBytes := parallelNestedPrefixRole1Exact.image.programBytes.set 4 1
  }
}

theorem parallelNestedPrefixRole1ExactGlobalActionMismatchRejected : parallelNestedPrefixRole1ExactGlobalActionMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    programBytes := parallelNestedPrefixRole1Exact.image.programBytes.set 9 1
  }
}

theorem parallelNestedPrefixRole1ExactGlobalOriginMismatchRejected : parallelNestedPrefixRole1ExactGlobalOriginMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    programBytes := parallelNestedPrefixRole1Exact.image.programBytes.set 10 2
  }
}

theorem parallelNestedPrefixRole1ExactGlobalLaneMismatchRejected : parallelNestedPrefixRole1ExactGlobalLaneMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    programBytes := parallelNestedPrefixRole1Exact.image.programBytes.set (parallelNestedPrefixRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelNestedPrefixRole1ExactScopeMarkerMismatchRejected : parallelNestedPrefixRole1ExactScopeMarkerMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set (parallelNestedPrefixRole1Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelNestedPrefixRole1ExactDependencyScopeMismatchRejected : parallelNestedPrefixRole1ExactDependencyScopeMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set (parallelNestedPrefixRole1Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelNestedPrefixRole1ExactDependencyConflictMismatchRejected : parallelNestedPrefixRole1ExactDependencyConflictMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    logicalLaneCount := 5
  }
}

theorem parallelNestedPrefixRole1ExactLogicalLaneCountMismatchRejected : parallelNestedPrefixRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelNestedPrefixRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelNestedPrefixRole1Exact with
  image := { parallelNestedPrefixRole1Exact.image with
    roleBytes := parallelNestedPrefixRole1Exact.image.roleBytes.set parallelNestedPrefixRole1Exact.image.roleLaneBitOffset 14
  }
}

theorem parallelNestedPrefixRole1ExactLaneBitMismatchRejected : parallelNestedPrefixRole1ExactLaneBitMismatch.check = false := by
  decide

def parallelTreeRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := parallelTree
  topology := {
  events := [
    { action := .send 1 1 0 },
    { action := .send 2 2 0 },
    { action := .send 1 3 0 },
    { action := .send 2 4 0 },
    { action := .send 1 5 0 },
    { action := .send 2 6 0 },
    { action := .send 1 7 0 },
    { action := .send 2 8 0 },
    { action := .send 1 9 0 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelTreeRole0Accepted : parallelTreeRole0.check = true := by
  decide

theorem parallelTreeRole0RefinesTopology : parallelTreeRole0.RefinesTopology :=
  Hibana.projection_certificate_sound parallelTreeRole0Accepted

def parallelTreeRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 0
    logicalLaneCount := 8
    activeLaneCount := 8
    endpointLaneSlotCount := 8
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 21
    eventCount := 9
    dependencyRowCount := 1
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 1, 0, 1, 3, 0, 0, 0, 0, 0, 2, 0, 2, 4, 0, 0, 0, 0, 0, 3, 0, 1, 5, 0, 0, 0, 0, 0, 4, 0, 2, 6, 0, 0, 0, 0, 0, 5, 0, 1, 7, 0, 0, 0, 0, 0, 6, 0, 2, 8, 0, 0, 0, 0, 0, 7, 0, 1, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 64, 0, 1, 0, 2, 64, 1, 2, 0, 2, 64, 2, 2, 0, 3, 64, 0, 2, 0, 1, 64, 1, 3, 0, 3, 64, 1, 4, 0, 3, 64, 2, 4, 0, 1, 64, 2, 4, 0, 4, 64, 0, 4, 0, 5, 64, 0, 4, 0, 0, 64, 1, 5, 0, 5, 64, 1, 6, 0, 5, 64, 2, 6, 0, 6, 64, 0, 6, 0, 4, 64, 1, 7, 0, 6, 64, 1, 8, 0, 6, 64, 2, 8, 0, 4, 64, 2, 8, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 2, 64, 0, 0, 1, 0, 255, 255, 255, 255, 2, 64, 0, 0, 2, 0, 255, 255, 255, 255, 3, 64, 0, 0, 3, 0, 255, 255, 255, 255, 3, 64, 0, 0, 4, 0, 255, 255, 255, 255, 5, 64, 0, 0, 5, 0, 255, 255, 255, 255, 5, 64, 0, 0, 6, 0, 255, 255, 255, 255, 6, 64, 0, 0, 7, 0, 255, 255, 255, 255, 6, 64, 0, 0, 8, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 8, 0, 9, 0, 255]
  }
  choreo := parallelTree
}

theorem parallelTreeRole0ExactAccepted : parallelTreeRole0Exact.check = true := by
  decide

theorem parallelTreeRole0ExactRefines : parallelTreeRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelTreeRole0ExactAccepted

def parallelTreeRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set parallelTreeRole0Exact.image.roleLaneOffset 1
  }
}

theorem parallelTreeRole0ExactLaneMismatchRejected : parallelTreeRole0ExactLaneMismatch.check = false := by
  decide

def parallelTreeRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set 0 1
  }
}

theorem parallelTreeRole0ExactEffIndexMismatchRejected : parallelTreeRole0ExactEffIndexMismatch.check = false := by
  decide

def parallelTreeRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set 8 1
  }
}

theorem parallelTreeRole0ExactFrameLabelMismatchRejected : parallelTreeRole0ExactFrameLabelMismatch.check = false := by
  decide

def parallelTreeRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := (parallelTreeRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelTreeRole0ExactEventScopeMismatchRejected : parallelTreeRole0ExactEventScopeMismatch.check = false := by
  decide

def parallelTreeRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set 9 1
  }
}

theorem parallelTreeRole0ExactEventFlagMismatchRejected : parallelTreeRole0ExactEventFlagMismatch.check = false := by
  decide

def parallelTreeRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    programBytes := parallelTreeRole0Exact.image.programBytes.set 4 1
  }
}

theorem parallelTreeRole0ExactGlobalActionMismatchRejected : parallelTreeRole0ExactGlobalActionMismatch.check = false := by
  decide

def parallelTreeRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    programBytes := parallelTreeRole0Exact.image.programBytes.set 9 1
  }
}

theorem parallelTreeRole0ExactGlobalOriginMismatchRejected : parallelTreeRole0ExactGlobalOriginMismatch.check = false := by
  decide

def parallelTreeRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    programBytes := parallelTreeRole0Exact.image.programBytes.set 10 3
  }
}

theorem parallelTreeRole0ExactGlobalLaneMismatchRejected : parallelTreeRole0ExactGlobalLaneMismatch.check = false := by
  decide

def parallelTreeRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    programBytes := parallelTreeRole0Exact.image.programBytes.set (parallelTreeRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelTreeRole0ExactScopeMarkerMismatchRejected : parallelTreeRole0ExactScopeMarkerMismatch.check = false := by
  decide

def parallelTreeRole0ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set (parallelTreeRole0Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelTreeRole0ExactDependencyScopeMismatchRejected : parallelTreeRole0ExactDependencyScopeMismatch.check = false := by
  decide

def parallelTreeRole0ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set (parallelTreeRole0Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelTreeRole0ExactDependencyConflictMismatchRejected : parallelTreeRole0ExactDependencyConflictMismatch.check = false := by
  decide

def parallelTreeRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    logicalLaneCount := 9
  }
}

theorem parallelTreeRole0ExactLogicalLaneCountMismatchRejected : parallelTreeRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelTreeRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole0Exact with
  image := { parallelTreeRole0Exact.image with
    roleBytes := parallelTreeRole0Exact.image.roleBytes.set parallelTreeRole0Exact.image.roleLaneBitOffset 254
  }
}

theorem parallelTreeRole0ExactLaneBitMismatchRejected : parallelTreeRole0ExactLaneBitMismatch.check = false := by
  decide

def parallelTreeRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := parallelTree
  topology := {
  events := [
    { action := .recv 0 1 0 },
    { action := .recv 0 3 0 },
    { action := .recv 0 5 0 },
    { action := .recv 0 7 0 },
    { action := .recv 0 9 0 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelTreeRole1Accepted : parallelTreeRole1.check = true := by
  decide

theorem parallelTreeRole1RefinesTopology : parallelTreeRole1.RefinesTopology :=
  Hibana.projection_certificate_sound parallelTreeRole1Accepted

def parallelTreeRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 1
    logicalLaneCount := 7
    activeLaneCount := 4
    endpointLaneSlotCount := 7
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 21
    eventCount := 5
    dependencyRowCount := 1
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 3
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 1, 0, 1, 3, 0, 0, 0, 0, 0, 2, 0, 2, 4, 0, 0, 0, 0, 0, 3, 0, 1, 5, 0, 0, 0, 0, 0, 4, 0, 2, 6, 0, 0, 0, 0, 0, 5, 0, 1, 7, 0, 0, 0, 0, 0, 6, 0, 2, 8, 0, 0, 0, 0, 0, 7, 0, 1, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 64, 0, 1, 0, 2, 64, 1, 2, 0, 2, 64, 2, 2, 0, 3, 64, 0, 2, 0, 1, 64, 1, 3, 0, 3, 64, 1, 4, 0, 3, 64, 2, 4, 0, 1, 64, 2, 4, 0, 4, 64, 0, 4, 0, 5, 64, 0, 4, 0, 0, 64, 1, 5, 0, 5, 64, 1, 6, 0, 5, 64, 2, 6, 0, 6, 64, 0, 6, 0, 4, 64, 1, 7, 0, 6, 64, 1, 8, 0, 6, 64, 2, 8, 0, 4, 64, 2, 8, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 2, 64, 0, 0, 2, 0, 255, 255, 255, 255, 3, 64, 0, 0, 4, 0, 255, 255, 255, 255, 5, 64, 0, 0, 6, 0, 255, 255, 255, 255, 6, 64, 0, 0, 8, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 2, 4, 6, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 4, 0, 5, 0, 85]
  }
  choreo := parallelTree
}

theorem parallelTreeRole1ExactAccepted : parallelTreeRole1Exact.check = true := by
  decide

theorem parallelTreeRole1ExactRefines : parallelTreeRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelTreeRole1ExactAccepted

def parallelTreeRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set parallelTreeRole1Exact.image.roleLaneOffset 1
  }
}

theorem parallelTreeRole1ExactLaneMismatchRejected : parallelTreeRole1ExactLaneMismatch.check = false := by
  decide

def parallelTreeRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set 0 1
  }
}

theorem parallelTreeRole1ExactEffIndexMismatchRejected : parallelTreeRole1ExactEffIndexMismatch.check = false := by
  decide

def parallelTreeRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set 8 1
  }
}

theorem parallelTreeRole1ExactFrameLabelMismatchRejected : parallelTreeRole1ExactFrameLabelMismatch.check = false := by
  decide

def parallelTreeRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := (parallelTreeRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelTreeRole1ExactEventScopeMismatchRejected : parallelTreeRole1ExactEventScopeMismatch.check = false := by
  decide

def parallelTreeRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set 9 1
  }
}

theorem parallelTreeRole1ExactEventFlagMismatchRejected : parallelTreeRole1ExactEventFlagMismatch.check = false := by
  decide

def parallelTreeRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    programBytes := parallelTreeRole1Exact.image.programBytes.set 4 1
  }
}

theorem parallelTreeRole1ExactGlobalActionMismatchRejected : parallelTreeRole1ExactGlobalActionMismatch.check = false := by
  decide

def parallelTreeRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    programBytes := parallelTreeRole1Exact.image.programBytes.set 9 1
  }
}

theorem parallelTreeRole1ExactGlobalOriginMismatchRejected : parallelTreeRole1ExactGlobalOriginMismatch.check = false := by
  decide

def parallelTreeRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    programBytes := parallelTreeRole1Exact.image.programBytes.set 10 3
  }
}

theorem parallelTreeRole1ExactGlobalLaneMismatchRejected : parallelTreeRole1ExactGlobalLaneMismatch.check = false := by
  decide

def parallelTreeRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    programBytes := parallelTreeRole1Exact.image.programBytes.set (parallelTreeRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelTreeRole1ExactScopeMarkerMismatchRejected : parallelTreeRole1ExactScopeMarkerMismatch.check = false := by
  decide

def parallelTreeRole1ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set (parallelTreeRole1Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem parallelTreeRole1ExactDependencyScopeMismatchRejected : parallelTreeRole1ExactDependencyScopeMismatch.check = false := by
  decide

def parallelTreeRole1ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set (parallelTreeRole1Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem parallelTreeRole1ExactDependencyConflictMismatchRejected : parallelTreeRole1ExactDependencyConflictMismatch.check = false := by
  decide

def parallelTreeRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    logicalLaneCount := 8
  }
}

theorem parallelTreeRole1ExactLogicalLaneCountMismatchRejected : parallelTreeRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelTreeRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole1Exact with
  image := { parallelTreeRole1Exact.image with
    roleBytes := parallelTreeRole1Exact.image.roleBytes.set parallelTreeRole1Exact.image.roleLaneBitOffset 84
  }
}

theorem parallelTreeRole1ExactLaneBitMismatchRejected : parallelTreeRole1ExactLaneBitMismatch.check = false := by
  decide

def parallelTreeRole2 : Hibana.ProjectionCertificate := {
  role := 2
  choreo := parallelTree
  topology := {
  events := [
    { action := .recv 0 2 0 },
    { action := .recv 0 4 0 },
    { action := .recv 0 6 0 },
    { action := .recv 0 8 0 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem parallelTreeRole2Accepted : parallelTreeRole2.check = true := by
  decide

theorem parallelTreeRole2RefinesTopology : parallelTreeRole2.RefinesTopology :=
  Hibana.projection_certificate_sound parallelTreeRole2Accepted

def parallelTreeRole2Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 2
    logicalLaneCount := 8
    activeLaneCount := 4
    endpointLaneSlotCount := 8
    maxRouteCommitCount := 0
    firstActiveLane := 1
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 21
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 1, 0, 1, 3, 0, 0, 0, 0, 0, 2, 0, 2, 4, 0, 0, 0, 0, 0, 3, 0, 1, 5, 0, 0, 0, 0, 0, 4, 0, 2, 6, 0, 0, 0, 0, 0, 5, 0, 1, 7, 0, 0, 0, 0, 0, 6, 0, 2, 8, 0, 0, 0, 0, 0, 7, 0, 1, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 64, 0, 1, 0, 2, 64, 1, 2, 0, 2, 64, 2, 2, 0, 3, 64, 0, 2, 0, 1, 64, 1, 3, 0, 3, 64, 1, 4, 0, 3, 64, 2, 4, 0, 1, 64, 2, 4, 0, 4, 64, 0, 4, 0, 5, 64, 0, 4, 0, 0, 64, 1, 5, 0, 5, 64, 1, 6, 0, 5, 64, 2, 6, 0, 6, 64, 0, 6, 0, 4, 64, 1, 7, 0, 6, 64, 1, 8, 0, 6, 64, 2, 8, 0, 4, 64, 2, 8, 0, 0, 64, 2]
    roleBytes := [1, 0, 255, 255, 255, 255, 2, 64, 0, 0, 3, 0, 255, 255, 255, 255, 3, 64, 0, 0, 5, 0, 255, 255, 255, 255, 5, 64, 0, 0, 7, 0, 255, 255, 255, 255, 6, 64, 0, 0, 1, 3, 5, 7, 0, 0, 4, 0, 170]
  }
  choreo := parallelTree
}

theorem parallelTreeRole2ExactAccepted : parallelTreeRole2Exact.check = true := by
  decide

theorem parallelTreeRole2ExactRefines : parallelTreeRole2Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelTreeRole2ExactAccepted

def parallelTreeRole2ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := parallelTreeRole2Exact.image.roleBytes.set parallelTreeRole2Exact.image.roleLaneOffset 2
  }
}

theorem parallelTreeRole2ExactLaneMismatchRejected : parallelTreeRole2ExactLaneMismatch.check = false := by
  decide

def parallelTreeRole2ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := parallelTreeRole2Exact.image.roleBytes.set 0 2
  }
}

theorem parallelTreeRole2ExactEffIndexMismatchRejected : parallelTreeRole2ExactEffIndexMismatch.check = false := by
  decide

def parallelTreeRole2ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := parallelTreeRole2Exact.image.roleBytes.set 8 1
  }
}

theorem parallelTreeRole2ExactFrameLabelMismatchRejected : parallelTreeRole2ExactFrameLabelMismatch.check = false := by
  decide

def parallelTreeRole2ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := (parallelTreeRole2Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelTreeRole2ExactEventScopeMismatchRejected : parallelTreeRole2ExactEventScopeMismatch.check = false := by
  decide

def parallelTreeRole2ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := parallelTreeRole2Exact.image.roleBytes.set 9 1
  }
}

theorem parallelTreeRole2ExactEventFlagMismatchRejected : parallelTreeRole2ExactEventFlagMismatch.check = false := by
  decide

def parallelTreeRole2ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    programBytes := parallelTreeRole2Exact.image.programBytes.set 4 1
  }
}

theorem parallelTreeRole2ExactGlobalActionMismatchRejected : parallelTreeRole2ExactGlobalActionMismatch.check = false := by
  decide

def parallelTreeRole2ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    programBytes := parallelTreeRole2Exact.image.programBytes.set 9 1
  }
}

theorem parallelTreeRole2ExactGlobalOriginMismatchRejected : parallelTreeRole2ExactGlobalOriginMismatch.check = false := by
  decide

def parallelTreeRole2ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    programBytes := parallelTreeRole2Exact.image.programBytes.set 10 3
  }
}

theorem parallelTreeRole2ExactGlobalLaneMismatchRejected : parallelTreeRole2ExactGlobalLaneMismatch.check = false := by
  decide

def parallelTreeRole2ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    programBytes := parallelTreeRole2Exact.image.programBytes.set (parallelTreeRole2Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelTreeRole2ExactScopeMarkerMismatchRejected : parallelTreeRole2ExactScopeMarkerMismatch.check = false := by
  decide

def parallelTreeRole2ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    logicalLaneCount := 9
  }
}

theorem parallelTreeRole2ExactLogicalLaneCountMismatchRejected : parallelTreeRole2ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelTreeRole2ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelTreeRole2Exact with
  image := { parallelTreeRole2Exact.image with
    roleBytes := parallelTreeRole2Exact.image.roleBytes.set parallelTreeRole2Exact.image.roleLaneBitOffset 171
  }
}

theorem parallelTreeRole2ExactLaneBitMismatchRejected : parallelTreeRole2ExactLaneBitMismatch.check = false := by
  decide

def parallelIndependentRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := parallelIndependent
  topology := {
  events := [
    { action := .recv 1 5 0 },
    { action := .send 1 6 0 },
    { action := .recv 1 7 0 },
    { action := .send 1 8 0 },
    { action := .send 2 12 0 },
    { action := .send 2 13 0 },
    { action := .send 2 9 0 },
    { action := .recv 2 10 0 },
    { action := .recv 2 11 0 }
  ],
  rolls := [
    { events := [0, 1, 2, 3] },
    { events := [6, 7, 8] }
  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [0, 1], rightEvents := [2, 3], reentry := .rolled },
    { conflict := 1, authority := .intrinsic, leftEvents := [7], rightEvents := [8], reentry := .rolled }
  ]
}
}

theorem parallelIndependentRole0Accepted : parallelIndependentRole0.check = true := by
  decide

theorem parallelIndependentRole0RefinesTopology : parallelIndependentRole0.RefinesTopology :=
  Hibana.projection_certificate_sound parallelIndependentRole0Accepted

def parallelIndependentRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 0
    logicalLaneCount := 4
    activeLaneCount := 4
    endpointLaneSlotCount := 4
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 2
    routeParticipantCount := 8
    scopeMarkerCount := 21
    eventCount := 9
    dependencyRowCount := 0
    conflictRowCount := 6
    routeScopeCount := 2
    residentBoundaryCount := 2
    laneBitCount := 7
    routeArmLaneStepCount := 4
    routeCommitRowCount := 4
    rollScopeCount := 2
    programBytes := [1, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 2, 12, 0, 0, 0, 0, 0, 1, 0, 2, 13, 0, 0, 0, 0, 0, 2, 0, 2, 9, 0, 0, 0, 0, 0, 3, 2, 0, 10, 0, 0, 0, 0, 0, 3, 2, 0, 11, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 1, 0, 0, 1, 6, 0, 0, 0, 2, 4, 0, 1, 0, 1, 0, 1, 0, 2, 0, 2, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 32, 0, 0, 0, 3, 0, 4, 2, 0, 3, 0, 2, 2, 0, 3, 0, 4, 4, 0, 3, 0, 2, 4, 0, 2, 32, 2, 4, 0, 4, 64, 0, 4, 0, 1, 64, 1, 5, 0, 4, 64, 1, 6, 0, 4, 64, 2, 6, 0, 1, 64, 2, 6, 0, 5, 32, 0, 6, 0, 0, 64, 1, 7, 0, 6, 0, 4, 8, 0, 6, 0, 2, 8, 0, 6, 0, 4, 9, 0, 6, 0, 2, 9, 0, 5, 32, 2, 9, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 3, 0, 0, 1, 1, 0, 255, 255, 1, 0, 3, 0, 0, 0, 2, 0, 255, 255, 2, 0, 3, 0, 1, 1, 3, 0, 255, 255, 3, 0, 3, 0, 1, 0, 4, 0, 255, 255, 255, 255, 4, 64, 0, 0, 5, 0, 255, 255, 255, 255, 4, 64, 0, 0, 6, 0, 255, 255, 255, 255, 5, 32, 0, 0, 7, 0, 255, 255, 4, 0, 6, 0, 0, 1, 8, 0, 255, 255, 5, 0, 6, 0, 1, 1, 0, 0, 0, 0, 1, 2, 3, 3, 3, 6, 0, 6, 0, 7, 0, 7, 0, 12, 0, 13, 0, 3, 0, 6, 0, 0, 192, 0, 192, 2, 0, 0, 0, 255, 255, 0, 0, 2, 0, 2, 0, 255, 255, 0, 0, 1, 0, 7, 0, 255, 255, 0, 0, 1, 0, 8, 0, 255, 255, 0, 0, 0, 0, 9, 0, 15, 1, 1, 1, 8, 8, 8, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 5, 0, 1, 0, 3, 0, 1, 0, 6, 0, 0, 0, 0, 1, 0, 0, 2, 0, 3, 0, 3, 7, 0, 7, 0, 3, 8, 0, 8, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 6, 0, 7, 0, 12, 0, 13, 0, 2, 0, 4, 0, 0, 0, 5, 0, 3, 0, 6, 0]
  }
  choreo := parallelIndependent
}

theorem parallelIndependentRole0ExactAccepted : parallelIndependentRole0Exact.check = true := by
  decide

theorem parallelIndependentRole0ExactRefines : parallelIndependentRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelIndependentRole0ExactAccepted

def parallelIndependentRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set parallelIndependentRole0Exact.image.roleLaneOffset 1
  }
}

theorem parallelIndependentRole0ExactLaneMismatchRejected : parallelIndependentRole0ExactLaneMismatch.check = false := by
  decide

def parallelIndependentRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set 0 1
  }
}

theorem parallelIndependentRole0ExactEffIndexMismatchRejected : parallelIndependentRole0ExactEffIndexMismatch.check = false := by
  decide

def parallelIndependentRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set 8 1
  }
}

theorem parallelIndependentRole0ExactFrameLabelMismatchRejected : parallelIndependentRole0ExactFrameLabelMismatch.check = false := by
  decide

def parallelIndependentRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := (parallelIndependentRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelIndependentRole0ExactEventScopeMismatchRejected : parallelIndependentRole0ExactEventScopeMismatch.check = false := by
  decide

def parallelIndependentRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set 9 0
  }
}

theorem parallelIndependentRole0ExactEventFlagMismatchRejected : parallelIndependentRole0ExactEventFlagMismatch.check = false := by
  decide

def parallelIndependentRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set 4 1
  }
}

theorem parallelIndependentRole0ExactGlobalActionMismatchRejected : parallelIndependentRole0ExactGlobalActionMismatch.check = false := by
  decide

def parallelIndependentRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set 9 1
  }
}

theorem parallelIndependentRole0ExactGlobalOriginMismatchRejected : parallelIndependentRole0ExactGlobalOriginMismatch.check = false := by
  decide

def parallelIndependentRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set 10 2
  }
}

theorem parallelIndependentRole0ExactGlobalLaneMismatchRejected : parallelIndependentRole0ExactGlobalLaneMismatch.check = false := by
  decide

def parallelIndependentRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set (parallelIndependentRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelIndependentRole0ExactScopeMarkerMismatchRejected : parallelIndependentRole0ExactScopeMarkerMismatch.check = false := by
  decide

def parallelIndependentRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set (parallelIndependentRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem parallelIndependentRole0ExactRouteMismatchRejected : parallelIndependentRole0ExactRouteMismatch.check = false := by
  decide

def parallelIndependentRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    logicalLaneCount := 5
  }
}

theorem parallelIndependentRole0ExactLogicalLaneCountMismatchRejected : parallelIndependentRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelIndependentRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set parallelIndependentRole0Exact.image.roleLaneBitOffset 14
  }
}

theorem parallelIndependentRole0ExactLaneBitMismatchRejected : parallelIndependentRole0ExactLaneBitMismatch.check = false := by
  decide

def parallelIndependentRole0ExactRouteArmLaneStepMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set parallelIndependentRole0Exact.image.roleRouteArmLaneStepOffset 1
  }
}

theorem parallelIndependentRole0ExactRouteArmLaneStepMismatchRejected : parallelIndependentRole0ExactRouteArmLaneStepMismatch.check = false := by
  decide

-- Self-child rejection: the retained slot-zero route points to itself; event range, lane length and reserved bytes are unchanged.
def parallelIndependentRole0ExactRouteChildMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := (parallelIndependentRole0Exact.image.roleBytes.set (parallelIndependentRole0Exact.image.roleRouteArmOffset + 4) 0).set (parallelIndependentRole0Exact.image.roleRouteArmOffset + 5) 0
  }
}

theorem parallelIndependentRole0ExactRouteChildMismatchRejected : parallelIndependentRole0ExactRouteChildMismatch.check = false := by
  decide

def parallelIndependentRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set parallelIndependentRole0Exact.image.roleRouteCommitRowOffset 7
  }
}

theorem parallelIndependentRole0ExactRouteCommitMismatchRejected : parallelIndependentRole0ExactRouteCommitMismatch.check = false := by
  decide

def parallelIndependentRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set (parallelIndependentRole0Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem parallelIndependentRole0ExactResolverMismatchRejected : parallelIndependentRole0ExactResolverMismatch.check = false := by
  decide

def parallelIndependentRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    programBytes := parallelIndependentRole0Exact.image.programBytes.set (parallelIndependentRole0Exact.image.programRouteResolverOffset + 4) 2
  }
}

theorem parallelIndependentRole0ExactControllerMismatchRejected : parallelIndependentRole0ExactControllerMismatch.check = false := by
  decide

def parallelIndependentRole0ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole0Exact with
  image := { parallelIndependentRole0Exact.image with
    roleBytes := parallelIndependentRole0Exact.image.roleBytes.set parallelIndependentRole0Exact.image.roleRollScopeOffset 3
  }
}

theorem parallelIndependentRole0ExactRollMismatchRejected : parallelIndependentRole0ExactRollMismatch.check = false := by
  decide

def parallelIndependentRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := parallelIndependent
  topology := {
  events := [
    { action := .send 0 5 0 },
    { action := .recv 0 6 0 },
    { action := .send 0 7 0 },
    { action := .recv 0 8 0 }
  ],
  rolls := [
    { events := [0, 1, 2, 3] }
  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [0, 1], rightEvents := [2, 3], reentry := .rolled }
  ]
}
}

theorem parallelIndependentRole1Accepted : parallelIndependentRole1.check = true := by
  decide

theorem parallelIndependentRole1RefinesTopology : parallelIndependentRole1.RefinesTopology :=
  Hibana.projection_certificate_sound parallelIndependentRole1Accepted

def parallelIndependentRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 2
    routeParticipantCount := 8
    scopeMarkerCount := 21
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 4
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [1, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 2, 12, 0, 0, 0, 0, 0, 1, 0, 2, 13, 0, 0, 0, 0, 0, 2, 0, 2, 9, 0, 0, 0, 0, 0, 3, 2, 0, 10, 0, 0, 0, 0, 0, 3, 2, 0, 11, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 1, 0, 0, 1, 6, 0, 0, 0, 2, 4, 0, 1, 0, 1, 0, 1, 0, 2, 0, 2, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 32, 0, 0, 0, 3, 0, 4, 2, 0, 3, 0, 2, 2, 0, 3, 0, 4, 4, 0, 3, 0, 2, 4, 0, 2, 32, 2, 4, 0, 4, 64, 0, 4, 0, 1, 64, 1, 5, 0, 4, 64, 1, 6, 0, 4, 64, 2, 6, 0, 1, 64, 2, 6, 0, 5, 32, 0, 6, 0, 0, 64, 1, 7, 0, 6, 0, 4, 8, 0, 6, 0, 2, 8, 0, 6, 0, 4, 9, 0, 6, 0, 2, 9, 0, 5, 32, 2, 9, 0, 0, 64, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 3, 0, 0, 0, 1, 0, 255, 255, 1, 0, 3, 0, 0, 1, 2, 0, 255, 255, 2, 0, 3, 0, 1, 0, 3, 0, 255, 255, 3, 0, 3, 0, 1, 1, 0, 0, 0, 0, 6, 0, 6, 0, 7, 0, 7, 0, 3, 0, 0, 192, 2, 0, 0, 0, 255, 255, 0, 0, 2, 0, 2, 0, 255, 255, 0, 0, 0, 0, 4, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 1, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 1, 0, 1, 0, 6, 0, 7, 0, 2, 0, 4, 0, 0, 0]
  }
  choreo := parallelIndependent
}

theorem parallelIndependentRole1ExactAccepted : parallelIndependentRole1Exact.check = true := by
  decide

theorem parallelIndependentRole1ExactRefines : parallelIndependentRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelIndependentRole1ExactAccepted

def parallelIndependentRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set parallelIndependentRole1Exact.image.roleLaneOffset 1
  }
}

theorem parallelIndependentRole1ExactLaneMismatchRejected : parallelIndependentRole1ExactLaneMismatch.check = false := by
  decide

def parallelIndependentRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set 0 1
  }
}

theorem parallelIndependentRole1ExactEffIndexMismatchRejected : parallelIndependentRole1ExactEffIndexMismatch.check = false := by
  decide

def parallelIndependentRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set 8 1
  }
}

theorem parallelIndependentRole1ExactFrameLabelMismatchRejected : parallelIndependentRole1ExactFrameLabelMismatch.check = false := by
  decide

def parallelIndependentRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := (parallelIndependentRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelIndependentRole1ExactEventScopeMismatchRejected : parallelIndependentRole1ExactEventScopeMismatch.check = false := by
  decide

def parallelIndependentRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set 9 1
  }
}

theorem parallelIndependentRole1ExactEventFlagMismatchRejected : parallelIndependentRole1ExactEventFlagMismatch.check = false := by
  decide

def parallelIndependentRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set 4 1
  }
}

theorem parallelIndependentRole1ExactGlobalActionMismatchRejected : parallelIndependentRole1ExactGlobalActionMismatch.check = false := by
  decide

def parallelIndependentRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set 9 1
  }
}

theorem parallelIndependentRole1ExactGlobalOriginMismatchRejected : parallelIndependentRole1ExactGlobalOriginMismatch.check = false := by
  decide

def parallelIndependentRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set 10 2
  }
}

theorem parallelIndependentRole1ExactGlobalLaneMismatchRejected : parallelIndependentRole1ExactGlobalLaneMismatch.check = false := by
  decide

def parallelIndependentRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set (parallelIndependentRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelIndependentRole1ExactScopeMarkerMismatchRejected : parallelIndependentRole1ExactScopeMarkerMismatch.check = false := by
  decide

def parallelIndependentRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set (parallelIndependentRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem parallelIndependentRole1ExactRouteMismatchRejected : parallelIndependentRole1ExactRouteMismatch.check = false := by
  decide

def parallelIndependentRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem parallelIndependentRole1ExactLogicalLaneCountMismatchRejected : parallelIndependentRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelIndependentRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set parallelIndependentRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem parallelIndependentRole1ExactLaneBitMismatchRejected : parallelIndependentRole1ExactLaneBitMismatch.check = false := by
  decide

-- Self-child rejection: the retained slot-zero route points to itself; event range, lane length and reserved bytes are unchanged.
def parallelIndependentRole1ExactRouteChildMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := (parallelIndependentRole1Exact.image.roleBytes.set (parallelIndependentRole1Exact.image.roleRouteArmOffset + 4) 0).set (parallelIndependentRole1Exact.image.roleRouteArmOffset + 5) 0
  }
}

theorem parallelIndependentRole1ExactRouteChildMismatchRejected : parallelIndependentRole1ExactRouteChildMismatch.check = false := by
  decide

def parallelIndependentRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set parallelIndependentRole1Exact.image.roleRouteCommitRowOffset 7
  }
}

theorem parallelIndependentRole1ExactRouteCommitMismatchRejected : parallelIndependentRole1ExactRouteCommitMismatch.check = false := by
  decide

def parallelIndependentRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set (parallelIndependentRole1Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem parallelIndependentRole1ExactResolverMismatchRejected : parallelIndependentRole1ExactResolverMismatch.check = false := by
  decide

def parallelIndependentRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    programBytes := parallelIndependentRole1Exact.image.programBytes.set (parallelIndependentRole1Exact.image.programRouteResolverOffset + 4) 2
  }
}

theorem parallelIndependentRole1ExactControllerMismatchRejected : parallelIndependentRole1ExactControllerMismatch.check = false := by
  decide

def parallelIndependentRole1ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole1Exact with
  image := { parallelIndependentRole1Exact.image with
    roleBytes := parallelIndependentRole1Exact.image.roleBytes.set parallelIndependentRole1Exact.image.roleRollScopeOffset 3
  }
}

theorem parallelIndependentRole1ExactRollMismatchRejected : parallelIndependentRole1ExactRollMismatch.check = false := by
  decide

def parallelIndependentRole2 : Hibana.ProjectionCertificate := {
  role := 2
  choreo := parallelIndependent
  topology := {
  events := [
    { action := .recv 0 12 0 },
    { action := .recv 0 13 0 },
    { action := .recv 0 9 0 },
    { action := .send 0 10 0 },
    { action := .send 0 11 0 }
  ],
  rolls := [
    { events := [2, 3, 4] }
  ],
  routes := [
    { conflict := 1, authority := .intrinsic, leftEvents := [3], rightEvents := [4], reentry := .rolled }
  ]
}
}

theorem parallelIndependentRole2Accepted : parallelIndependentRole2.check = true := by
  decide

theorem parallelIndependentRole2RefinesTopology : parallelIndependentRole2.RefinesTopology :=
  Hibana.projection_certificate_sound parallelIndependentRole2Accepted

def parallelIndependentRole2Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 2
    logicalLaneCount := 4
    activeLaneCount := 3
    endpointLaneSlotCount := 4
    maxRouteCommitCount := 1
    firstActiveLane := 1
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 9
    routeResolverCount := 2
    routeParticipantCount := 8
    scopeMarkerCount := 21
    eventCount := 5
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [1, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 2, 12, 0, 0, 0, 0, 0, 1, 0, 2, 13, 0, 0, 0, 0, 0, 2, 0, 2, 9, 0, 0, 0, 0, 0, 3, 2, 0, 10, 0, 0, 0, 0, 0, 3, 2, 0, 11, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 1, 0, 0, 1, 6, 0, 0, 0, 2, 4, 0, 1, 0, 1, 0, 1, 0, 2, 0, 2, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 0, 0, 2, 32, 0, 0, 0, 3, 0, 4, 2, 0, 3, 0, 2, 2, 0, 3, 0, 4, 4, 0, 3, 0, 2, 4, 0, 2, 32, 2, 4, 0, 4, 64, 0, 4, 0, 1, 64, 1, 5, 0, 4, 64, 1, 6, 0, 4, 64, 2, 6, 0, 1, 64, 2, 6, 0, 5, 32, 0, 6, 0, 0, 64, 1, 7, 0, 6, 0, 4, 8, 0, 6, 0, 2, 8, 0, 6, 0, 4, 9, 0, 6, 0, 2, 9, 0, 5, 32, 2, 9, 0, 0, 64, 2]
    roleBytes := [4, 0, 255, 255, 255, 255, 4, 64, 0, 0, 5, 0, 255, 255, 255, 255, 4, 64, 0, 0, 6, 0, 255, 255, 255, 255, 5, 32, 0, 0, 7, 0, 255, 255, 0, 0, 6, 0, 0, 0, 8, 0, 255, 255, 1, 0, 6, 0, 1, 0, 1, 2, 3, 3, 3, 12, 0, 13, 0, 6, 0, 0, 192, 1, 0, 3, 0, 255, 255, 0, 0, 1, 0, 4, 0, 255, 255, 0, 0, 0, 0, 5, 0, 14, 8, 8, 8, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 3, 3, 0, 3, 0, 3, 4, 0, 4, 0, 1, 0, 0, 0, 1, 0, 1, 0, 12, 0, 13, 0, 5, 0, 3, 0, 2, 0]
  }
  choreo := parallelIndependent
}

theorem parallelIndependentRole2ExactAccepted : parallelIndependentRole2Exact.check = true := by
  decide

theorem parallelIndependentRole2ExactRefines : parallelIndependentRole2Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound parallelIndependentRole2ExactAccepted

def parallelIndependentRole2ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set parallelIndependentRole2Exact.image.roleLaneOffset 2
  }
}

theorem parallelIndependentRole2ExactLaneMismatchRejected : parallelIndependentRole2ExactLaneMismatch.check = false := by
  decide

def parallelIndependentRole2ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set 0 5
  }
}

theorem parallelIndependentRole2ExactEffIndexMismatchRejected : parallelIndependentRole2ExactEffIndexMismatch.check = false := by
  decide

def parallelIndependentRole2ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set 8 1
  }
}

theorem parallelIndependentRole2ExactFrameLabelMismatchRejected : parallelIndependentRole2ExactFrameLabelMismatch.check = false := by
  decide

def parallelIndependentRole2ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := (parallelIndependentRole2Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem parallelIndependentRole2ExactEventScopeMismatchRejected : parallelIndependentRole2ExactEventScopeMismatch.check = false := by
  decide

def parallelIndependentRole2ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set 9 1
  }
}

theorem parallelIndependentRole2ExactEventFlagMismatchRejected : parallelIndependentRole2ExactEventFlagMismatch.check = false := by
  decide

def parallelIndependentRole2ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set 4 1
  }
}

theorem parallelIndependentRole2ExactGlobalActionMismatchRejected : parallelIndependentRole2ExactGlobalActionMismatch.check = false := by
  decide

def parallelIndependentRole2ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set 9 1
  }
}

theorem parallelIndependentRole2ExactGlobalOriginMismatchRejected : parallelIndependentRole2ExactGlobalOriginMismatch.check = false := by
  decide

def parallelIndependentRole2ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set 10 2
  }
}

theorem parallelIndependentRole2ExactGlobalLaneMismatchRejected : parallelIndependentRole2ExactGlobalLaneMismatch.check = false := by
  decide

def parallelIndependentRole2ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set (parallelIndependentRole2Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem parallelIndependentRole2ExactScopeMarkerMismatchRejected : parallelIndependentRole2ExactScopeMarkerMismatch.check = false := by
  decide

def parallelIndependentRole2ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set (parallelIndependentRole2Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem parallelIndependentRole2ExactRouteMismatchRejected : parallelIndependentRole2ExactRouteMismatch.check = false := by
  decide

def parallelIndependentRole2ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    logicalLaneCount := 5
  }
}

theorem parallelIndependentRole2ExactLogicalLaneCountMismatchRejected : parallelIndependentRole2ExactLogicalLaneCountMismatch.check = false := by
  decide

def parallelIndependentRole2ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set parallelIndependentRole2Exact.image.roleLaneBitOffset 15
  }
}

theorem parallelIndependentRole2ExactLaneBitMismatchRejected : parallelIndependentRole2ExactLaneBitMismatch.check = false := by
  decide

def parallelIndependentRole2ExactRouteArmLaneStepMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set parallelIndependentRole2Exact.image.roleRouteArmLaneStepOffset 0
  }
}

theorem parallelIndependentRole2ExactRouteArmLaneStepMismatchRejected : parallelIndependentRole2ExactRouteArmLaneStepMismatch.check = false := by
  decide

-- Self-child rejection: the retained slot-zero route points to itself; event range, lane length and reserved bytes are unchanged.
def parallelIndependentRole2ExactRouteChildMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := (parallelIndependentRole2Exact.image.roleBytes.set (parallelIndependentRole2Exact.image.roleRouteArmOffset + 4) 0).set (parallelIndependentRole2Exact.image.roleRouteArmOffset + 5) 0
  }
}

theorem parallelIndependentRole2ExactRouteChildMismatchRejected : parallelIndependentRole2ExactRouteChildMismatch.check = false := by
  decide

def parallelIndependentRole2ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set parallelIndependentRole2Exact.image.roleRouteCommitRowOffset 13
  }
}

theorem parallelIndependentRole2ExactRouteCommitMismatchRejected : parallelIndependentRole2ExactRouteCommitMismatch.check = false := by
  decide

def parallelIndependentRole2ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set (parallelIndependentRole2Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem parallelIndependentRole2ExactResolverMismatchRejected : parallelIndependentRole2ExactResolverMismatch.check = false := by
  decide

def parallelIndependentRole2ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    programBytes := parallelIndependentRole2Exact.image.programBytes.set (parallelIndependentRole2Exact.image.programRouteResolverOffset + 4) 2
  }
}

theorem parallelIndependentRole2ExactControllerMismatchRejected : parallelIndependentRole2ExactControllerMismatch.check = false := by
  decide

def parallelIndependentRole2ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  parallelIndependentRole2Exact with
  image := { parallelIndependentRole2Exact.image with
    roleBytes := parallelIndependentRole2Exact.image.roleBytes.set parallelIndependentRole2Exact.image.roleRollScopeOffset 4
  }
}

theorem parallelIndependentRole2ExactRollMismatchRejected : parallelIndependentRole2ExactRollMismatch.check = false := by
  decide

