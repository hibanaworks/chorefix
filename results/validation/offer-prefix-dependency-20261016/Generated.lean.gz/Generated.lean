import Hibana.MainTheorems

set_option maxRecDepth 100000

def generatedChoreo : Hibana.Choreo :=
  Hibana.Choreo.seq (Hibana.Choreo.par (Hibana.Choreo.send 0 1 11 6) (Hibana.Choreo.send 0 2 12 7)) (Hibana.Choreo.seq (Hibana.Choreo.route .intrinsic (Hibana.Choreo.seq (Hibana.Choreo.send 0 1 21 0) (Hibana.Choreo.send 1 0 22 0)) (Hibana.Choreo.send 0 1 23 0)) (Hibana.Choreo.send 0 3 31 0))

def generatedRolledChoreo : Hibana.Choreo :=
  Hibana.Choreo.roll (Hibana.Choreo.seq (Hibana.Choreo.route .intrinsic (Hibana.Choreo.send 0 1 41 0) (Hibana.Choreo.send 0 1 42 0)) (Hibana.Choreo.send 0 1 43 0))

def generatedNestedRolledChoreo : Hibana.Choreo :=
  Hibana.Choreo.roll (Hibana.Choreo.seq (Hibana.Choreo.roll (Hibana.Choreo.seq (Hibana.Choreo.send 0 1 71 0) (Hibana.Choreo.send 0 1 72 0))) (Hibana.Choreo.send 0 1 73 0))

def generatedResolvedChoreo : Hibana.Choreo :=
  Hibana.Choreo.route (.dynamic 901) (Hibana.Choreo.send 0 1 51 6) (Hibana.Choreo.send 0 1 51 7)

def generatedNestedResolvedChoreo : Hibana.Choreo :=
  Hibana.Choreo.route (.dynamic 902) (Hibana.Choreo.seq (Hibana.Choreo.send 0 1 61 0) (Hibana.Choreo.route (.dynamic 903) (Hibana.Choreo.send 0 1 62 0) (Hibana.Choreo.send 0 1 63 0))) (Hibana.Choreo.send 0 1 64 0)

def generatedRolledResolvedChoreo : Hibana.Choreo :=
  Hibana.Choreo.roll (Hibana.Choreo.route (.dynamic 904) (Hibana.Choreo.send 0 1 81 0) (Hibana.Choreo.send 0 1 82 0))

def generatedRejectingChoreo : Hibana.Choreo :=
  Hibana.Choreo.route (.dynamic 905) (Hibana.Choreo.send 0 1 91 0) (Hibana.Choreo.send 0 1 92 0)

def generatedCyclicRollChoreo : Hibana.Choreo :=
  Hibana.Choreo.roll (Hibana.Choreo.route (.dynamic 906) (Hibana.Choreo.seq (Hibana.Choreo.send 2 0 107 0) (Hibana.Choreo.seq (Hibana.Choreo.send 0 2 101 0) (Hibana.Choreo.seq (Hibana.Choreo.send 2 1 109 0) (Hibana.Choreo.send 1 2 103 0)))) (Hibana.Choreo.seq (Hibana.Choreo.send 2 0 108 0) (Hibana.Choreo.seq (Hibana.Choreo.send 0 2 102 0) (Hibana.Choreo.seq (Hibana.Choreo.send 2 1 110 0) (Hibana.Choreo.send 1 2 104 0)))))

def generatedFullRoleDomainChoreo : Hibana.Choreo :=
  Hibana.Choreo.roll (Hibana.Choreo.route (.dynamic 65535) (Hibana.Choreo.send 254 255 101 6) (Hibana.Choreo.send 254 255 102 6))

def generatedLaneMatchingChoreo : Hibana.Choreo :=
  Hibana.Choreo.par (Hibana.Choreo.par (Hibana.Choreo.send 0 1 111 0) (Hibana.Choreo.send 0 2 112 0)) (Hibana.Choreo.par (Hibana.Choreo.send 3 4 113 0) (Hibana.Choreo.send 2 3 114 0))

def generatedTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 11 6 }, { eventId := 1, action := .send 2 12 7 }], action := .commit { eventId := 1, action := .send 2 12 7 } },
  { enabled := [{ eventId := 0, action := .send 1 11 6 }], action := .commit { eventId := 0, action := .send 1 11 6 } },
  { enabled := [{ eventId := 2, action := .send 1 21 0 }, { eventId := 4, action := .send 1 23 0 }], action := .commit { eventId := 2, action := .send 1 21 0 } },
  { enabled := [{ eventId := 3, action := .recv 1 22 0 }], action := .commit { eventId := 3, action := .recv 1 22 0 } },
  { enabled := [{ eventId := 5, action := .send 3 31 0 }], action := .commit { eventId := 5, action := .send 3 31 0 } },
  { enabled := [], action := .stop }
]

theorem generatedTraceRole0Accepted : Hibana.checkProgramTrace generatedChoreo 0 generatedTraceRole0 = true := by
  decide

theorem generatedTraceRole0Valid :
    (Hibana.projectGraph 0 generatedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedChoreo) .initial generatedTraceRole0 :=
  Hibana.program_trace_checker_sound generatedChoreo 0 generatedTraceRole0 generatedTraceRole0Accepted

def generatedTraceRole1 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .recv 0 11 6 }], action := .commit { eventId := 0, action := .recv 0 11 6 } },
  { enabled := [{ eventId := 1, action := .recv 0 21 0 }, { eventId := 3, action := .recv 0 23 0 }], action := .commit { eventId := 1, action := .recv 0 21 0 } },
  { enabled := [{ eventId := 2, action := .send 0 22 0 }], action := .commit { eventId := 2, action := .send 0 22 0 } },
  { enabled := [], action := .stop }
]

theorem generatedTraceRole1Accepted : Hibana.checkProgramTrace generatedChoreo 1 generatedTraceRole1 = true := by
  decide

theorem generatedTraceRole1Valid :
    (Hibana.projectGraph 1 generatedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 1 generatedChoreo) .initial generatedTraceRole1 :=
  Hibana.program_trace_checker_sound generatedChoreo 1 generatedTraceRole1 generatedTraceRole1Accepted

def generatedTraceRole2 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .recv 0 12 7 }], action := .commit { eventId := 0, action := .recv 0 12 7 } },
  { enabled := [], action := .stop }
]

theorem generatedTraceRole2Accepted : Hibana.checkProgramTrace generatedChoreo 2 generatedTraceRole2 = true := by
  decide

theorem generatedTraceRole2Valid :
    (Hibana.projectGraph 2 generatedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 2 generatedChoreo) .initial generatedTraceRole2 :=
  Hibana.program_trace_checker_sound generatedChoreo 2 generatedTraceRole2 generatedTraceRole2Accepted

def generatedTraceRole3 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .recv 0 31 0 }], action := .commit { eventId := 0, action := .recv 0 31 0 } },
  { enabled := [], action := .stop }
]

theorem generatedTraceRole3Accepted : Hibana.checkProgramTrace generatedChoreo 3 generatedTraceRole3 = true := by
  decide

theorem generatedTraceRole3Valid :
    (Hibana.projectGraph 3 generatedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 3 generatedChoreo) .initial generatedTraceRole3 :=
  Hibana.program_trace_checker_sound generatedChoreo 3 generatedTraceRole3 generatedTraceRole3Accepted

def generatedRolledLeftTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 41 0 }, { eventId := 1, action := .send 1 42 0 }], action := .commit { eventId := 0, action := .send 1 41 0 } },
  { enabled := [{ eventId := 0, action := .send 1 41 0 }, { eventId := 2, action := .send 1 43 0 }], action := .commit { eventId := 2, action := .send 1 43 0 } },
  { enabled := [{ eventId := 0, action := .send 1 41 0 }], action := .commit { eventId := 0, action := .send 1 41 0 } },
  { enabled := [{ eventId := 0, action := .send 1 41 0 }, { eventId := 2, action := .send 1 43 0 }], action := .commit { eventId := 2, action := .send 1 43 0 } },
  { enabled := [{ eventId := 0, action := .send 1 41 0 }], action := .stop }
]

theorem generatedRolledLeftTraceRole0Accepted : Hibana.checkProgramTrace generatedRolledChoreo 0 generatedRolledLeftTraceRole0 = true := by
  decide

theorem generatedRolledLeftTraceRole0Valid :
    (Hibana.projectGraph 0 generatedRolledChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedRolledChoreo) .initial generatedRolledLeftTraceRole0 :=
  Hibana.program_trace_checker_sound generatedRolledChoreo 0 generatedRolledLeftTraceRole0 generatedRolledLeftTraceRole0Accepted

def generatedRolledRightTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 41 0 }, { eventId := 1, action := .send 1 42 0 }], action := .commit { eventId := 1, action := .send 1 42 0 } },
  { enabled := [{ eventId := 1, action := .send 1 42 0 }, { eventId := 2, action := .send 1 43 0 }], action := .commit { eventId := 2, action := .send 1 43 0 } },
  { enabled := [{ eventId := 1, action := .send 1 42 0 }], action := .commit { eventId := 1, action := .send 1 42 0 } },
  { enabled := [{ eventId := 1, action := .send 1 42 0 }, { eventId := 2, action := .send 1 43 0 }], action := .commit { eventId := 2, action := .send 1 43 0 } },
  { enabled := [{ eventId := 1, action := .send 1 42 0 }], action := .stop }
]

theorem generatedRolledRightTraceRole0Accepted : Hibana.checkProgramTrace generatedRolledChoreo 0 generatedRolledRightTraceRole0 = true := by
  decide

theorem generatedRolledRightTraceRole0Valid :
    (Hibana.projectGraph 0 generatedRolledChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedRolledChoreo) .initial generatedRolledRightTraceRole0 :=
  Hibana.program_trace_checker_sound generatedRolledChoreo 0 generatedRolledRightTraceRole0 generatedRolledRightTraceRole0Accepted

def generatedRolledLeftTraceRole1 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .recv 0 41 0 }, { eventId := 1, action := .recv 0 42 0 }], action := .commit { eventId := 0, action := .recv 0 41 0 } },
  { enabled := [{ eventId := 0, action := .recv 0 41 0 }, { eventId := 2, action := .recv 0 43 0 }], action := .commit { eventId := 2, action := .recv 0 43 0 } },
  { enabled := [{ eventId := 0, action := .recv 0 41 0 }], action := .commit { eventId := 0, action := .recv 0 41 0 } },
  { enabled := [{ eventId := 0, action := .recv 0 41 0 }, { eventId := 2, action := .recv 0 43 0 }], action := .commit { eventId := 2, action := .recv 0 43 0 } },
  { enabled := [{ eventId := 0, action := .recv 0 41 0 }], action := .stop }
]

theorem generatedRolledLeftTraceRole1Accepted : Hibana.checkProgramTrace generatedRolledChoreo 1 generatedRolledLeftTraceRole1 = true := by
  decide

theorem generatedRolledLeftTraceRole1Valid :
    (Hibana.projectGraph 1 generatedRolledChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 1 generatedRolledChoreo) .initial generatedRolledLeftTraceRole1 :=
  Hibana.program_trace_checker_sound generatedRolledChoreo 1 generatedRolledLeftTraceRole1 generatedRolledLeftTraceRole1Accepted

def generatedNestedRolledTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 71 0 }], action := .commit { eventId := 0, action := .send 1 71 0 } },
  { enabled := [{ eventId := 1, action := .send 1 72 0 }], action := .commit { eventId := 1, action := .send 1 72 0 } },
  { enabled := [{ eventId := 0, action := .send 1 71 0 }, { eventId := 2, action := .send 1 73 0 }], action := .commit { eventId := 2, action := .send 1 73 0 } },
  { enabled := [{ eventId := 0, action := .send 1 71 0 }], action := .commit { eventId := 0, action := .send 1 71 0 } },
  { enabled := [{ eventId := 1, action := .send 1 72 0 }], action := .commit { eventId := 1, action := .send 1 72 0 } },
  { enabled := [{ eventId := 0, action := .send 1 71 0 }, { eventId := 2, action := .send 1 73 0 }], action := .commit { eventId := 2, action := .send 1 73 0 } },
  { enabled := [{ eventId := 0, action := .send 1 71 0 }], action := .stop }
]

theorem generatedNestedRolledTraceRole0Accepted : Hibana.checkProgramTrace generatedNestedRolledChoreo 0 generatedNestedRolledTraceRole0 = true := by
  decide

theorem generatedNestedRolledTraceRole0Valid :
    (Hibana.projectGraph 0 generatedNestedRolledChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedNestedRolledChoreo) .initial generatedNestedRolledTraceRole0 :=
  Hibana.program_trace_checker_sound generatedNestedRolledChoreo 0 generatedNestedRolledTraceRole0 generatedNestedRolledTraceRole0Accepted

def generatedResolvedLeftTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 51 6 }, { eventId := 1, action := .send 1 51 7 }], action := .resolve 0 901 .left },
  { enabled := [{ eventId := 0, action := .send 1 51 6 }], action := .commit { eventId := 0, action := .send 1 51 6 } },
  { enabled := [], action := .stop }
]

theorem generatedResolvedLeftTraceRole0Accepted : Hibana.checkProgramTrace generatedResolvedChoreo 0 generatedResolvedLeftTraceRole0 = true := by
  decide

theorem generatedResolvedLeftTraceRole0Valid :
    (Hibana.projectGraph 0 generatedResolvedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedResolvedChoreo) .initial generatedResolvedLeftTraceRole0 :=
  Hibana.program_trace_checker_sound generatedResolvedChoreo 0 generatedResolvedLeftTraceRole0 generatedResolvedLeftTraceRole0Accepted

def generatedResolvedRightTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 51 6 }, { eventId := 1, action := .send 1 51 7 }], action := .resolve 0 901 .right },
  { enabled := [{ eventId := 1, action := .send 1 51 7 }], action := .commit { eventId := 1, action := .send 1 51 7 } },
  { enabled := [], action := .stop }
]

theorem generatedResolvedRightTraceRole0Accepted : Hibana.checkProgramTrace generatedResolvedChoreo 0 generatedResolvedRightTraceRole0 = true := by
  decide

theorem generatedResolvedRightTraceRole0Valid :
    (Hibana.projectGraph 0 generatedResolvedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedResolvedChoreo) .initial generatedResolvedRightTraceRole0 :=
  Hibana.program_trace_checker_sound generatedResolvedChoreo 0 generatedResolvedRightTraceRole0 generatedResolvedRightTraceRole0Accepted

def generatedNestedResolvedTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 61 0 }, { eventId := 3, action := .send 1 64 0 }], action := .resolve 0 902 .left },
  { enabled := [{ eventId := 0, action := .send 1 61 0 }], action := .commit { eventId := 0, action := .send 1 61 0 } },
  { enabled := [{ eventId := 1, action := .send 1 62 0 }, { eventId := 2, action := .send 1 63 0 }], action := .resolve 1 903 .right },
  { enabled := [{ eventId := 2, action := .send 1 63 0 }], action := .commit { eventId := 2, action := .send 1 63 0 } },
  { enabled := [], action := .stop }
]

theorem generatedNestedResolvedTraceRole0Accepted : Hibana.checkProgramTrace generatedNestedResolvedChoreo 0 generatedNestedResolvedTraceRole0 = true := by
  decide

theorem generatedNestedResolvedTraceRole0Valid :
    (Hibana.projectGraph 0 generatedNestedResolvedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedNestedResolvedChoreo) .initial generatedNestedResolvedTraceRole0 :=
  Hibana.program_trace_checker_sound generatedNestedResolvedChoreo 0 generatedNestedResolvedTraceRole0 generatedNestedResolvedTraceRole0Accepted

def generatedRolledResolvedTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 81 0 }, { eventId := 1, action := .send 1 82 0 }], action := .resolve 0 904 .left },
  { enabled := [{ eventId := 0, action := .send 1 81 0 }], action := .commit { eventId := 0, action := .send 1 81 0 } },
  { enabled := [{ eventId := 0, action := .send 1 81 0 }], action := .resolve 0 904 .right },
  { enabled := [{ eventId := 1, action := .send 1 82 0 }], action := .commit { eventId := 1, action := .send 1 82 0 } },
  { enabled := [{ eventId := 1, action := .send 1 82 0 }], action := .resolve 0 904 .left },
  { enabled := [{ eventId := 0, action := .send 1 81 0 }], action := .commit { eventId := 0, action := .send 1 81 0 } },
  { enabled := [{ eventId := 0, action := .send 1 81 0 }], action := .stop }
]

theorem generatedRolledResolvedTraceRole0Accepted : Hibana.checkProgramTrace generatedRolledResolvedChoreo 0 generatedRolledResolvedTraceRole0 = true := by
  decide

theorem generatedRolledResolvedTraceRole0Valid :
    (Hibana.projectGraph 0 generatedRolledResolvedChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedRolledResolvedChoreo) .initial generatedRolledResolvedTraceRole0 :=
  Hibana.program_trace_checker_sound generatedRolledResolvedChoreo 0 generatedRolledResolvedTraceRole0 generatedRolledResolvedTraceRole0Accepted

def generatedRejectedTraceRole0 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 1 91 0 }, { eventId := 1, action := .send 1 92 0 }], action := .reject 0 905 }
]

theorem generatedRejectedTraceRole0Accepted : Hibana.checkProgramTrace generatedRejectingChoreo 0 generatedRejectedTraceRole0 = true := by
  decide

theorem generatedRejectedTraceRole0Valid :
    (Hibana.projectGraph 0 generatedRejectingChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 0 generatedRejectingChoreo) .initial generatedRejectedTraceRole0 :=
  Hibana.program_trace_checker_sound generatedRejectingChoreo 0 generatedRejectedTraceRole0 generatedRejectedTraceRole0Accepted

def generatedCyclicRollTraceRole2 : List Hibana.TraceFrame := [
  { enabled := [{ eventId := 0, action := .send 0 107 0 }, { eventId := 4, action := .send 0 108 0 }], action := .resolve 0 906 .left },
  { enabled := [{ eventId := 0, action := .send 0 107 0 }], action := .commit { eventId := 0, action := .send 0 107 0 } },
  { enabled := [{ eventId := 1, action := .recv 0 101 0 }], action := .commit { eventId := 1, action := .recv 0 101 0 } },
  { enabled := [{ eventId := 2, action := .send 1 109 0 }], action := .commit { eventId := 2, action := .send 1 109 0 } },
  { enabled := [{ eventId := 3, action := .recv 1 103 0 }], action := .commit { eventId := 3, action := .recv 1 103 0 } },
  { enabled := [{ eventId := 0, action := .send 0 107 0 }], action := .resolve 0 906 .right },
  { enabled := [{ eventId := 4, action := .send 0 108 0 }], action := .commit { eventId := 4, action := .send 0 108 0 } },
  { enabled := [{ eventId := 5, action := .recv 0 102 0 }], action := .commit { eventId := 5, action := .recv 0 102 0 } },
  { enabled := [{ eventId := 6, action := .send 1 110 0 }], action := .commit { eventId := 6, action := .send 1 110 0 } },
  { enabled := [{ eventId := 7, action := .recv 1 104 0 }], action := .commit { eventId := 7, action := .recv 1 104 0 } },
  { enabled := [{ eventId := 4, action := .send 0 108 0 }], action := .stop }
]

theorem generatedCyclicRollTraceRole2Accepted : Hibana.checkProgramTrace generatedCyclicRollChoreo 2 generatedCyclicRollTraceRole2 = true := by
  decide

theorem generatedCyclicRollTraceRole2Valid :
    (Hibana.projectGraph 2 generatedCyclicRollChoreo).WellFormed /\
      Hibana.ValidTrace (Hibana.projectGraph 2 generatedCyclicRollChoreo) .initial generatedCyclicRollTraceRole2 :=
  Hibana.program_trace_checker_sound generatedCyclicRollChoreo 2 generatedCyclicRollTraceRole2 generatedCyclicRollTraceRole2Accepted

def generatedProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedChoreo
  topology := {
  events := [
    { action := .send 1 11 6 },
    { action := .send 2 12 7 },
    { action := .send 1 21 0 },
    { action := .recv 1 22 0 },
    { action := .send 1 23 0 },
    { action := .send 3 31 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [2, 3], rightEvents := [4], reentry := .singlePass }
  ]
}
}

theorem generatedProjectionRole0Accepted : generatedProjectionRole0.check = true := by
  decide

theorem generatedProjectionRole0RefinesTopology : generatedProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedProjectionRole0Accepted

def generatedProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 4
    role := 0
    logicalLaneCount := 2
    activeLaneCount := 2
    endpointLaneSlotCount := 2
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 7
    eventCount := 6
    dependencyRowCount := 4
    conflictRowCount := 3
    routeScopeCount := 1
    residentBoundaryCount := 3
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 2, 12, 7, 0, 0, 0, 0, 1, 0, 1, 21, 0, 0, 0, 0, 0, 0, 1, 0, 22, 0, 0, 0, 0, 0, 0, 0, 1, 23, 0, 0, 0, 0, 0, 0, 0, 3, 31, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 64, 0, 1, 0, 0, 64, 1, 2, 0, 0, 64, 2, 2, 0, 1, 0, 0, 4, 0, 1, 0, 2, 4, 0, 1, 0, 0, 5, 0, 1, 0, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 0, 64, 0, 0, 1, 0, 255, 255, 255, 255, 0, 64, 0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 1, 0, 1, 0, 1, 0, 0, 1, 4, 0, 2, 0, 2, 0, 1, 0, 1, 0, 5, 0, 3, 0, 255, 255, 255, 255, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 2, 0, 3, 0, 1, 0, 255, 255, 2, 0, 2, 0, 255, 255, 0, 0, 1, 0, 4, 0, 255, 255, 0, 0, 0, 0, 2, 0, 6, 0, 3, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 2, 0, 3, 0, 0, 4, 0, 4, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0]
  }
  choreo := generatedChoreo
}

theorem generatedProjectionRole0ExactAccepted : generatedProjectionRole0Exact.check = true := by
  decide

theorem generatedProjectionRole0ExactRefines : generatedProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedProjectionRole0ExactAccepted

def generatedProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set generatedProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedProjectionRole0ExactLaneMismatchRejected : generatedProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedProjectionRole0ExactEffIndexMismatchRejected : generatedProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedProjectionRole0ExactFrameLabelMismatchRejected : generatedProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := (generatedProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedProjectionRole0ExactEventScopeMismatchRejected : generatedProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedProjectionRole0ExactEventFlagMismatchRejected : generatedProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedProjectionRole0ExactGlobalActionMismatchRejected : generatedProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedProjectionRole0ExactGlobalOriginMismatchRejected : generatedProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set 10 3
  }
}

theorem generatedProjectionRole0ExactGlobalLaneMismatchRejected : generatedProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set (generatedProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedProjectionRole0ExactScopeMarkerMismatchRejected : generatedProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set (generatedProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedProjectionRole0ExactRouteMismatchRejected : generatedProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedProjectionRole0ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set (generatedProjectionRole0Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem generatedProjectionRole0ExactDependencyScopeMismatchRejected : generatedProjectionRole0ExactDependencyScopeMismatch.check = false := by
  decide

def generatedProjectionRole0ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set (generatedProjectionRole0Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem generatedProjectionRole0ExactDependencyConflictMismatchRejected : generatedProjectionRole0ExactDependencyConflictMismatch.check = false := by
  decide

def generatedProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    logicalLaneCount := 3
  }
}

theorem generatedProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set generatedProjectionRole0Exact.image.roleLaneBitOffset 2
  }
}

theorem generatedProjectionRole0ExactLaneBitMismatchRejected : generatedProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedProjectionRole0ExactRouteArmLaneStepMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set generatedProjectionRole0Exact.image.roleRouteArmLaneStepOffset 1
  }
}

theorem generatedProjectionRole0ExactRouteArmLaneStepMismatchRejected : generatedProjectionRole0ExactRouteArmLaneStepMismatch.check = false := by
  decide

def generatedProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    roleBytes := generatedProjectionRole0Exact.image.roleBytes.set generatedProjectionRole0Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedProjectionRole0ExactRouteCommitMismatchRejected : generatedProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set (generatedProjectionRole0Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedProjectionRole0ExactResolverMismatchRejected : generatedProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole0Exact with
  image := { generatedProjectionRole0Exact.image with
    programBytes := generatedProjectionRole0Exact.image.programBytes.set (generatedProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedProjectionRole0ExactControllerMismatchRejected : generatedProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedChoreo
  topology := {
  events := [
    { action := .recv 0 11 6 },
    { action := .recv 0 21 0 },
    { action := .send 0 22 0 },
    { action := .recv 0 23 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [1, 2], rightEvents := [3], reentry := .singlePass }
  ]
}
}

theorem generatedProjectionRole1Accepted : generatedProjectionRole1.check = true := by
  decide

theorem generatedProjectionRole1RefinesTopology : generatedProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedProjectionRole1Accepted

def generatedProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 4
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 7
    eventCount := 4
    dependencyRowCount := 3
    conflictRowCount := 3
    routeScopeCount := 1
    residentBoundaryCount := 3
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 2, 12, 7, 0, 0, 0, 0, 1, 0, 1, 21, 0, 0, 0, 0, 0, 0, 1, 0, 22, 0, 0, 0, 0, 0, 0, 0, 1, 23, 0, 0, 0, 0, 0, 0, 0, 3, 31, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 64, 0, 1, 0, 0, 64, 1, 2, 0, 0, 64, 2, 2, 0, 1, 0, 0, 4, 0, 1, 0, 2, 4, 0, 1, 0, 0, 5, 0, 1, 0, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 0, 64, 0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0, 1, 3, 0, 1, 0, 1, 0, 1, 0, 0, 0, 4, 0, 2, 0, 2, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 2, 0, 3, 0, 1, 0, 255, 255, 2, 0, 1, 0, 255, 255, 0, 0, 1, 0, 3, 0, 255, 255, 0, 0, 0, 0, 1, 0, 4, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 1, 0, 2, 0, 0, 3, 0, 3, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0]
  }
  choreo := generatedChoreo
}

theorem generatedProjectionRole1ExactAccepted : generatedProjectionRole1Exact.check = true := by
  decide

theorem generatedProjectionRole1ExactRefines : generatedProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedProjectionRole1ExactAccepted

def generatedProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set generatedProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedProjectionRole1ExactLaneMismatchRejected : generatedProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedProjectionRole1ExactEffIndexMismatchRejected : generatedProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedProjectionRole1ExactFrameLabelMismatchRejected : generatedProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := (generatedProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedProjectionRole1ExactEventScopeMismatchRejected : generatedProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set 9 1
  }
}

theorem generatedProjectionRole1ExactEventFlagMismatchRejected : generatedProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedProjectionRole1ExactGlobalActionMismatchRejected : generatedProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedProjectionRole1ExactGlobalOriginMismatchRejected : generatedProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set 10 3
  }
}

theorem generatedProjectionRole1ExactGlobalLaneMismatchRejected : generatedProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set (generatedProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedProjectionRole1ExactScopeMarkerMismatchRejected : generatedProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set (generatedProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedProjectionRole1ExactRouteMismatchRejected : generatedProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedProjectionRole1ExactDependencyScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set (generatedProjectionRole1Exact.image.roleDependencyOffset + 4) 1
  }
}

theorem generatedProjectionRole1ExactDependencyScopeMismatchRejected : generatedProjectionRole1ExactDependencyScopeMismatch.check = false := by
  decide

def generatedProjectionRole1ExactDependencyConflictMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set (generatedProjectionRole1Exact.image.roleDependencyOffset + 6) 1
  }
}

theorem generatedProjectionRole1ExactDependencyConflictMismatchRejected : generatedProjectionRole1ExactDependencyConflictMismatch.check = false := by
  decide

def generatedProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set generatedProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedProjectionRole1ExactLaneBitMismatchRejected : generatedProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    roleBytes := generatedProjectionRole1Exact.image.roleBytes.set generatedProjectionRole1Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedProjectionRole1ExactRouteCommitMismatchRejected : generatedProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set (generatedProjectionRole1Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedProjectionRole1ExactResolverMismatchRejected : generatedProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole1Exact with
  image := { generatedProjectionRole1Exact.image with
    programBytes := generatedProjectionRole1Exact.image.programBytes.set (generatedProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedProjectionRole1ExactControllerMismatchRejected : generatedProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedProjectionRole2 : Hibana.ProjectionCertificate := {
  role := 2
  choreo := generatedChoreo
  topology := {
  events := [
    { action := .recv 0 12 7 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem generatedProjectionRole2Accepted : generatedProjectionRole2.check = true := by
  decide

theorem generatedProjectionRole2RefinesTopology : generatedProjectionRole2.RefinesTopology :=
  Hibana.projection_certificate_sound generatedProjectionRole2Accepted

def generatedProjectionRole2Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 4
    role := 2
    logicalLaneCount := 2
    activeLaneCount := 1
    endpointLaneSlotCount := 2
    maxRouteCommitCount := 0
    firstActiveLane := 1
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 7
    eventCount := 1
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 2, 12, 7, 0, 0, 0, 0, 1, 0, 1, 21, 0, 0, 0, 0, 0, 0, 1, 0, 22, 0, 0, 0, 0, 0, 0, 0, 1, 23, 0, 0, 0, 0, 0, 0, 0, 3, 31, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 64, 0, 1, 0, 0, 64, 1, 2, 0, 0, 64, 2, 2, 0, 1, 0, 0, 4, 0, 1, 0, 2, 4, 0, 1, 0, 0, 5, 0, 1, 0, 2]
    roleBytes := [1, 0, 255, 255, 255, 255, 0, 64, 0, 0, 1, 0, 0, 1, 0, 2]
  }
  choreo := generatedChoreo
}

theorem generatedProjectionRole2ExactAccepted : generatedProjectionRole2Exact.check = true := by
  decide

theorem generatedProjectionRole2ExactRefines : generatedProjectionRole2Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedProjectionRole2ExactAccepted

def generatedProjectionRole2ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := generatedProjectionRole2Exact.image.roleBytes.set generatedProjectionRole2Exact.image.roleLaneOffset 2
  }
}

theorem generatedProjectionRole2ExactLaneMismatchRejected : generatedProjectionRole2ExactLaneMismatch.check = false := by
  decide

def generatedProjectionRole2ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := generatedProjectionRole2Exact.image.roleBytes.set 0 2
  }
}

theorem generatedProjectionRole2ExactEffIndexMismatchRejected : generatedProjectionRole2ExactEffIndexMismatch.check = false := by
  decide

def generatedProjectionRole2ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := generatedProjectionRole2Exact.image.roleBytes.set 8 1
  }
}

theorem generatedProjectionRole2ExactFrameLabelMismatchRejected : generatedProjectionRole2ExactFrameLabelMismatch.check = false := by
  decide

def generatedProjectionRole2ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := (generatedProjectionRole2Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedProjectionRole2ExactEventScopeMismatchRejected : generatedProjectionRole2ExactEventScopeMismatch.check = false := by
  decide

def generatedProjectionRole2ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := generatedProjectionRole2Exact.image.roleBytes.set 9 1
  }
}

theorem generatedProjectionRole2ExactEventFlagMismatchRejected : generatedProjectionRole2ExactEventFlagMismatch.check = false := by
  decide

def generatedProjectionRole2ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set 4 1
  }
}

theorem generatedProjectionRole2ExactGlobalActionMismatchRejected : generatedProjectionRole2ExactGlobalActionMismatch.check = false := by
  decide

def generatedProjectionRole2ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set 9 1
  }
}

theorem generatedProjectionRole2ExactGlobalOriginMismatchRejected : generatedProjectionRole2ExactGlobalOriginMismatch.check = false := by
  decide

def generatedProjectionRole2ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set 10 3
  }
}

theorem generatedProjectionRole2ExactGlobalLaneMismatchRejected : generatedProjectionRole2ExactGlobalLaneMismatch.check = false := by
  decide

def generatedProjectionRole2ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set (generatedProjectionRole2Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedProjectionRole2ExactScopeMarkerMismatchRejected : generatedProjectionRole2ExactScopeMarkerMismatch.check = false := by
  decide

-- Zero-route role: a phantom resident route count must be rejected. The local events remain nonempty.
def generatedProjectionRole2ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with routeScopeCount := 1 }
}

theorem generatedProjectionRole2ExactRouteMismatchRejected : generatedProjectionRole2ExactRouteMismatch.check = false := by
  decide

def generatedProjectionRole2ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    logicalLaneCount := 3
  }
}

theorem generatedProjectionRole2ExactLogicalLaneCountMismatchRejected : generatedProjectionRole2ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedProjectionRole2ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    roleBytes := generatedProjectionRole2Exact.image.roleBytes.set generatedProjectionRole2Exact.image.roleLaneBitOffset 3
  }
}

theorem generatedProjectionRole2ExactLaneBitMismatchRejected : generatedProjectionRole2ExactLaneBitMismatch.check = false := by
  decide

-- Zero-route role: zero commit rows cannot reserve phantom route-commit depth.
def generatedProjectionRole2ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with maxRouteCommitCount := 1 }
}

theorem generatedProjectionRole2ExactRouteCommitMismatchRejected : generatedProjectionRole2ExactRouteCommitMismatch.check = false := by
  decide

def generatedProjectionRole2ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set (generatedProjectionRole2Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedProjectionRole2ExactResolverMismatchRejected : generatedProjectionRole2ExactResolverMismatch.check = false := by
  decide

def generatedProjectionRole2ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole2Exact with
  image := { generatedProjectionRole2Exact.image with
    programBytes := generatedProjectionRole2Exact.image.programBytes.set (generatedProjectionRole2Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedProjectionRole2ExactControllerMismatchRejected : generatedProjectionRole2ExactControllerMismatch.check = false := by
  decide

def generatedProjectionRole3 : Hibana.ProjectionCertificate := {
  role := 3
  choreo := generatedChoreo
  topology := {
  events := [
    { action := .recv 0 31 0 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem generatedProjectionRole3Accepted : generatedProjectionRole3.check = true := by
  decide

theorem generatedProjectionRole3RefinesTopology : generatedProjectionRole3.RefinesTopology :=
  Hibana.projection_certificate_sound generatedProjectionRole3Accepted

def generatedProjectionRole3Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 4
    role := 3
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 6
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 7
    eventCount := 1
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 11, 6, 0, 0, 0, 0, 0, 0, 2, 12, 7, 0, 0, 0, 0, 1, 0, 1, 21, 0, 0, 0, 0, 0, 0, 1, 0, 22, 0, 0, 0, 0, 0, 0, 0, 1, 23, 0, 0, 0, 0, 0, 0, 0, 3, 31, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 64, 0, 1, 0, 0, 64, 1, 2, 0, 0, 64, 2, 2, 0, 1, 0, 0, 4, 0, 1, 0, 2, 4, 0, 1, 0, 0, 5, 0, 1, 0, 2]
    roleBytes := [5, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 1, 0, 1]
  }
  choreo := generatedChoreo
}

theorem generatedProjectionRole3ExactAccepted : generatedProjectionRole3Exact.check = true := by
  decide

theorem generatedProjectionRole3ExactRefines : generatedProjectionRole3Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedProjectionRole3ExactAccepted

def generatedProjectionRole3ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := generatedProjectionRole3Exact.image.roleBytes.set generatedProjectionRole3Exact.image.roleLaneOffset 1
  }
}

theorem generatedProjectionRole3ExactLaneMismatchRejected : generatedProjectionRole3ExactLaneMismatch.check = false := by
  decide

def generatedProjectionRole3ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := generatedProjectionRole3Exact.image.roleBytes.set 0 6
  }
}

theorem generatedProjectionRole3ExactEffIndexMismatchRejected : generatedProjectionRole3ExactEffIndexMismatch.check = false := by
  decide

def generatedProjectionRole3ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := generatedProjectionRole3Exact.image.roleBytes.set 8 1
  }
}

theorem generatedProjectionRole3ExactFrameLabelMismatchRejected : generatedProjectionRole3ExactFrameLabelMismatch.check = false := by
  decide

def generatedProjectionRole3ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := (generatedProjectionRole3Exact.image.roleBytes.set 6 0).set 7 0
  }
}

theorem generatedProjectionRole3ExactEventScopeMismatchRejected : generatedProjectionRole3ExactEventScopeMismatch.check = false := by
  decide

def generatedProjectionRole3ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := generatedProjectionRole3Exact.image.roleBytes.set 9 1
  }
}

theorem generatedProjectionRole3ExactEventFlagMismatchRejected : generatedProjectionRole3ExactEventFlagMismatch.check = false := by
  decide

def generatedProjectionRole3ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set 4 1
  }
}

theorem generatedProjectionRole3ExactGlobalActionMismatchRejected : generatedProjectionRole3ExactGlobalActionMismatch.check = false := by
  decide

def generatedProjectionRole3ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set 9 1
  }
}

theorem generatedProjectionRole3ExactGlobalOriginMismatchRejected : generatedProjectionRole3ExactGlobalOriginMismatch.check = false := by
  decide

def generatedProjectionRole3ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set 10 3
  }
}

theorem generatedProjectionRole3ExactGlobalLaneMismatchRejected : generatedProjectionRole3ExactGlobalLaneMismatch.check = false := by
  decide

def generatedProjectionRole3ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set (generatedProjectionRole3Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedProjectionRole3ExactScopeMarkerMismatchRejected : generatedProjectionRole3ExactScopeMarkerMismatch.check = false := by
  decide

-- Zero-route role: a phantom resident route count must be rejected. The local events remain nonempty.
def generatedProjectionRole3ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with routeScopeCount := 1 }
}

theorem generatedProjectionRole3ExactRouteMismatchRejected : generatedProjectionRole3ExactRouteMismatch.check = false := by
  decide

def generatedProjectionRole3ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedProjectionRole3ExactLogicalLaneCountMismatchRejected : generatedProjectionRole3ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedProjectionRole3ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    roleBytes := generatedProjectionRole3Exact.image.roleBytes.set generatedProjectionRole3Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedProjectionRole3ExactLaneBitMismatchRejected : generatedProjectionRole3ExactLaneBitMismatch.check = false := by
  decide

-- Zero-route role: zero commit rows cannot reserve phantom route-commit depth.
def generatedProjectionRole3ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with maxRouteCommitCount := 1 }
}

theorem generatedProjectionRole3ExactRouteCommitMismatchRejected : generatedProjectionRole3ExactRouteCommitMismatch.check = false := by
  decide

def generatedProjectionRole3ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set (generatedProjectionRole3Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedProjectionRole3ExactResolverMismatchRejected : generatedProjectionRole3ExactResolverMismatch.check = false := by
  decide

def generatedProjectionRole3ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedProjectionRole3Exact with
  image := { generatedProjectionRole3Exact.image with
    programBytes := generatedProjectionRole3Exact.image.programBytes.set (generatedProjectionRole3Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedProjectionRole3ExactControllerMismatchRejected : generatedProjectionRole3ExactControllerMismatch.check = false := by
  decide

def generatedRolledProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedRolledChoreo
  topology := {
  events := [
    { action := .send 1 41 0 },
    { action := .send 1 42 0 },
    { action := .send 1 43 0 }
  ],
  rolls := [
    { events := [0, 1, 2] }
  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedRolledProjectionRole0Accepted : generatedRolledProjectionRole0.check = true := by
  decide

theorem generatedRolledProjectionRole0RefinesTopology : generatedRolledProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRolledProjectionRole0Accepted

def generatedRolledProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 3
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [0, 1, 41, 0, 0, 0, 0, 0, 0, 0, 1, 42, 0, 0, 0, 0, 0, 0, 0, 1, 43, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 3, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 0, 1, 0, 255, 255, 1, 0, 1, 0, 1, 0, 2, 0, 255, 255, 255, 255, 0, 32, 2, 0, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 3, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 3, 0, 0, 0]
  }
  choreo := generatedRolledChoreo
}

theorem generatedRolledProjectionRole0ExactAccepted : generatedRolledProjectionRole0Exact.check = true := by
  decide

theorem generatedRolledProjectionRole0ExactRefines : generatedRolledProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRolledProjectionRole0ExactAccepted

def generatedRolledProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set generatedRolledProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedRolledProjectionRole0ExactLaneMismatchRejected : generatedRolledProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRolledProjectionRole0ExactEffIndexMismatchRejected : generatedRolledProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRolledProjectionRole0ExactFrameLabelMismatchRejected : generatedRolledProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := (generatedRolledProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRolledProjectionRole0ExactEventScopeMismatchRejected : generatedRolledProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedRolledProjectionRole0ExactEventFlagMismatchRejected : generatedRolledProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedRolledProjectionRole0ExactGlobalActionMismatchRejected : generatedRolledProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedRolledProjectionRole0ExactGlobalOriginMismatchRejected : generatedRolledProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedRolledProjectionRole0ExactGlobalLaneMismatchRejected : generatedRolledProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set (generatedRolledProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRolledProjectionRole0ExactScopeMarkerMismatchRejected : generatedRolledProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set (generatedRolledProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRolledProjectionRole0ExactRouteMismatchRejected : generatedRolledProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRolledProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedRolledProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set generatedRolledProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRolledProjectionRole0ExactLaneBitMismatchRejected : generatedRolledProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set generatedRolledProjectionRole0Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedRolledProjectionRole0ExactRouteCommitMismatchRejected : generatedRolledProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set (generatedRolledProjectionRole0Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedRolledProjectionRole0ExactResolverMismatchRejected : generatedRolledProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    programBytes := generatedRolledProjectionRole0Exact.image.programBytes.set (generatedRolledProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRolledProjectionRole0ExactControllerMismatchRejected : generatedRolledProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedRolledProjectionRole0ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole0Exact with
  image := { generatedRolledProjectionRole0Exact.image with
    roleBytes := generatedRolledProjectionRole0Exact.image.roleBytes.set generatedRolledProjectionRole0Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedRolledProjectionRole0ExactRollMismatchRejected : generatedRolledProjectionRole0ExactRollMismatch.check = false := by
  decide

def generatedRolledProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedRolledChoreo
  topology := {
  events := [
    { action := .recv 0 41 0 },
    { action := .recv 0 42 0 },
    { action := .recv 0 43 0 }
  ],
  rolls := [
    { events := [0, 1, 2] }
  ],
  routes := [
    { conflict := 0, authority := .intrinsic, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedRolledProjectionRole1Accepted : generatedRolledProjectionRole1.check = true := by
  decide

theorem generatedRolledProjectionRole1RefinesTopology : generatedRolledProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRolledProjectionRole1Accepted

def generatedRolledProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 3
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [0, 1, 41, 0, 0, 0, 0, 0, 0, 0, 1, 42, 0, 0, 0, 0, 0, 0, 0, 1, 43, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 3, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 1, 1, 0, 255, 255, 1, 0, 1, 0, 1, 1, 2, 0, 255, 255, 255, 255, 0, 32, 2, 0, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 3, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 3, 0, 0, 0]
  }
  choreo := generatedRolledChoreo
}

theorem generatedRolledProjectionRole1ExactAccepted : generatedRolledProjectionRole1Exact.check = true := by
  decide

theorem generatedRolledProjectionRole1ExactRefines : generatedRolledProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRolledProjectionRole1ExactAccepted

def generatedRolledProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set generatedRolledProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedRolledProjectionRole1ExactLaneMismatchRejected : generatedRolledProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRolledProjectionRole1ExactEffIndexMismatchRejected : generatedRolledProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRolledProjectionRole1ExactFrameLabelMismatchRejected : generatedRolledProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := (generatedRolledProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRolledProjectionRole1ExactEventScopeMismatchRejected : generatedRolledProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedRolledProjectionRole1ExactEventFlagMismatchRejected : generatedRolledProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedRolledProjectionRole1ExactGlobalActionMismatchRejected : generatedRolledProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedRolledProjectionRole1ExactGlobalOriginMismatchRejected : generatedRolledProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedRolledProjectionRole1ExactGlobalLaneMismatchRejected : generatedRolledProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set (generatedRolledProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRolledProjectionRole1ExactScopeMarkerMismatchRejected : generatedRolledProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set (generatedRolledProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRolledProjectionRole1ExactRouteMismatchRejected : generatedRolledProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRolledProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedRolledProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set generatedRolledProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRolledProjectionRole1ExactLaneBitMismatchRejected : generatedRolledProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set generatedRolledProjectionRole1Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedRolledProjectionRole1ExactRouteCommitMismatchRejected : generatedRolledProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set (generatedRolledProjectionRole1Exact.image.programRouteResolverOffset + 2) 1
  }
}

theorem generatedRolledProjectionRole1ExactResolverMismatchRejected : generatedRolledProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    programBytes := generatedRolledProjectionRole1Exact.image.programBytes.set (generatedRolledProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRolledProjectionRole1ExactControllerMismatchRejected : generatedRolledProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedRolledProjectionRole1ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledProjectionRole1Exact with
  image := { generatedRolledProjectionRole1Exact.image with
    roleBytes := generatedRolledProjectionRole1Exact.image.roleBytes.set generatedRolledProjectionRole1Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedRolledProjectionRole1ExactRollMismatchRejected : generatedRolledProjectionRole1ExactRollMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedNestedRolledChoreo
  topology := {
  events := [
    { action := .send 1 71 0 },
    { action := .send 1 72 0 },
    { action := .send 1 73 0 }
  ],
  rolls := [
    { events := [0, 1] },
    { events := [0, 1, 2] }
  ],
  routes := [

  ]
}
}

theorem generatedNestedRolledProjectionRole0Accepted : generatedNestedRolledProjectionRole0.check = true := by
  decide

theorem generatedNestedRolledProjectionRole0RefinesTopology : generatedNestedRolledProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedNestedRolledProjectionRole0Accepted

def generatedNestedRolledProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 4
    eventCount := 3
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 2
    programBytes := [0, 1, 71, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 73, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0, 1, 32, 0, 2, 0, 1, 32, 2, 3, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 1, 32, 0, 0, 1, 0, 255, 255, 255, 255, 1, 32, 0, 0, 2, 0, 255, 255, 255, 255, 0, 32, 1, 0, 0, 0, 0, 0, 0, 3, 0, 1, 0, 0, 3, 0, 0, 0, 1, 0, 2, 0, 0, 0]
  }
  choreo := generatedNestedRolledChoreo
}

theorem generatedNestedRolledProjectionRole0ExactAccepted : generatedNestedRolledProjectionRole0Exact.check = true := by
  decide

theorem generatedNestedRolledProjectionRole0ExactRefines : generatedNestedRolledProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedNestedRolledProjectionRole0ExactAccepted

def generatedNestedRolledProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set generatedNestedRolledProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactLaneMismatchRejected : generatedNestedRolledProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactEffIndexMismatchRejected : generatedNestedRolledProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactFrameLabelMismatchRejected : generatedNestedRolledProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := (generatedNestedRolledProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedNestedRolledProjectionRole0ExactEventScopeMismatchRejected : generatedNestedRolledProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactEventFlagMismatchRejected : generatedNestedRolledProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    programBytes := generatedNestedRolledProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactGlobalActionMismatchRejected : generatedNestedRolledProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    programBytes := generatedNestedRolledProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactGlobalOriginMismatchRejected : generatedNestedRolledProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    programBytes := generatedNestedRolledProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedNestedRolledProjectionRole0ExactGlobalLaneMismatchRejected : generatedNestedRolledProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    programBytes := generatedNestedRolledProjectionRole0Exact.image.programBytes.set (generatedNestedRolledProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedNestedRolledProjectionRole0ExactScopeMarkerMismatchRejected : generatedNestedRolledProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedNestedRolledProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedNestedRolledProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set generatedNestedRolledProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedNestedRolledProjectionRole0ExactLaneBitMismatchRejected : generatedNestedRolledProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole0ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole0Exact with
  image := { generatedNestedRolledProjectionRole0Exact.image with
    roleBytes := generatedNestedRolledProjectionRole0Exact.image.roleBytes.set generatedNestedRolledProjectionRole0Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedNestedRolledProjectionRole0ExactRollMismatchRejected : generatedNestedRolledProjectionRole0ExactRollMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedNestedRolledChoreo
  topology := {
  events := [
    { action := .recv 0 71 0 },
    { action := .recv 0 72 0 },
    { action := .recv 0 73 0 }
  ],
  rolls := [
    { events := [0, 1] },
    { events := [0, 1, 2] }
  ],
  routes := [

  ]
}
}

theorem generatedNestedRolledProjectionRole1Accepted : generatedNestedRolledProjectionRole1.check = true := by
  decide

theorem generatedNestedRolledProjectionRole1RefinesTopology : generatedNestedRolledProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedNestedRolledProjectionRole1Accepted

def generatedNestedRolledProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 3
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 4
    eventCount := 3
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 2
    programBytes := [0, 1, 71, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 73, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0, 1, 32, 0, 2, 0, 1, 32, 2, 3, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 255, 255, 1, 32, 0, 0, 1, 0, 255, 255, 255, 255, 1, 32, 0, 0, 2, 0, 255, 255, 255, 255, 0, 32, 1, 0, 0, 0, 0, 0, 0, 3, 0, 1, 0, 0, 3, 0, 0, 0, 1, 0, 2, 0, 0, 0]
  }
  choreo := generatedNestedRolledChoreo
}

theorem generatedNestedRolledProjectionRole1ExactAccepted : generatedNestedRolledProjectionRole1Exact.check = true := by
  decide

theorem generatedNestedRolledProjectionRole1ExactRefines : generatedNestedRolledProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedNestedRolledProjectionRole1ExactAccepted

def generatedNestedRolledProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set generatedNestedRolledProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactLaneMismatchRejected : generatedNestedRolledProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactEffIndexMismatchRejected : generatedNestedRolledProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactFrameLabelMismatchRejected : generatedNestedRolledProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := (generatedNestedRolledProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedNestedRolledProjectionRole1ExactEventScopeMismatchRejected : generatedNestedRolledProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set 9 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactEventFlagMismatchRejected : generatedNestedRolledProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    programBytes := generatedNestedRolledProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactGlobalActionMismatchRejected : generatedNestedRolledProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    programBytes := generatedNestedRolledProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactGlobalOriginMismatchRejected : generatedNestedRolledProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    programBytes := generatedNestedRolledProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedNestedRolledProjectionRole1ExactGlobalLaneMismatchRejected : generatedNestedRolledProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    programBytes := generatedNestedRolledProjectionRole1Exact.image.programBytes.set (generatedNestedRolledProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedNestedRolledProjectionRole1ExactScopeMarkerMismatchRejected : generatedNestedRolledProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedNestedRolledProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedNestedRolledProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set generatedNestedRolledProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedNestedRolledProjectionRole1ExactLaneBitMismatchRejected : generatedNestedRolledProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedNestedRolledProjectionRole1ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedRolledProjectionRole1Exact with
  image := { generatedNestedRolledProjectionRole1Exact.image with
    roleBytes := generatedNestedRolledProjectionRole1Exact.image.roleBytes.set generatedNestedRolledProjectionRole1Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedNestedRolledProjectionRole1ExactRollMismatchRejected : generatedNestedRolledProjectionRole1ExactRollMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedResolvedChoreo
  topology := {
  events := [
    { action := .send 1 51 6 },
    { action := .send 1 51 7 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 901, leftEvents := [0], rightEvents := [1], reentry := .singlePass }
  ]
}
}

theorem generatedResolvedProjectionRole0Accepted : generatedResolvedProjectionRole0.check = true := by
  decide

theorem generatedResolvedProjectionRole0RefinesTopology : generatedResolvedProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedResolvedProjectionRole0Accepted

def generatedResolvedProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 4
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 51, 6, 0, 0, 0, 0, 0, 0, 1, 51, 7, 0, 0, 0, 0, 0, 0, 128, 133, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 0, 0, 0, 2, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 1, 0, 255, 255, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 255, 255, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0]
  }
  choreo := generatedResolvedChoreo
}

theorem generatedResolvedProjectionRole0ExactAccepted : generatedResolvedProjectionRole0Exact.check = true := by
  decide

theorem generatedResolvedProjectionRole0ExactRefines : generatedResolvedProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedResolvedProjectionRole0ExactAccepted

def generatedResolvedProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set generatedResolvedProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedResolvedProjectionRole0ExactLaneMismatchRejected : generatedResolvedProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedResolvedProjectionRole0ExactEffIndexMismatchRejected : generatedResolvedProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedResolvedProjectionRole0ExactFrameLabelMismatchRejected : generatedResolvedProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := (generatedResolvedProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedResolvedProjectionRole0ExactEventScopeMismatchRejected : generatedResolvedProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedResolvedProjectionRole0ExactEventFlagMismatchRejected : generatedResolvedProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedResolvedProjectionRole0ExactGlobalActionMismatchRejected : generatedResolvedProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedResolvedProjectionRole0ExactGlobalOriginMismatchRejected : generatedResolvedProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedResolvedProjectionRole0ExactGlobalLaneMismatchRejected : generatedResolvedProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set (generatedResolvedProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedResolvedProjectionRole0ExactScopeMarkerMismatchRejected : generatedResolvedProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set (generatedResolvedProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedResolvedProjectionRole0ExactRouteMismatchRejected : generatedResolvedProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedResolvedProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedResolvedProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set generatedResolvedProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedResolvedProjectionRole0ExactLaneBitMismatchRejected : generatedResolvedProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    roleBytes := generatedResolvedProjectionRole0Exact.image.roleBytes.set generatedResolvedProjectionRole0Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedResolvedProjectionRole0ExactRouteCommitMismatchRejected : generatedResolvedProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set (generatedResolvedProjectionRole0Exact.image.programRouteResolverOffset + 2) 132
  }
}

theorem generatedResolvedProjectionRole0ExactResolverMismatchRejected : generatedResolvedProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedResolvedProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole0Exact with
  image := { generatedResolvedProjectionRole0Exact.image with
    programBytes := generatedResolvedProjectionRole0Exact.image.programBytes.set (generatedResolvedProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedResolvedProjectionRole0ExactControllerMismatchRejected : generatedResolvedProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedResolvedChoreo
  topology := {
  events := [
    { action := .recv 0 51 6 },
    { action := .recv 0 51 7 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 901, leftEvents := [0], rightEvents := [1], reentry := .singlePass }
  ]
}
}

theorem generatedResolvedProjectionRole1Accepted : generatedResolvedProjectionRole1.check = true := by
  decide

theorem generatedResolvedProjectionRole1RefinesTopology : generatedResolvedProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedResolvedProjectionRole1Accepted

def generatedResolvedProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 4
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 51, 6, 0, 0, 0, 0, 0, 0, 1, 51, 7, 0, 0, 0, 0, 0, 0, 128, 133, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 0, 0, 0, 2, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 255, 255, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 255, 255, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0]
  }
  choreo := generatedResolvedChoreo
}

theorem generatedResolvedProjectionRole1ExactAccepted : generatedResolvedProjectionRole1Exact.check = true := by
  decide

theorem generatedResolvedProjectionRole1ExactRefines : generatedResolvedProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedResolvedProjectionRole1ExactAccepted

def generatedResolvedProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set generatedResolvedProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedResolvedProjectionRole1ExactLaneMismatchRejected : generatedResolvedProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedResolvedProjectionRole1ExactEffIndexMismatchRejected : generatedResolvedProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedResolvedProjectionRole1ExactFrameLabelMismatchRejected : generatedResolvedProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := (generatedResolvedProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedResolvedProjectionRole1ExactEventScopeMismatchRejected : generatedResolvedProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedResolvedProjectionRole1ExactEventFlagMismatchRejected : generatedResolvedProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedResolvedProjectionRole1ExactGlobalActionMismatchRejected : generatedResolvedProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedResolvedProjectionRole1ExactGlobalOriginMismatchRejected : generatedResolvedProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedResolvedProjectionRole1ExactGlobalLaneMismatchRejected : generatedResolvedProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set (generatedResolvedProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedResolvedProjectionRole1ExactScopeMarkerMismatchRejected : generatedResolvedProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set (generatedResolvedProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedResolvedProjectionRole1ExactRouteMismatchRejected : generatedResolvedProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedResolvedProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedResolvedProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set generatedResolvedProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedResolvedProjectionRole1ExactLaneBitMismatchRejected : generatedResolvedProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    roleBytes := generatedResolvedProjectionRole1Exact.image.roleBytes.set generatedResolvedProjectionRole1Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedResolvedProjectionRole1ExactRouteCommitMismatchRejected : generatedResolvedProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set (generatedResolvedProjectionRole1Exact.image.programRouteResolverOffset + 2) 132
  }
}

theorem generatedResolvedProjectionRole1ExactResolverMismatchRejected : generatedResolvedProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedResolvedProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedResolvedProjectionRole1Exact with
  image := { generatedResolvedProjectionRole1Exact.image with
    programBytes := generatedResolvedProjectionRole1Exact.image.programBytes.set (generatedResolvedProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedResolvedProjectionRole1ExactControllerMismatchRejected : generatedResolvedProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedNestedResolvedChoreo
  topology := {
  events := [
    { action := .send 1 61 0 },
    { action := .send 1 62 0 },
    { action := .send 1 63 0 },
    { action := .send 1 64 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 902, leftEvents := [0, 1, 2], rightEvents := [3], reentry := .singlePass },
    { conflict := 1, authority := .dynamic 903, leftEvents := [1], rightEvents := [2], reentry := .singlePass }
  ]
}
}

theorem generatedNestedResolvedProjectionRole0Accepted : generatedNestedResolvedProjectionRole0.check = true := by
  decide

theorem generatedNestedResolvedProjectionRole0RefinesTopology : generatedNestedResolvedProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedNestedResolvedProjectionRole0Accepted

def generatedNestedResolvedProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 2
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 4
    routeResolverCount := 2
    routeParticipantCount := 8
    scopeMarkerCount := 8
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 4
    routeScopeCount := 2
    residentBoundaryCount := 2
    laneBitCount := 7
    routeArmLaneStepCount := 4
    routeCommitRowCount := 6
    rollScopeCount := 0
    programBytes := [0, 1, 61, 0, 0, 0, 0, 0, 0, 0, 1, 62, 0, 0, 0, 0, 0, 0, 0, 1, 63, 0, 0, 0, 0, 0, 0, 0, 1, 64, 0, 0, 0, 0, 0, 0, 0, 128, 134, 3, 0, 0, 0, 1, 1, 128, 135, 3, 0, 4, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 2, 0, 1, 0, 2, 2, 0, 1, 0, 0, 3, 0, 1, 0, 2, 3, 0, 0, 0, 2, 3, 0, 0, 0, 0, 4, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 1, 0, 255, 255, 1, 0, 1, 0, 0, 0, 2, 0, 255, 255, 2, 0, 1, 0, 1, 0, 3, 0, 255, 255, 3, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 1, 0, 255, 255, 0, 0, 3, 0, 0, 0, 255, 255, 0, 0, 1, 0, 3, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 1, 0, 2, 0, 255, 255, 0, 0, 0, 0, 4, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 5, 0, 1, 0, 3, 0, 1, 0, 6, 0, 0, 0, 0, 2, 0, 0, 3, 0, 3, 0, 0, 1, 0, 1, 0, 0, 2, 0, 2, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 2, 0, 2, 0, 4, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 3, 0]
  }
  choreo := generatedNestedResolvedChoreo
}

theorem generatedNestedResolvedProjectionRole0ExactAccepted : generatedNestedResolvedProjectionRole0Exact.check = true := by
  decide

theorem generatedNestedResolvedProjectionRole0ExactRefines : generatedNestedResolvedProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedNestedResolvedProjectionRole0ExactAccepted

def generatedNestedResolvedProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set generatedNestedResolvedProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactLaneMismatchRejected : generatedNestedResolvedProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactEffIndexMismatchRejected : generatedNestedResolvedProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactFrameLabelMismatchRejected : generatedNestedResolvedProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := (generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedNestedResolvedProjectionRole0ExactEventScopeMismatchRejected : generatedNestedResolvedProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactEventFlagMismatchRejected : generatedNestedResolvedProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactGlobalActionMismatchRejected : generatedNestedResolvedProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactGlobalOriginMismatchRejected : generatedNestedResolvedProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedNestedResolvedProjectionRole0ExactGlobalLaneMismatchRejected : generatedNestedResolvedProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set (generatedNestedResolvedProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedNestedResolvedProjectionRole0ExactScopeMarkerMismatchRejected : generatedNestedResolvedProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set (generatedNestedResolvedProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedNestedResolvedProjectionRole0ExactRouteMismatchRejected : generatedNestedResolvedProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedNestedResolvedProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedNestedResolvedProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set generatedNestedResolvedProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedNestedResolvedProjectionRole0ExactLaneBitMismatchRejected : generatedNestedResolvedProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

-- Self-child rejection: the retained slot-zero route points to itself; event range, lane length and reserved bytes are unchanged.
def generatedNestedResolvedProjectionRole0ExactRouteChildMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := (generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set (generatedNestedResolvedProjectionRole0Exact.image.roleRouteArmOffset + 4) 0).set (generatedNestedResolvedProjectionRole0Exact.image.roleRouteArmOffset + 5) 0
  }
}

theorem generatedNestedResolvedProjectionRole0ExactRouteChildMismatchRejected : generatedNestedResolvedProjectionRole0ExactRouteChildMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole0Exact.image.roleBytes.set generatedNestedResolvedProjectionRole0Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactRouteCommitMismatchRejected : generatedNestedResolvedProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set (generatedNestedResolvedProjectionRole0Exact.image.programRouteResolverOffset + 2) 135
  }
}

theorem generatedNestedResolvedProjectionRole0ExactResolverMismatchRejected : generatedNestedResolvedProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole0Exact with
  image := { generatedNestedResolvedProjectionRole0Exact.image with
    programBytes := generatedNestedResolvedProjectionRole0Exact.image.programBytes.set (generatedNestedResolvedProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedNestedResolvedProjectionRole0ExactControllerMismatchRejected : generatedNestedResolvedProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedNestedResolvedChoreo
  topology := {
  events := [
    { action := .recv 0 61 0 },
    { action := .recv 0 62 0 },
    { action := .recv 0 63 0 },
    { action := .recv 0 64 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 902, leftEvents := [0, 1, 2], rightEvents := [3], reentry := .singlePass },
    { conflict := 1, authority := .dynamic 903, leftEvents := [1], rightEvents := [2], reentry := .singlePass }
  ]
}
}

theorem generatedNestedResolvedProjectionRole1Accepted : generatedNestedResolvedProjectionRole1.check = true := by
  decide

theorem generatedNestedResolvedProjectionRole1RefinesTopology : generatedNestedResolvedProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedNestedResolvedProjectionRole1Accepted

def generatedNestedResolvedProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 2
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 4
    routeResolverCount := 2
    routeParticipantCount := 8
    scopeMarkerCount := 8
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 4
    routeScopeCount := 2
    residentBoundaryCount := 2
    laneBitCount := 7
    routeArmLaneStepCount := 4
    routeCommitRowCount := 6
    rollScopeCount := 0
    programBytes := [0, 1, 61, 0, 0, 0, 0, 0, 0, 0, 1, 62, 0, 0, 0, 0, 0, 0, 0, 1, 63, 0, 0, 0, 0, 0, 0, 0, 1, 64, 0, 0, 0, 0, 0, 0, 0, 128, 134, 3, 0, 0, 0, 1, 1, 128, 135, 3, 0, 4, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 2, 0, 1, 0, 2, 2, 0, 1, 0, 0, 3, 0, 1, 0, 2, 3, 0, 0, 0, 2, 3, 0, 0, 0, 0, 4, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 255, 255, 1, 0, 1, 0, 0, 1, 2, 0, 255, 255, 2, 0, 1, 0, 1, 1, 3, 0, 255, 255, 3, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 1, 0, 255, 255, 0, 0, 3, 0, 0, 0, 255, 255, 0, 0, 1, 0, 3, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 1, 0, 2, 0, 255, 255, 0, 0, 0, 0, 4, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 5, 0, 1, 0, 3, 0, 1, 0, 6, 0, 0, 0, 0, 2, 0, 0, 3, 0, 3, 0, 0, 1, 0, 1, 0, 0, 2, 0, 2, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 2, 0, 2, 0, 4, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 3, 0]
  }
  choreo := generatedNestedResolvedChoreo
}

theorem generatedNestedResolvedProjectionRole1ExactAccepted : generatedNestedResolvedProjectionRole1Exact.check = true := by
  decide

theorem generatedNestedResolvedProjectionRole1ExactRefines : generatedNestedResolvedProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedNestedResolvedProjectionRole1ExactAccepted

def generatedNestedResolvedProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set generatedNestedResolvedProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactLaneMismatchRejected : generatedNestedResolvedProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactEffIndexMismatchRejected : generatedNestedResolvedProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactFrameLabelMismatchRejected : generatedNestedResolvedProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := (generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedNestedResolvedProjectionRole1ExactEventScopeMismatchRejected : generatedNestedResolvedProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedNestedResolvedProjectionRole1ExactEventFlagMismatchRejected : generatedNestedResolvedProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactGlobalActionMismatchRejected : generatedNestedResolvedProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactGlobalOriginMismatchRejected : generatedNestedResolvedProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedNestedResolvedProjectionRole1ExactGlobalLaneMismatchRejected : generatedNestedResolvedProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set (generatedNestedResolvedProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedNestedResolvedProjectionRole1ExactScopeMarkerMismatchRejected : generatedNestedResolvedProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set (generatedNestedResolvedProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedNestedResolvedProjectionRole1ExactRouteMismatchRejected : generatedNestedResolvedProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedNestedResolvedProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedNestedResolvedProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set generatedNestedResolvedProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedNestedResolvedProjectionRole1ExactLaneBitMismatchRejected : generatedNestedResolvedProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

-- Self-child rejection: the retained slot-zero route points to itself; event range, lane length and reserved bytes are unchanged.
def generatedNestedResolvedProjectionRole1ExactRouteChildMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := (generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set (generatedNestedResolvedProjectionRole1Exact.image.roleRouteArmOffset + 4) 0).set (generatedNestedResolvedProjectionRole1Exact.image.roleRouteArmOffset + 5) 0
  }
}

theorem generatedNestedResolvedProjectionRole1ExactRouteChildMismatchRejected : generatedNestedResolvedProjectionRole1ExactRouteChildMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    roleBytes := generatedNestedResolvedProjectionRole1Exact.image.roleBytes.set generatedNestedResolvedProjectionRole1Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactRouteCommitMismatchRejected : generatedNestedResolvedProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set (generatedNestedResolvedProjectionRole1Exact.image.programRouteResolverOffset + 2) 135
  }
}

theorem generatedNestedResolvedProjectionRole1ExactResolverMismatchRejected : generatedNestedResolvedProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedNestedResolvedProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedNestedResolvedProjectionRole1Exact with
  image := { generatedNestedResolvedProjectionRole1Exact.image with
    programBytes := generatedNestedResolvedProjectionRole1Exact.image.programBytes.set (generatedNestedResolvedProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedNestedResolvedProjectionRole1ExactControllerMismatchRejected : generatedNestedResolvedProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedRolledResolvedChoreo
  topology := {
  events := [
    { action := .send 1 81 0 },
    { action := .send 1 82 0 }
  ],
  rolls := [
    { events := [0, 1] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 904, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedRolledResolvedProjectionRole0Accepted : generatedRolledResolvedProjectionRole0.check = true := by
  decide

theorem generatedRolledResolvedProjectionRole0RefinesTopology : generatedRolledResolvedProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRolledResolvedProjectionRole0Accepted

def generatedRolledResolvedProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [0, 1, 81, 0, 0, 0, 0, 0, 0, 0, 1, 82, 0, 0, 0, 0, 0, 0, 1, 128, 136, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 2, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 0, 1, 0, 255, 255, 1, 0, 1, 0, 1, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 2, 0, 0, 0]
  }
  choreo := generatedRolledResolvedChoreo
}

theorem generatedRolledResolvedProjectionRole0ExactAccepted : generatedRolledResolvedProjectionRole0Exact.check = true := by
  decide

theorem generatedRolledResolvedProjectionRole0ExactRefines : generatedRolledResolvedProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRolledResolvedProjectionRole0ExactAccepted

def generatedRolledResolvedProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set generatedRolledResolvedProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactLaneMismatchRejected : generatedRolledResolvedProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactEffIndexMismatchRejected : generatedRolledResolvedProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactFrameLabelMismatchRejected : generatedRolledResolvedProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := (generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRolledResolvedProjectionRole0ExactEventScopeMismatchRejected : generatedRolledResolvedProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactEventFlagMismatchRejected : generatedRolledResolvedProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactGlobalActionMismatchRejected : generatedRolledResolvedProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactGlobalOriginMismatchRejected : generatedRolledResolvedProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedRolledResolvedProjectionRole0ExactGlobalLaneMismatchRejected : generatedRolledResolvedProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set (generatedRolledResolvedProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRolledResolvedProjectionRole0ExactScopeMarkerMismatchRejected : generatedRolledResolvedProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set (generatedRolledResolvedProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRolledResolvedProjectionRole0ExactRouteMismatchRejected : generatedRolledResolvedProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRolledResolvedProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedRolledResolvedProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set generatedRolledResolvedProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRolledResolvedProjectionRole0ExactLaneBitMismatchRejected : generatedRolledResolvedProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set generatedRolledResolvedProjectionRole0Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedRolledResolvedProjectionRole0ExactRouteCommitMismatchRejected : generatedRolledResolvedProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set (generatedRolledResolvedProjectionRole0Exact.image.programRouteResolverOffset + 2) 137
  }
}

theorem generatedRolledResolvedProjectionRole0ExactResolverMismatchRejected : generatedRolledResolvedProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    programBytes := generatedRolledResolvedProjectionRole0Exact.image.programBytes.set (generatedRolledResolvedProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactControllerMismatchRejected : generatedRolledResolvedProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole0ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole0Exact with
  image := { generatedRolledResolvedProjectionRole0Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole0Exact.image.roleBytes.set generatedRolledResolvedProjectionRole0Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedRolledResolvedProjectionRole0ExactRollMismatchRejected : generatedRolledResolvedProjectionRole0ExactRollMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedRolledResolvedChoreo
  topology := {
  events := [
    { action := .recv 0 81 0 },
    { action := .recv 0 82 0 }
  ],
  rolls := [
    { events := [0, 1] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 904, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedRolledResolvedProjectionRole1Accepted : generatedRolledResolvedProjectionRole1.check = true := by
  decide

theorem generatedRolledResolvedProjectionRole1RefinesTopology : generatedRolledResolvedProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRolledResolvedProjectionRole1Accepted

def generatedRolledResolvedProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [0, 1, 81, 0, 0, 0, 0, 0, 0, 0, 1, 82, 0, 0, 0, 0, 0, 0, 1, 128, 136, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 2, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 1, 1, 0, 255, 255, 1, 0, 1, 0, 1, 1, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 2, 0, 0, 0]
  }
  choreo := generatedRolledResolvedChoreo
}

theorem generatedRolledResolvedProjectionRole1ExactAccepted : generatedRolledResolvedProjectionRole1Exact.check = true := by
  decide

theorem generatedRolledResolvedProjectionRole1ExactRefines : generatedRolledResolvedProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRolledResolvedProjectionRole1ExactAccepted

def generatedRolledResolvedProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set generatedRolledResolvedProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactLaneMismatchRejected : generatedRolledResolvedProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactEffIndexMismatchRejected : generatedRolledResolvedProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactFrameLabelMismatchRejected : generatedRolledResolvedProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := (generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRolledResolvedProjectionRole1ExactEventScopeMismatchRejected : generatedRolledResolvedProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedRolledResolvedProjectionRole1ExactEventFlagMismatchRejected : generatedRolledResolvedProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactGlobalActionMismatchRejected : generatedRolledResolvedProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactGlobalOriginMismatchRejected : generatedRolledResolvedProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedRolledResolvedProjectionRole1ExactGlobalLaneMismatchRejected : generatedRolledResolvedProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set (generatedRolledResolvedProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRolledResolvedProjectionRole1ExactScopeMarkerMismatchRejected : generatedRolledResolvedProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set (generatedRolledResolvedProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRolledResolvedProjectionRole1ExactRouteMismatchRejected : generatedRolledResolvedProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRolledResolvedProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedRolledResolvedProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set generatedRolledResolvedProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRolledResolvedProjectionRole1ExactLaneBitMismatchRejected : generatedRolledResolvedProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set generatedRolledResolvedProjectionRole1Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedRolledResolvedProjectionRole1ExactRouteCommitMismatchRejected : generatedRolledResolvedProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set (generatedRolledResolvedProjectionRole1Exact.image.programRouteResolverOffset + 2) 137
  }
}

theorem generatedRolledResolvedProjectionRole1ExactResolverMismatchRejected : generatedRolledResolvedProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    programBytes := generatedRolledResolvedProjectionRole1Exact.image.programBytes.set (generatedRolledResolvedProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactControllerMismatchRejected : generatedRolledResolvedProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedRolledResolvedProjectionRole1ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRolledResolvedProjectionRole1Exact with
  image := { generatedRolledResolvedProjectionRole1Exact.image with
    roleBytes := generatedRolledResolvedProjectionRole1Exact.image.roleBytes.set generatedRolledResolvedProjectionRole1Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedRolledResolvedProjectionRole1ExactRollMismatchRejected : generatedRolledResolvedProjectionRole1ExactRollMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedRejectingChoreo
  topology := {
  events := [
    { action := .send 1 91 0 },
    { action := .send 1 92 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 905, leftEvents := [0], rightEvents := [1], reentry := .singlePass }
  ]
}
}

theorem generatedRejectingProjectionRole0Accepted : generatedRejectingProjectionRole0.check = true := by
  decide

theorem generatedRejectingProjectionRole0RefinesTopology : generatedRejectingProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRejectingProjectionRole0Accepted

def generatedRejectingProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 4
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 91, 0, 0, 0, 0, 0, 0, 0, 1, 92, 0, 0, 0, 0, 0, 0, 0, 128, 137, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 0, 0, 0, 2, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 1, 0, 255, 255, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 255, 255, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0]
  }
  choreo := generatedRejectingChoreo
}

theorem generatedRejectingProjectionRole0ExactAccepted : generatedRejectingProjectionRole0Exact.check = true := by
  decide

theorem generatedRejectingProjectionRole0ExactRefines : generatedRejectingProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRejectingProjectionRole0ExactAccepted

def generatedRejectingProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set generatedRejectingProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedRejectingProjectionRole0ExactLaneMismatchRejected : generatedRejectingProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRejectingProjectionRole0ExactEffIndexMismatchRejected : generatedRejectingProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRejectingProjectionRole0ExactFrameLabelMismatchRejected : generatedRejectingProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := (generatedRejectingProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRejectingProjectionRole0ExactEventScopeMismatchRejected : generatedRejectingProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set 9 1
  }
}

theorem generatedRejectingProjectionRole0ExactEventFlagMismatchRejected : generatedRejectingProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedRejectingProjectionRole0ExactGlobalActionMismatchRejected : generatedRejectingProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedRejectingProjectionRole0ExactGlobalOriginMismatchRejected : generatedRejectingProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set 10 2
  }
}

theorem generatedRejectingProjectionRole0ExactGlobalLaneMismatchRejected : generatedRejectingProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set (generatedRejectingProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRejectingProjectionRole0ExactScopeMarkerMismatchRejected : generatedRejectingProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set (generatedRejectingProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRejectingProjectionRole0ExactRouteMismatchRejected : generatedRejectingProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRejectingProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedRejectingProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set generatedRejectingProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRejectingProjectionRole0ExactLaneBitMismatchRejected : generatedRejectingProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    roleBytes := generatedRejectingProjectionRole0Exact.image.roleBytes.set generatedRejectingProjectionRole0Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedRejectingProjectionRole0ExactRouteCommitMismatchRejected : generatedRejectingProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set (generatedRejectingProjectionRole0Exact.image.programRouteResolverOffset + 2) 136
  }
}

theorem generatedRejectingProjectionRole0ExactResolverMismatchRejected : generatedRejectingProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedRejectingProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole0Exact with
  image := { generatedRejectingProjectionRole0Exact.image with
    programBytes := generatedRejectingProjectionRole0Exact.image.programBytes.set (generatedRejectingProjectionRole0Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRejectingProjectionRole0ExactControllerMismatchRejected : generatedRejectingProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedRejectingChoreo
  topology := {
  events := [
    { action := .recv 0 91 0 },
    { action := .recv 0 92 0 }
  ],
  rolls := [

  ],
  routes := [
    { conflict := 0, authority := .dynamic 905, leftEvents := [0], rightEvents := [1], reentry := .singlePass }
  ]
}
}

theorem generatedRejectingProjectionRole1Accepted : generatedRejectingProjectionRole1.check = true := by
  decide

theorem generatedRejectingProjectionRole1RefinesTopology : generatedRejectingProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedRejectingProjectionRole1Accepted

def generatedRejectingProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 2
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 4
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 0
    programBytes := [0, 1, 91, 0, 0, 0, 0, 0, 0, 0, 1, 92, 0, 0, 0, 0, 0, 0, 0, 128, 137, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 0, 0, 0, 2, 0, 0, 0, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 255, 255, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 255, 255, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0]
  }
  choreo := generatedRejectingChoreo
}

theorem generatedRejectingProjectionRole1ExactAccepted : generatedRejectingProjectionRole1Exact.check = true := by
  decide

theorem generatedRejectingProjectionRole1ExactRefines : generatedRejectingProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedRejectingProjectionRole1ExactAccepted

def generatedRejectingProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set generatedRejectingProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedRejectingProjectionRole1ExactLaneMismatchRejected : generatedRejectingProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set 0 1
  }
}

theorem generatedRejectingProjectionRole1ExactEffIndexMismatchRejected : generatedRejectingProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedRejectingProjectionRole1ExactFrameLabelMismatchRejected : generatedRejectingProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := (generatedRejectingProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedRejectingProjectionRole1ExactEventScopeMismatchRejected : generatedRejectingProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedRejectingProjectionRole1ExactEventFlagMismatchRejected : generatedRejectingProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedRejectingProjectionRole1ExactGlobalActionMismatchRejected : generatedRejectingProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedRejectingProjectionRole1ExactGlobalOriginMismatchRejected : generatedRejectingProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set 10 2
  }
}

theorem generatedRejectingProjectionRole1ExactGlobalLaneMismatchRejected : generatedRejectingProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set (generatedRejectingProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedRejectingProjectionRole1ExactScopeMarkerMismatchRejected : generatedRejectingProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set (generatedRejectingProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedRejectingProjectionRole1ExactRouteMismatchRejected : generatedRejectingProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedRejectingProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedRejectingProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set generatedRejectingProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedRejectingProjectionRole1ExactLaneBitMismatchRejected : generatedRejectingProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    roleBytes := generatedRejectingProjectionRole1Exact.image.roleBytes.set generatedRejectingProjectionRole1Exact.image.roleRouteCommitRowOffset 1
  }
}

theorem generatedRejectingProjectionRole1ExactRouteCommitMismatchRejected : generatedRejectingProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set (generatedRejectingProjectionRole1Exact.image.programRouteResolverOffset + 2) 136
  }
}

theorem generatedRejectingProjectionRole1ExactResolverMismatchRejected : generatedRejectingProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedRejectingProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedRejectingProjectionRole1Exact with
  image := { generatedRejectingProjectionRole1Exact.image with
    programBytes := generatedRejectingProjectionRole1Exact.image.programBytes.set (generatedRejectingProjectionRole1Exact.image.programRouteResolverOffset + 4) 1
  }
}

theorem generatedRejectingProjectionRole1ExactControllerMismatchRejected : generatedRejectingProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254 : Hibana.ProjectionCertificate := {
  role := 254
  choreo := generatedFullRoleDomainChoreo
  topology := {
  events := [
    { action := .send 255 101 6 },
    { action := .send 255 102 6 }
  ],
  rolls := [
    { events := [0, 1] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 65535, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedFullRoleDomainProjectionRole254Accepted : generatedFullRoleDomainProjectionRole254.check = true := by
  decide

theorem generatedFullRoleDomainProjectionRole254RefinesTopology : generatedFullRoleDomainProjectionRole254.RefinesTopology :=
  Hibana.projection_certificate_sound generatedFullRoleDomainProjectionRole254Accepted

def generatedFullRoleDomainProjectionRole254Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 256
    role := 254
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [254, 255, 101, 6, 0, 0, 0, 0, 0, 254, 255, 102, 6, 0, 0, 0, 0, 0, 1, 128, 255, 255, 254, 0, 0, 1, 254, 255, 254, 255, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 2, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 0, 1, 0, 255, 255, 1, 0, 1, 0, 1, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 2, 0, 0, 0]
  }
  choreo := generatedFullRoleDomainChoreo
}

theorem generatedFullRoleDomainProjectionRole254ExactAccepted : generatedFullRoleDomainProjectionRole254Exact.check = true := by
  decide

theorem generatedFullRoleDomainProjectionRole254ExactRefines : generatedFullRoleDomainProjectionRole254Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedFullRoleDomainProjectionRole254ExactAccepted

def generatedFullRoleDomainProjectionRole254ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole254Exact.image.roleLaneOffset 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactLaneMismatchRejected : generatedFullRoleDomainProjectionRole254ExactLaneMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set 0 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactEffIndexMismatchRejected : generatedFullRoleDomainProjectionRole254ExactEffIndexMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set 8 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactFrameLabelMismatchRejected : generatedFullRoleDomainProjectionRole254ExactFrameLabelMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := (generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactEventScopeMismatchRejected : generatedFullRoleDomainProjectionRole254ExactEventScopeMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set 9 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactEventFlagMismatchRejected : generatedFullRoleDomainProjectionRole254ExactEventFlagMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set 4 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactGlobalActionMismatchRejected : generatedFullRoleDomainProjectionRole254ExactGlobalActionMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set 9 255
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactGlobalOriginMismatchRejected : generatedFullRoleDomainProjectionRole254ExactGlobalOriginMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set 10 0
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactGlobalLaneMismatchRejected : generatedFullRoleDomainProjectionRole254ExactGlobalLaneMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole254Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactScopeMarkerMismatchRejected : generatedFullRoleDomainProjectionRole254ExactScopeMarkerMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set (generatedFullRoleDomainProjectionRole254Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactRouteMismatchRejected : generatedFullRoleDomainProjectionRole254ExactRouteMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactLogicalLaneCountMismatchRejected : generatedFullRoleDomainProjectionRole254ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole254Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactLaneBitMismatchRejected : generatedFullRoleDomainProjectionRole254ExactLaneBitMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole254Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactRouteCommitMismatchRejected : generatedFullRoleDomainProjectionRole254ExactRouteCommitMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole254Exact.image.programRouteResolverOffset + 2) 254
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactResolverMismatchRejected : generatedFullRoleDomainProjectionRole254ExactResolverMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole254Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole254Exact.image.programRouteResolverOffset + 4) 255
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactControllerMismatchRejected : generatedFullRoleDomainProjectionRole254ExactControllerMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole254ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole254Exact with
  image := { generatedFullRoleDomainProjectionRole254Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole254Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole254Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedFullRoleDomainProjectionRole254ExactRollMismatchRejected : generatedFullRoleDomainProjectionRole254ExactRollMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255 : Hibana.ProjectionCertificate := {
  role := 255
  choreo := generatedFullRoleDomainChoreo
  topology := {
  events := [
    { action := .recv 254 101 6 },
    { action := .recv 254 102 6 }
  ],
  rolls := [
    { events := [0, 1] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 65535, leftEvents := [0], rightEvents := [1], reentry := .rolled }
  ]
}
}

theorem generatedFullRoleDomainProjectionRole255Accepted : generatedFullRoleDomainProjectionRole255.check = true := by
  decide

theorem generatedFullRoleDomainProjectionRole255RefinesTopology : generatedFullRoleDomainProjectionRole255.RefinesTopology :=
  Hibana.projection_certificate_sound generatedFullRoleDomainProjectionRole255Accepted

def generatedFullRoleDomainProjectionRole255Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 256
    role := 255
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 2
    routeResolverCount := 1
    routeParticipantCount := 4
    scopeMarkerCount := 6
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 2
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [254, 255, 101, 6, 0, 0, 0, 0, 0, 254, 255, 102, 6, 0, 0, 0, 0, 0, 1, 128, 255, 255, 254, 0, 0, 1, 254, 255, 254, 255, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 1, 0, 1, 0, 2, 1, 0, 1, 0, 4, 2, 0, 1, 0, 2, 2, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 1, 1, 0, 255, 255, 1, 0, 1, 0, 1, 1, 0, 0, 2, 0, 3, 0, 1, 0, 0, 192, 1, 0, 0, 0, 255, 255, 0, 0, 1, 0, 1, 0, 255, 255, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 2, 0, 0, 0]
  }
  choreo := generatedFullRoleDomainChoreo
}

theorem generatedFullRoleDomainProjectionRole255ExactAccepted : generatedFullRoleDomainProjectionRole255Exact.check = true := by
  decide

theorem generatedFullRoleDomainProjectionRole255ExactRefines : generatedFullRoleDomainProjectionRole255Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedFullRoleDomainProjectionRole255ExactAccepted

def generatedFullRoleDomainProjectionRole255ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole255Exact.image.roleLaneOffset 1
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactLaneMismatchRejected : generatedFullRoleDomainProjectionRole255ExactLaneMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set 0 1
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactEffIndexMismatchRejected : generatedFullRoleDomainProjectionRole255ExactEffIndexMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set 8 1
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactFrameLabelMismatchRejected : generatedFullRoleDomainProjectionRole255ExactFrameLabelMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := (generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactEventScopeMismatchRejected : generatedFullRoleDomainProjectionRole255ExactEventScopeMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set 9 0
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactEventFlagMismatchRejected : generatedFullRoleDomainProjectionRole255ExactEventFlagMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set 4 1
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactGlobalActionMismatchRejected : generatedFullRoleDomainProjectionRole255ExactGlobalActionMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set 9 255
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactGlobalOriginMismatchRejected : generatedFullRoleDomainProjectionRole255ExactGlobalOriginMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set 10 0
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactGlobalLaneMismatchRejected : generatedFullRoleDomainProjectionRole255ExactGlobalLaneMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole255Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactScopeMarkerMismatchRejected : generatedFullRoleDomainProjectionRole255ExactScopeMarkerMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set (generatedFullRoleDomainProjectionRole255Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactRouteMismatchRejected : generatedFullRoleDomainProjectionRole255ExactRouteMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactLogicalLaneCountMismatchRejected : generatedFullRoleDomainProjectionRole255ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole255Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactLaneBitMismatchRejected : generatedFullRoleDomainProjectionRole255ExactLaneBitMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole255Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactRouteCommitMismatchRejected : generatedFullRoleDomainProjectionRole255ExactRouteCommitMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole255Exact.image.programRouteResolverOffset + 2) 254
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactResolverMismatchRejected : generatedFullRoleDomainProjectionRole255ExactResolverMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    programBytes := generatedFullRoleDomainProjectionRole255Exact.image.programBytes.set (generatedFullRoleDomainProjectionRole255Exact.image.programRouteResolverOffset + 4) 255
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactControllerMismatchRejected : generatedFullRoleDomainProjectionRole255ExactControllerMismatch.check = false := by
  decide

def generatedFullRoleDomainProjectionRole255ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedFullRoleDomainProjectionRole255Exact with
  image := { generatedFullRoleDomainProjectionRole255Exact.image with
    roleBytes := generatedFullRoleDomainProjectionRole255Exact.image.roleBytes.set generatedFullRoleDomainProjectionRole255Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedFullRoleDomainProjectionRole255ExactRollMismatchRejected : generatedFullRoleDomainProjectionRole255ExactRollMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3 : Hibana.ProjectionCertificate := {
  role := 3
  choreo := generatedLaneMatchingChoreo
  topology := {
  events := [
    { action := .send 4 113 0 },
    { action := .recv 2 114 0 }
  ],
  rolls := [

  ],
  routes := [

  ]
}
}

theorem generatedLaneMatchingProjectionRole3Accepted : generatedLaneMatchingProjectionRole3.check = true := by
  decide

theorem generatedLaneMatchingProjectionRole3RefinesTopology : generatedLaneMatchingProjectionRole3.RefinesTopology :=
  Hibana.projection_certificate_sound generatedLaneMatchingProjectionRole3Accepted

def generatedLaneMatchingProjectionRole3Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 5
    role := 3
    logicalLaneCount := 2
    activeLaneCount := 2
    endpointLaneSlotCount := 2
    maxRouteCommitCount := 0
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 4
    routeResolverCount := 0
    routeParticipantCount := 0
    scopeMarkerCount := 9
    eventCount := 2
    dependencyRowCount := 0
    conflictRowCount := 0
    routeScopeCount := 0
    residentBoundaryCount := 2
    laneBitCount := 1
    routeArmLaneStepCount := 0
    routeCommitRowCount := 0
    rollScopeCount := 0
    programBytes := [0, 1, 111, 0, 0, 0, 0, 0, 0, 0, 2, 112, 0, 0, 0, 0, 0, 1, 3, 4, 113, 0, 0, 0, 0, 0, 1, 2, 3, 114, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 1, 64, 0, 1, 0, 1, 64, 1, 2, 0, 1, 64, 2, 2, 0, 2, 64, 0, 2, 0, 0, 64, 1, 3, 0, 2, 64, 1, 4, 0, 2, 64, 2, 4, 0, 0, 64, 2]
    roleBytes := [2, 0, 255, 255, 255, 255, 2, 64, 0, 0, 3, 0, 255, 255, 255, 255, 2, 64, 0, 0, 1, 0, 0, 0, 2, 0, 3]
  }
  choreo := generatedLaneMatchingChoreo
}

theorem generatedLaneMatchingProjectionRole3ExactAccepted : generatedLaneMatchingProjectionRole3Exact.check = true := by
  decide

theorem generatedLaneMatchingProjectionRole3ExactRefines : generatedLaneMatchingProjectionRole3Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedLaneMatchingProjectionRole3ExactAccepted

def generatedLaneMatchingProjectionRole3ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set generatedLaneMatchingProjectionRole3Exact.image.roleLaneOffset 2
  }
}

theorem generatedLaneMatchingProjectionRole3ExactLaneMismatchRejected : generatedLaneMatchingProjectionRole3ExactLaneMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set 0 3
  }
}

theorem generatedLaneMatchingProjectionRole3ExactEffIndexMismatchRejected : generatedLaneMatchingProjectionRole3ExactEffIndexMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set 8 1
  }
}

theorem generatedLaneMatchingProjectionRole3ExactFrameLabelMismatchRejected : generatedLaneMatchingProjectionRole3ExactFrameLabelMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := (generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedLaneMatchingProjectionRole3ExactEventScopeMismatchRejected : generatedLaneMatchingProjectionRole3ExactEventScopeMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set 9 1
  }
}

theorem generatedLaneMatchingProjectionRole3ExactEventFlagMismatchRejected : generatedLaneMatchingProjectionRole3ExactEventFlagMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    programBytes := generatedLaneMatchingProjectionRole3Exact.image.programBytes.set 4 1
  }
}

theorem generatedLaneMatchingProjectionRole3ExactGlobalActionMismatchRejected : generatedLaneMatchingProjectionRole3ExactGlobalActionMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    programBytes := generatedLaneMatchingProjectionRole3Exact.image.programBytes.set 9 1
  }
}

theorem generatedLaneMatchingProjectionRole3ExactGlobalOriginMismatchRejected : generatedLaneMatchingProjectionRole3ExactGlobalOriginMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    programBytes := generatedLaneMatchingProjectionRole3Exact.image.programBytes.set 10 3
  }
}

theorem generatedLaneMatchingProjectionRole3ExactGlobalLaneMismatchRejected : generatedLaneMatchingProjectionRole3ExactGlobalLaneMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    programBytes := generatedLaneMatchingProjectionRole3Exact.image.programBytes.set (generatedLaneMatchingProjectionRole3Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedLaneMatchingProjectionRole3ExactScopeMarkerMismatchRejected : generatedLaneMatchingProjectionRole3ExactScopeMarkerMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    logicalLaneCount := 3
  }
}

theorem generatedLaneMatchingProjectionRole3ExactLogicalLaneCountMismatchRejected : generatedLaneMatchingProjectionRole3ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedLaneMatchingProjectionRole3ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedLaneMatchingProjectionRole3Exact with
  image := { generatedLaneMatchingProjectionRole3Exact.image with
    roleBytes := generatedLaneMatchingProjectionRole3Exact.image.roleBytes.set generatedLaneMatchingProjectionRole3Exact.image.roleLaneBitOffset 2
  }
}

theorem generatedLaneMatchingProjectionRole3ExactLaneBitMismatchRejected : generatedLaneMatchingProjectionRole3ExactLaneBitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0 : Hibana.ProjectionCertificate := {
  role := 0
  choreo := generatedCyclicRollChoreo
  topology := {
  events := [
    { action := .recv 2 107 0 },
    { action := .send 2 101 0 },
    { action := .recv 2 108 0 },
    { action := .send 2 102 0 }
  ],
  rolls := [
    { events := [0, 1, 2, 3] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 906, leftEvents := [0, 1], rightEvents := [2, 3], reentry := .rolled }
  ]
}
}

theorem generatedCyclicRollProjectionRole0Accepted : generatedCyclicRollProjectionRole0.check = true := by
  decide

theorem generatedCyclicRollProjectionRole0RefinesTopology : generatedCyclicRollProjectionRole0.RefinesTopology :=
  Hibana.projection_certificate_sound generatedCyclicRollProjectionRole0Accepted

def generatedCyclicRollProjectionRole0Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 0
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 8
    routeResolverCount := 1
    routeParticipantCount := 6
    scopeMarkerCount := 6
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 4
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [2, 0, 107, 0, 0, 0, 0, 0, 0, 0, 2, 101, 0, 0, 0, 0, 0, 0, 2, 1, 109, 0, 0, 0, 0, 0, 0, 1, 2, 103, 0, 0, 0, 0, 0, 0, 2, 0, 108, 0, 0, 0, 0, 0, 0, 0, 2, 102, 0, 0, 0, 0, 0, 0, 2, 1, 110, 0, 0, 0, 0, 0, 0, 1, 2, 104, 0, 0, 0, 0, 0, 0, 1, 128, 138, 3, 2, 0, 0, 2, 0, 1, 2, 0, 1, 2, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 4, 0, 1, 0, 2, 4, 0, 1, 0, 4, 8, 0, 1, 0, 2, 8, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 1, 1, 0, 255, 255, 1, 0, 1, 0, 0, 0, 4, 0, 255, 255, 2, 0, 1, 0, 1, 1, 5, 0, 255, 255, 3, 0, 1, 0, 1, 0, 0, 0, 0, 0, 2, 0, 2, 0, 3, 0, 3, 0, 1, 0, 0, 192, 2, 0, 0, 0, 255, 255, 0, 0, 2, 0, 2, 0, 255, 255, 0, 0, 0, 0, 4, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 1, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 4, 0, 0, 0]
  }
  choreo := generatedCyclicRollChoreo
}

theorem generatedCyclicRollProjectionRole0ExactAccepted : generatedCyclicRollProjectionRole0Exact.check = true := by
  decide

theorem generatedCyclicRollProjectionRole0ExactRefines : generatedCyclicRollProjectionRole0Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedCyclicRollProjectionRole0ExactAccepted

def generatedCyclicRollProjectionRole0ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set generatedCyclicRollProjectionRole0Exact.image.roleLaneOffset 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactLaneMismatchRejected : generatedCyclicRollProjectionRole0ExactLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set 0 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactEffIndexMismatchRejected : generatedCyclicRollProjectionRole0ExactEffIndexMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set 8 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactFrameLabelMismatchRejected : generatedCyclicRollProjectionRole0ExactFrameLabelMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := (generatedCyclicRollProjectionRole0Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedCyclicRollProjectionRole0ExactEventScopeMismatchRejected : generatedCyclicRollProjectionRole0ExactEventScopeMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set 9 0
  }
}

theorem generatedCyclicRollProjectionRole0ExactEventFlagMismatchRejected : generatedCyclicRollProjectionRole0ExactEventFlagMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set 4 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactGlobalActionMismatchRejected : generatedCyclicRollProjectionRole0ExactGlobalActionMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set 9 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactGlobalOriginMismatchRejected : generatedCyclicRollProjectionRole0ExactGlobalOriginMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set 10 3
  }
}

theorem generatedCyclicRollProjectionRole0ExactGlobalLaneMismatchRejected : generatedCyclicRollProjectionRole0ExactGlobalLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set (generatedCyclicRollProjectionRole0Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedCyclicRollProjectionRole0ExactScopeMarkerMismatchRejected : generatedCyclicRollProjectionRole0ExactScopeMarkerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set (generatedCyclicRollProjectionRole0Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedCyclicRollProjectionRole0ExactRouteMismatchRejected : generatedCyclicRollProjectionRole0ExactRouteMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedCyclicRollProjectionRole0ExactLogicalLaneCountMismatchRejected : generatedCyclicRollProjectionRole0ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set generatedCyclicRollProjectionRole0Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedCyclicRollProjectionRole0ExactLaneBitMismatchRejected : generatedCyclicRollProjectionRole0ExactLaneBitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set generatedCyclicRollProjectionRole0Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedCyclicRollProjectionRole0ExactRouteCommitMismatchRejected : generatedCyclicRollProjectionRole0ExactRouteCommitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set (generatedCyclicRollProjectionRole0Exact.image.programRouteResolverOffset + 2) 139
  }
}

theorem generatedCyclicRollProjectionRole0ExactResolverMismatchRejected : generatedCyclicRollProjectionRole0ExactResolverMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    programBytes := generatedCyclicRollProjectionRole0Exact.image.programBytes.set (generatedCyclicRollProjectionRole0Exact.image.programRouteResolverOffset + 4) 3
  }
}

theorem generatedCyclicRollProjectionRole0ExactControllerMismatchRejected : generatedCyclicRollProjectionRole0ExactControllerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole0ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole0Exact with
  image := { generatedCyclicRollProjectionRole0Exact.image with
    roleBytes := generatedCyclicRollProjectionRole0Exact.image.roleBytes.set generatedCyclicRollProjectionRole0Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedCyclicRollProjectionRole0ExactRollMismatchRejected : generatedCyclicRollProjectionRole0ExactRollMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1 : Hibana.ProjectionCertificate := {
  role := 1
  choreo := generatedCyclicRollChoreo
  topology := {
  events := [
    { action := .recv 2 109 0 },
    { action := .send 2 103 0 },
    { action := .recv 2 110 0 },
    { action := .send 2 104 0 }
  ],
  rolls := [
    { events := [0, 1, 2, 3] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 906, leftEvents := [0, 1], rightEvents := [2, 3], reentry := .rolled }
  ]
}
}

theorem generatedCyclicRollProjectionRole1Accepted : generatedCyclicRollProjectionRole1.check = true := by
  decide

theorem generatedCyclicRollProjectionRole1RefinesTopology : generatedCyclicRollProjectionRole1.RefinesTopology :=
  Hibana.projection_certificate_sound generatedCyclicRollProjectionRole1Accepted

def generatedCyclicRollProjectionRole1Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 1
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 8
    routeResolverCount := 1
    routeParticipantCount := 6
    scopeMarkerCount := 6
    eventCount := 4
    dependencyRowCount := 0
    conflictRowCount := 4
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [2, 0, 107, 0, 0, 0, 0, 0, 0, 0, 2, 101, 0, 0, 0, 0, 0, 0, 2, 1, 109, 0, 0, 0, 0, 0, 0, 1, 2, 103, 0, 0, 0, 0, 0, 0, 2, 0, 108, 0, 0, 0, 0, 0, 0, 0, 2, 102, 0, 0, 0, 0, 0, 0, 2, 1, 110, 0, 0, 0, 0, 0, 0, 1, 2, 104, 0, 0, 0, 0, 0, 0, 1, 128, 138, 3, 2, 0, 0, 2, 0, 1, 2, 0, 1, 2, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 4, 0, 1, 0, 2, 4, 0, 1, 0, 4, 8, 0, 1, 0, 2, 8, 0, 0, 32, 2]
    roleBytes := [2, 0, 255, 255, 0, 0, 1, 0, 0, 1, 3, 0, 255, 255, 1, 0, 1, 0, 0, 0, 6, 0, 255, 255, 2, 0, 1, 0, 1, 1, 7, 0, 255, 255, 3, 0, 1, 0, 1, 0, 0, 0, 0, 0, 2, 0, 2, 0, 3, 0, 3, 0, 1, 0, 0, 192, 2, 0, 0, 0, 255, 255, 0, 0, 2, 0, 2, 0, 255, 255, 0, 0, 0, 0, 4, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 1, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 4, 0, 0, 0]
  }
  choreo := generatedCyclicRollChoreo
}

theorem generatedCyclicRollProjectionRole1ExactAccepted : generatedCyclicRollProjectionRole1Exact.check = true := by
  decide

theorem generatedCyclicRollProjectionRole1ExactRefines : generatedCyclicRollProjectionRole1Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedCyclicRollProjectionRole1ExactAccepted

def generatedCyclicRollProjectionRole1ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set generatedCyclicRollProjectionRole1Exact.image.roleLaneOffset 1
  }
}

theorem generatedCyclicRollProjectionRole1ExactLaneMismatchRejected : generatedCyclicRollProjectionRole1ExactLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set 0 3
  }
}

theorem generatedCyclicRollProjectionRole1ExactEffIndexMismatchRejected : generatedCyclicRollProjectionRole1ExactEffIndexMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set 8 1
  }
}

theorem generatedCyclicRollProjectionRole1ExactFrameLabelMismatchRejected : generatedCyclicRollProjectionRole1ExactFrameLabelMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := (generatedCyclicRollProjectionRole1Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedCyclicRollProjectionRole1ExactEventScopeMismatchRejected : generatedCyclicRollProjectionRole1ExactEventScopeMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set 9 0
  }
}

theorem generatedCyclicRollProjectionRole1ExactEventFlagMismatchRejected : generatedCyclicRollProjectionRole1ExactEventFlagMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set 4 1
  }
}

theorem generatedCyclicRollProjectionRole1ExactGlobalActionMismatchRejected : generatedCyclicRollProjectionRole1ExactGlobalActionMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set 9 1
  }
}

theorem generatedCyclicRollProjectionRole1ExactGlobalOriginMismatchRejected : generatedCyclicRollProjectionRole1ExactGlobalOriginMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set 10 3
  }
}

theorem generatedCyclicRollProjectionRole1ExactGlobalLaneMismatchRejected : generatedCyclicRollProjectionRole1ExactGlobalLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set (generatedCyclicRollProjectionRole1Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedCyclicRollProjectionRole1ExactScopeMarkerMismatchRejected : generatedCyclicRollProjectionRole1ExactScopeMarkerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set (generatedCyclicRollProjectionRole1Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedCyclicRollProjectionRole1ExactRouteMismatchRejected : generatedCyclicRollProjectionRole1ExactRouteMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedCyclicRollProjectionRole1ExactLogicalLaneCountMismatchRejected : generatedCyclicRollProjectionRole1ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set generatedCyclicRollProjectionRole1Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedCyclicRollProjectionRole1ExactLaneBitMismatchRejected : generatedCyclicRollProjectionRole1ExactLaneBitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set generatedCyclicRollProjectionRole1Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedCyclicRollProjectionRole1ExactRouteCommitMismatchRejected : generatedCyclicRollProjectionRole1ExactRouteCommitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set (generatedCyclicRollProjectionRole1Exact.image.programRouteResolverOffset + 2) 139
  }
}

theorem generatedCyclicRollProjectionRole1ExactResolverMismatchRejected : generatedCyclicRollProjectionRole1ExactResolverMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    programBytes := generatedCyclicRollProjectionRole1Exact.image.programBytes.set (generatedCyclicRollProjectionRole1Exact.image.programRouteResolverOffset + 4) 3
  }
}

theorem generatedCyclicRollProjectionRole1ExactControllerMismatchRejected : generatedCyclicRollProjectionRole1ExactControllerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole1ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole1Exact with
  image := { generatedCyclicRollProjectionRole1Exact.image with
    roleBytes := generatedCyclicRollProjectionRole1Exact.image.roleBytes.set generatedCyclicRollProjectionRole1Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedCyclicRollProjectionRole1ExactRollMismatchRejected : generatedCyclicRollProjectionRole1ExactRollMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2 : Hibana.ProjectionCertificate := {
  role := 2
  choreo := generatedCyclicRollChoreo
  topology := {
  events := [
    { action := .send 0 107 0 },
    { action := .recv 0 101 0 },
    { action := .send 1 109 0 },
    { action := .recv 1 103 0 },
    { action := .send 0 108 0 },
    { action := .recv 0 102 0 },
    { action := .send 1 110 0 },
    { action := .recv 1 104 0 }
  ],
  rolls := [
    { events := [0, 1, 2, 3, 4, 5, 6, 7] }
  ],
  routes := [
    { conflict := 0, authority := .dynamic 906, leftEvents := [0, 1, 2, 3], rightEvents := [4, 5, 6, 7], reentry := .rolled }
  ]
}
}

theorem generatedCyclicRollProjectionRole2Accepted : generatedCyclicRollProjectionRole2.check = true := by
  decide

theorem generatedCyclicRollProjectionRole2RefinesTopology : generatedCyclicRollProjectionRole2.RefinesTopology :=
  Hibana.projection_certificate_sound generatedCyclicRollProjectionRole2Accepted

def generatedCyclicRollProjectionRole2Exact : Hibana.ExactDescriptorCertificate := {
  image := {
    roleCount := 3
    role := 2
    logicalLaneCount := 1
    activeLaneCount := 1
    endpointLaneSlotCount := 1
    maxRouteCommitCount := 1
    firstActiveLane := 0
    activeLaneStart := 0
    activeLaneLength := 1
    atomCount := 8
    routeResolverCount := 1
    routeParticipantCount := 6
    scopeMarkerCount := 6
    eventCount := 8
    dependencyRowCount := 0
    conflictRowCount := 8
    routeScopeCount := 1
    residentBoundaryCount := 2
    laneBitCount := 4
    routeArmLaneStepCount := 2
    routeCommitRowCount := 2
    rollScopeCount := 1
    programBytes := [2, 0, 107, 0, 0, 0, 0, 0, 0, 0, 2, 101, 0, 0, 0, 0, 0, 0, 2, 1, 109, 0, 0, 0, 0, 0, 0, 1, 2, 103, 0, 0, 0, 0, 0, 0, 2, 0, 108, 0, 0, 0, 0, 0, 0, 0, 2, 102, 0, 0, 0, 0, 0, 0, 2, 1, 110, 0, 0, 0, 0, 0, 0, 1, 2, 104, 0, 0, 0, 0, 0, 0, 1, 128, 138, 3, 2, 0, 0, 2, 0, 1, 2, 0, 1, 2, 0, 0, 0, 32, 0, 0, 0, 1, 0, 4, 4, 0, 1, 0, 2, 4, 0, 1, 0, 4, 8, 0, 1, 0, 2, 8, 0, 0, 32, 2]
    roleBytes := [0, 0, 255, 255, 0, 0, 1, 0, 0, 0, 1, 0, 255, 255, 1, 0, 1, 0, 0, 1, 2, 0, 255, 255, 2, 0, 1, 0, 0, 0, 3, 0, 255, 255, 3, 0, 1, 0, 0, 0, 4, 0, 255, 255, 4, 0, 1, 0, 1, 0, 5, 0, 255, 255, 5, 0, 1, 0, 1, 1, 6, 0, 255, 255, 6, 0, 1, 0, 1, 0, 7, 0, 255, 255, 7, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 2, 0, 2, 0, 3, 0, 3, 0, 3, 0, 3, 0, 1, 0, 0, 192, 4, 0, 0, 0, 255, 255, 0, 0, 4, 0, 4, 0, 255, 255, 0, 0, 0, 0, 8, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 0, 0, 0, 3, 0, 0, 4, 0, 7, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 3, 0, 0, 0, 8, 0, 0, 0]
  }
  choreo := generatedCyclicRollChoreo
}

theorem generatedCyclicRollProjectionRole2ExactAccepted : generatedCyclicRollProjectionRole2Exact.check = true := by
  decide

theorem generatedCyclicRollProjectionRole2ExactRefines : generatedCyclicRollProjectionRole2Exact.Refines :=
  Hibana.exact_descriptor_certificate_sound generatedCyclicRollProjectionRole2ExactAccepted

def generatedCyclicRollProjectionRole2ExactLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set generatedCyclicRollProjectionRole2Exact.image.roleLaneOffset 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactLaneMismatchRejected : generatedCyclicRollProjectionRole2ExactLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactEffIndexMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set 0 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactEffIndexMismatchRejected : generatedCyclicRollProjectionRole2ExactEffIndexMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactFrameLabelMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set 8 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactFrameLabelMismatchRejected : generatedCyclicRollProjectionRole2ExactFrameLabelMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactEventScopeMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := (generatedCyclicRollProjectionRole2Exact.image.roleBytes.set 6 255).set 7 255
  }
}

theorem generatedCyclicRollProjectionRole2ExactEventScopeMismatchRejected : generatedCyclicRollProjectionRole2ExactEventScopeMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactEventFlagMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set 9 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactEventFlagMismatchRejected : generatedCyclicRollProjectionRole2ExactEventFlagMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactGlobalActionMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set 4 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactGlobalActionMismatchRejected : generatedCyclicRollProjectionRole2ExactGlobalActionMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactGlobalOriginMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set 9 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactGlobalOriginMismatchRejected : generatedCyclicRollProjectionRole2ExactGlobalOriginMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactGlobalLaneMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set 10 3
  }
}

theorem generatedCyclicRollProjectionRole2ExactGlobalLaneMismatchRejected : generatedCyclicRollProjectionRole2ExactGlobalLaneMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactScopeMarkerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set (generatedCyclicRollProjectionRole2Exact.image.programScopeMarkerOffset + 4) 4
  }
}

theorem generatedCyclicRollProjectionRole2ExactScopeMarkerMismatchRejected : generatedCyclicRollProjectionRole2ExactScopeMarkerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactRouteMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set (generatedCyclicRollProjectionRole2Exact.image.roleRouteScopeOffset + 1) 128
  }
}

theorem generatedCyclicRollProjectionRole2ExactRouteMismatchRejected : generatedCyclicRollProjectionRole2ExactRouteMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactLogicalLaneCountMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    logicalLaneCount := 2
  }
}

theorem generatedCyclicRollProjectionRole2ExactLogicalLaneCountMismatchRejected : generatedCyclicRollProjectionRole2ExactLogicalLaneCountMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactLaneBitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set generatedCyclicRollProjectionRole2Exact.image.roleLaneBitOffset 0
  }
}

theorem generatedCyclicRollProjectionRole2ExactLaneBitMismatchRejected : generatedCyclicRollProjectionRole2ExactLaneBitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactRouteCommitMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set generatedCyclicRollProjectionRole2Exact.image.roleRouteCommitRowOffset 3
  }
}

theorem generatedCyclicRollProjectionRole2ExactRouteCommitMismatchRejected : generatedCyclicRollProjectionRole2ExactRouteCommitMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactResolverMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set (generatedCyclicRollProjectionRole2Exact.image.programRouteResolverOffset + 2) 139
  }
}

theorem generatedCyclicRollProjectionRole2ExactResolverMismatchRejected : generatedCyclicRollProjectionRole2ExactResolverMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactControllerMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    programBytes := generatedCyclicRollProjectionRole2Exact.image.programBytes.set (generatedCyclicRollProjectionRole2Exact.image.programRouteResolverOffset + 4) 3
  }
}

theorem generatedCyclicRollProjectionRole2ExactControllerMismatchRejected : generatedCyclicRollProjectionRole2ExactControllerMismatch.check = false := by
  decide

def generatedCyclicRollProjectionRole2ExactRollMismatch : Hibana.ExactDescriptorCertificate := {
  generatedCyclicRollProjectionRole2Exact with
  image := { generatedCyclicRollProjectionRole2Exact.image with
    roleBytes := generatedCyclicRollProjectionRole2Exact.image.roleBytes.set generatedCyclicRollProjectionRole2Exact.image.roleRollScopeOffset 1
  }
}

theorem generatedCyclicRollProjectionRole2ExactRollMismatchRejected : generatedCyclicRollProjectionRole2ExactRollMismatch.check = false := by
  decide

def generatedProgressRole0 : Hibana.ProgressCertificate :=
  Hibana.buildProgressCertificate (Hibana.projectGraph 0 generatedChoreo)

theorem generatedProgressRole0Accepted : generatedProgressRole0.check (Hibana.projectGraph 0 generatedChoreo) = true := by
  decide

theorem generatedProgressRole0EnsuresLogicalProgress {state : Hibana.CompactCommitState}
    (reachable : Hibana.CompactReachable (Hibana.projectGraph 0 generatedChoreo) state) :
    Hibana.LogicalProgress (Hibana.projectGraph 0 generatedChoreo) state :=
  Hibana.reachable_state_has_logical_progress (certificate := generatedProgressRole0) generatedProgressRole0Accepted reachable

def generatedResolvedProgressRole0 : Hibana.ProgressCertificate :=
  Hibana.buildProgressCertificate (Hibana.projectGraph 0 generatedResolvedChoreo)

theorem generatedResolvedProgressRole0Accepted : generatedResolvedProgressRole0.check (Hibana.projectGraph 0 generatedResolvedChoreo) = true := by
  decide

theorem generatedResolvedProgressRole0EnsuresLogicalProgress {state : Hibana.CompactCommitState}
    (reachable : Hibana.CompactReachable (Hibana.projectGraph 0 generatedResolvedChoreo) state) :
    Hibana.LogicalProgress (Hibana.projectGraph 0 generatedResolvedChoreo) state :=
  Hibana.reachable_state_has_logical_progress (certificate := generatedResolvedProgressRole0) generatedResolvedProgressRole0Accepted reachable

def generatedRolledProgressRole0 : Hibana.ProgressCertificate :=
  Hibana.buildProgressCertificate (Hibana.projectGraph 0 generatedRolledChoreo)

theorem generatedRolledProgressRole0Accepted : generatedRolledProgressRole0.check (Hibana.projectGraph 0 generatedRolledChoreo) = true := by
  decide

theorem generatedRolledProgressRole0EnsuresLogicalProgress {state : Hibana.CompactCommitState}
    (reachable : Hibana.CompactReachable (Hibana.projectGraph 0 generatedRolledChoreo) state) :
    Hibana.LogicalProgress (Hibana.projectGraph 0 generatedRolledChoreo) state :=
  Hibana.reachable_state_has_logical_progress (certificate := generatedRolledProgressRole0) generatedRolledProgressRole0Accepted reachable

def generatedNestedResolvedProgressRole0 : Hibana.ProgressCertificate :=
  Hibana.buildProgressCertificate (Hibana.projectGraph 0 generatedNestedResolvedChoreo)

theorem generatedNestedResolvedProgressRole0Accepted : generatedNestedResolvedProgressRole0.check (Hibana.projectGraph 0 generatedNestedResolvedChoreo) = true := by
  decide

theorem generatedNestedResolvedProgressRole0EnsuresLogicalProgress {state : Hibana.CompactCommitState}
    (reachable : Hibana.CompactReachable (Hibana.projectGraph 0 generatedNestedResolvedChoreo) state) :
    Hibana.LogicalProgress (Hibana.projectGraph 0 generatedNestedResolvedChoreo) state :=
  Hibana.reachable_state_has_logical_progress (certificate := generatedNestedResolvedProgressRole0) generatedNestedResolvedProgressRole0Accepted reachable

def generatedProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 4 generatedChoreo

theorem generatedProjectabilityAccepted : generatedProjectability.check 0 4 generatedChoreo = true := by
  native_decide

theorem generatedProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 4 generatedChoreo state) :
    ∃ config,
    state.decode? 0 4 generatedChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedProjectability) generatedProjectabilityAccepted reachable

def generatedRolledProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedRolledChoreo

theorem generatedRolledProjectabilityAccepted : generatedRolledProjectability.check 0 2 generatedRolledChoreo = true := by
  native_decide

theorem generatedRolledProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedRolledChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedRolledChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedRolledProjectability) generatedRolledProjectabilityAccepted reachable

def generatedNestedRolledProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedNestedRolledChoreo

theorem generatedNestedRolledProjectabilityAccepted : generatedNestedRolledProjectability.check 0 2 generatedNestedRolledChoreo = true := by
  native_decide

theorem generatedNestedRolledProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedNestedRolledChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedNestedRolledChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedNestedRolledProjectability) generatedNestedRolledProjectabilityAccepted reachable

def generatedResolvedProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedResolvedChoreo

theorem generatedResolvedProjectabilityAccepted : generatedResolvedProjectability.check 0 2 generatedResolvedChoreo = true := by
  native_decide

theorem generatedResolvedProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedResolvedChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedResolvedChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedResolvedProjectability) generatedResolvedProjectabilityAccepted reachable

def generatedNestedResolvedProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedNestedResolvedChoreo

theorem generatedNestedResolvedProjectabilityAccepted : generatedNestedResolvedProjectability.check 0 2 generatedNestedResolvedChoreo = true := by
  native_decide

theorem generatedNestedResolvedProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedNestedResolvedChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedNestedResolvedChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedNestedResolvedProjectability) generatedNestedResolvedProjectabilityAccepted reachable

def generatedRolledResolvedProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedRolledResolvedChoreo

theorem generatedRolledResolvedProjectabilityAccepted : generatedRolledResolvedProjectability.check 0 2 generatedRolledResolvedChoreo = true := by
  native_decide

theorem generatedRolledResolvedProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedRolledResolvedChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedRolledResolvedChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedRolledResolvedProjectability) generatedRolledResolvedProjectabilityAccepted reachable

def generatedRejectingProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 2 generatedRejectingChoreo

theorem generatedRejectingProjectabilityAccepted : generatedRejectingProjectability.check 0 2 generatedRejectingChoreo = true := by
  native_decide

theorem generatedRejectingProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 2 generatedRejectingChoreo state) :
    ∃ config,
    state.decode? 0 2 generatedRejectingChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedRejectingProjectability) generatedRejectingProjectabilityAccepted reachable

def generatedCyclicRollProjectability : Hibana.ProjectabilityCertificate :=
  Hibana.buildProjectabilityCertificate 0 3 generatedCyclicRollChoreo

theorem generatedCyclicRollProjectabilityAccepted : generatedCyclicRollProjectability.check 0 3 generatedCyclicRollChoreo = true := by
  native_decide

theorem generatedCyclicRollProjectabilityEnsuresGlobalProgress {state : Hibana.CompactGlobalState}
    (reachable : Hibana.CompactGlobalReachable 0 3 generatedCyclicRollChoreo state) :
    ∃ config,
    state.decode? 0 3 generatedCyclicRollChoreo = some config ∧
    Hibana.GlobalLogicalProgress config :=
  Hibana.projectability_certificate_removes_global_progress_premise
    (certificate := generatedCyclicRollProjectability) generatedCyclicRollProjectabilityAccepted reachable

def generatedVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 4 generatedChoreo
  descriptors := [generatedProjectionRole0Exact, generatedProjectionRole1Exact, generatedProjectionRole2Exact, generatedProjectionRole3Exact]
}

theorem generatedVerifiedProtocolAccepted : generatedVerifiedProtocol.check 0 4 generatedChoreo = true := by
  native_decide

theorem generatedVerifiedProtocolAllRolesRefine : generatedVerifiedProtocol.AllRolesRefine 0 4 generatedChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedVerifiedProtocolAccepted

def generatedRolledVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedRolledProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedRolledChoreo
  descriptors := [generatedRolledProjectionRole0Exact, generatedRolledProjectionRole1Exact]
}

theorem generatedRolledVerifiedProtocolAccepted : generatedRolledVerifiedProtocol.check 0 2 generatedRolledChoreo = true := by
  native_decide

theorem generatedRolledVerifiedProtocolAllRolesRefine : generatedRolledVerifiedProtocol.AllRolesRefine 0 2 generatedRolledChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedRolledVerifiedProtocolAccepted

def generatedNestedRolledVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedNestedRolledProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedNestedRolledChoreo
  descriptors := [generatedNestedRolledProjectionRole0Exact, generatedNestedRolledProjectionRole1Exact]
}

theorem generatedNestedRolledVerifiedProtocolAccepted : generatedNestedRolledVerifiedProtocol.check 0 2 generatedNestedRolledChoreo = true := by
  native_decide

theorem generatedNestedRolledVerifiedProtocolAllRolesRefine : generatedNestedRolledVerifiedProtocol.AllRolesRefine 0 2 generatedNestedRolledChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedNestedRolledVerifiedProtocolAccepted

def generatedResolvedVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedResolvedProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedResolvedChoreo
  descriptors := [generatedResolvedProjectionRole0Exact, generatedResolvedProjectionRole1Exact]
}

theorem generatedResolvedVerifiedProtocolAccepted : generatedResolvedVerifiedProtocol.check 0 2 generatedResolvedChoreo = true := by
  native_decide

theorem generatedResolvedVerifiedProtocolAllRolesRefine : generatedResolvedVerifiedProtocol.AllRolesRefine 0 2 generatedResolvedChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedResolvedVerifiedProtocolAccepted

def generatedNestedResolvedVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedNestedResolvedProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedNestedResolvedChoreo
  descriptors := [generatedNestedResolvedProjectionRole0Exact, generatedNestedResolvedProjectionRole1Exact]
}

theorem generatedNestedResolvedVerifiedProtocolAccepted : generatedNestedResolvedVerifiedProtocol.check 0 2 generatedNestedResolvedChoreo = true := by
  native_decide

theorem generatedNestedResolvedVerifiedProtocolAllRolesRefine : generatedNestedResolvedVerifiedProtocol.AllRolesRefine 0 2 generatedNestedResolvedChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedNestedResolvedVerifiedProtocolAccepted

def generatedRolledResolvedVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedRolledResolvedProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedRolledResolvedChoreo
  descriptors := [generatedRolledResolvedProjectionRole0Exact, generatedRolledResolvedProjectionRole1Exact]
}

theorem generatedRolledResolvedVerifiedProtocolAccepted : generatedRolledResolvedVerifiedProtocol.check 0 2 generatedRolledResolvedChoreo = true := by
  native_decide

theorem generatedRolledResolvedVerifiedProtocolAllRolesRefine : generatedRolledResolvedVerifiedProtocol.AllRolesRefine 0 2 generatedRolledResolvedChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedRolledResolvedVerifiedProtocolAccepted

def generatedRejectingVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedRejectingProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 2 generatedRejectingChoreo
  descriptors := [generatedRejectingProjectionRole0Exact, generatedRejectingProjectionRole1Exact]
}

theorem generatedRejectingVerifiedProtocolAccepted : generatedRejectingVerifiedProtocol.check 0 2 generatedRejectingChoreo = true := by
  native_decide

theorem generatedRejectingVerifiedProtocolAllRolesRefine : generatedRejectingVerifiedProtocol.AllRolesRefine 0 2 generatedRejectingChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedRejectingVerifiedProtocolAccepted

def generatedCyclicRollVerifiedProtocol : Hibana.VerifiedProtocolCertificate := {
  projectability := generatedCyclicRollProjectability
  distributedProgress := Hibana.buildDistributedProgressCertificate 0 3 generatedCyclicRollChoreo
  descriptors := [generatedCyclicRollProjectionRole0Exact, generatedCyclicRollProjectionRole1Exact, generatedCyclicRollProjectionRole2Exact]
}

theorem generatedCyclicRollVerifiedProtocolAccepted : generatedCyclicRollVerifiedProtocol.check 0 3 generatedCyclicRollChoreo = true := by
  native_decide

theorem generatedCyclicRollVerifiedProtocolAllRolesRefine : generatedCyclicRollVerifiedProtocol.AllRolesRefine 0 3 generatedCyclicRollChoreo :=
  Hibana.verified_protocol_certificate_establishes_all_role_refinement generatedCyclicRollVerifiedProtocolAccepted

def generatedProductionSession : Nat := 0

def generatedProductionInitial : Hibana.CompactGlobalState :=
  Hibana.CompactGlobalState.initial generatedProductionSession 4 generatedChoreo

def generatedProductionAfterProtocol : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 4 generatedChoreo
    generatedProductionInitial (.protocol (.send 0))).get (by decide)

def generatedProductionAfterReceive : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 4 generatedChoreo
    generatedProductionAfterProtocol (.protocol (.recv 0))).get (by decide)

def generatedProductionLocalChoreo : Hibana.Choreo :=
  .send 0 0 201 0

def generatedProductionLocalInitial : Hibana.CompactGlobalState :=
  Hibana.CompactGlobalState.initial generatedProductionSession 1
    generatedProductionLocalChoreo

def generatedProductionAfterLocal : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 1
    generatedProductionLocalChoreo generatedProductionLocalInitial
    (.protocol (.localAction 0))).get (by decide)

def generatedProductionResolvedInitial : Hibana.CompactGlobalState :=
  Hibana.CompactGlobalState.initial generatedProductionSession 2
    generatedResolvedChoreo

def generatedProductionAfterResolve : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedResolvedChoreo
    generatedProductionResolvedInitial
    (.protocol (.resolve 0 0 901 .left))).get (by decide)

def generatedProductionAfterResolverReject : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedResolvedChoreo
    generatedProductionResolvedInitial
    (.protocol (.rejectResolver 0 0 901))).get (by decide)

def generatedProductionRolledInitial : Hibana.CompactGlobalState :=
  Hibana.CompactGlobalState.initial generatedProductionSession 2
    generatedRolledChoreo

def generatedProductionRolledAfterSend : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedRolledChoreo
    generatedProductionRolledInitial (.protocol (.send 0))).get (by decide)

def generatedProductionRolledAfterReceive : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedRolledChoreo
    generatedProductionRolledAfterSend (.protocol (.recv 0))).get (by decide)

def generatedProductionRolledAfterTailSend : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedRolledChoreo
    generatedProductionRolledAfterReceive (.protocol (.send 2))).get (by decide)

def generatedProductionRolledBeforeRoll : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedRolledChoreo
    generatedProductionRolledAfterTailSend (.protocol (.recv 2))).get (by decide)

def generatedProductionRolledAfterRoll : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 2 generatedRolledChoreo
    generatedProductionRolledBeforeRoll (.protocol (.roll 0))).get (by decide)

def generatedProductionAfterFault : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 4 generatedChoreo
    generatedProductionInitial (.fault 0 .transportOffline)).get (by decide)

def generatedProductionAfterAmbiguousReceive : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 4 generatedChoreo
    generatedProductionInitial (.ambiguousReceive 0)).get (by decide)

def generatedProductionAfterCancellationObservation : Hibana.CompactGlobalState :=
  (Hibana.applyRuntimeEffect? generatedProductionSession 4 generatedChoreo
    generatedProductionAfterFault (.observeCancellation 1)).get (by decide)

def generatedProductionKernelArtifact : Hibana.ProductionKernelArtifact := {
  transitions := [
    { before := generatedProductionInitial
      effect := .protocol (.send 0)
      after := generatedProductionAfterProtocol },
    { before := generatedProductionInitial
      effect := .preview
      after := generatedProductionInitial },
    { before := generatedProductionInitial
      effect := .dropPending
      after := generatedProductionInitial },
    { before := generatedProductionInitial
      effect := .requeue
      after := generatedProductionInitial },
    { before := generatedProductionInitial
      effect := .fault 0 .transportOffline
      after := generatedProductionAfterFault },
    { before := generatedProductionInitial
      effect := .ambiguousReceive 0
      after := generatedProductionAfterAmbiguousReceive },
    { before := generatedProductionAfterFault
      effect := .observeCancellation 1
      after := generatedProductionAfterCancellationObservation }
  ]
  protocolCases := [
    { session := generatedProductionSession
      roleCount := 4
      choreo := generatedChoreo
      transition := {
        before := generatedProductionInitial
        effect := .protocol (.send 0)
        after := generatedProductionAfterProtocol } },
    { session := generatedProductionSession
      roleCount := 4
      choreo := generatedChoreo
      transition := {
        before := generatedProductionAfterProtocol
        effect := .protocol (.recv 0)
        after := generatedProductionAfterReceive } },
    { session := generatedProductionSession
      roleCount := 1
      choreo := generatedProductionLocalChoreo
      transition := {
        before := generatedProductionLocalInitial
        effect := .protocol (.localAction 0)
        after := generatedProductionAfterLocal } },
    { session := generatedProductionSession
      roleCount := 2
      choreo := generatedResolvedChoreo
      transition := {
        before := generatedProductionResolvedInitial
        effect := .protocol (.resolve 0 0 901 .left)
        after := generatedProductionAfterResolve } },
    { session := generatedProductionSession
      roleCount := 2
      choreo := generatedResolvedChoreo
      transition := {
        before := generatedProductionResolvedInitial
        effect := .protocol (.rejectResolver 0 0 901)
        after := generatedProductionAfterResolverReject } },
    { session := generatedProductionSession
      roleCount := 2
      choreo := generatedRolledChoreo
      transition := {
        before := generatedProductionRolledBeforeRoll
        effect := .protocol (.roll 0)
        after := generatedProductionRolledAfterRoll } }
  ]
  owners := [.endpoint, .cursor, .slab, .waiter, .resolver,
    .receiveReceipt, .transport, .callbackReentry]
}

theorem generatedProductionKernelArtifactAccepted :
    generatedProductionKernelArtifact.check
      generatedProductionSession 4 generatedChoreo = true := by
  decide

theorem generatedProductionKernelArtifactRefinesKernel :
    Hibana.PreparedKernelRefinement generatedProductionKernelArtifact.kernel
    generatedProductionSession 4 generatedChoreo :=
  Hibana.accepted_production_kernel_artifact_refines_artifact_kernel
    generatedProductionKernelArtifactAccepted

theorem generated_production_protocol_cases_refine_prepared_kernels :
    forall protocolCase,
      protocolCase ∈ generatedProductionKernelArtifact.protocolCases ->
        Hibana.PreparedKernelRefinement protocolCase.kernel protocolCase.session
          protocolCase.roleCount protocolCase.choreo :=
  Hibana.accepted_production_kernel_artifact_refines_protocol_case_kernels
    (artifact := generatedProductionKernelArtifact)
    (session := generatedProductionSession)
    (roleCount := 4)
    (choreo := generatedChoreo)
    generatedProductionKernelArtifactAccepted

def generatedProductionCodecEntries : List (Nat × Nat) :=
  [(0, 0), (6, 4), (7, 4)]

def generatedProductionCodecs : List Hibana.VerifiedCodec :=
  Hibana.fixedWidthCodecRegistry generatedProductionCodecEntries

theorem generated_production_codec_coverage_for
    (choreo : Hibana.Choreo)
    (supported :
      forall candidate, candidate ∈ choreo.globalEvents ->
        candidate.schema = 0 \/ candidate.schema = 6 \/ candidate.schema = 7) :
    Hibana.VerifiedCodecCoverage choreo generatedProductionCodecs := by
  constructor
  · exact Hibana.fixed_width_codec_registry_agrees
      (Hibana.fixed_width_schema_registry_checker_sound (by decide))
  · intro event member
    rcases supported event member with unitSchema | u32Schema | i32Schema
    · refine ⟨Hibana.fixedWidthVerifiedCodec 0 0, ?_, ?_⟩
      · simp [generatedProductionCodecs, generatedProductionCodecEntries,
          Hibana.fixedWidthCodecRegistry]
      · rw [unitSchema]
        rfl
    · refine ⟨Hibana.fixedWidthVerifiedCodec 6 4, ?_, ?_⟩
      · simp [generatedProductionCodecs, generatedProductionCodecEntries,
          Hibana.fixedWidthCodecRegistry]
      · rw [u32Schema]
        rfl
    · refine ⟨Hibana.fixedWidthVerifiedCodec 7 4, ?_, ?_⟩
      · simp [generatedProductionCodecs, generatedProductionCodecEntries,
          Hibana.fixedWidthCodecRegistry]
      · rw [i32Schema]
        rfl

theorem generated_production_codec_coverage :
    Hibana.VerifiedCodecCoverage generatedChoreo generatedProductionCodecs :=
  generated_production_codec_coverage_for generatedChoreo (by decide)

def generatedVerifiedProtocolMember
    (roleCount : Nat)
    (choreo : Hibana.Choreo)
    (certificate : Hibana.VerifiedProtocolCertificate)
    (accepted : certificate.check 0 roleCount choreo = true)
    (supported :
      forall candidate, candidate ∈ choreo.globalEvents ->
        candidate.schema = 0 \/ candidate.schema = 6 \/ candidate.schema = 7) :
    Hibana.VerifiedProtocolMember := {
  session := 0
  roleCount
  choreo
  certificate
  accepted
  codecs := generatedProductionCodecs
  codecCoverage := generated_production_codec_coverage_for choreo supported
}

def generatedVerifiedProtocolPrimary : Hibana.VerifiedProtocolMember :=
  generatedVerifiedProtocolMember 4 generatedChoreo generatedVerifiedProtocol
    generatedVerifiedProtocolAccepted (by decide)

def generatedVerifiedProtocolFamily : List Hibana.VerifiedProtocolMember := [
  generatedVerifiedProtocolPrimary,
  generatedVerifiedProtocolMember 2 generatedRolledChoreo
    generatedRolledVerifiedProtocol generatedRolledVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 2 generatedNestedRolledChoreo
    generatedNestedRolledVerifiedProtocol generatedNestedRolledVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 2 generatedResolvedChoreo
    generatedResolvedVerifiedProtocol generatedResolvedVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 2 generatedNestedResolvedChoreo
    generatedNestedResolvedVerifiedProtocol generatedNestedResolvedVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 2 generatedRolledResolvedChoreo
    generatedRolledResolvedVerifiedProtocol generatedRolledResolvedVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 2 generatedRejectingChoreo
    generatedRejectingVerifiedProtocol generatedRejectingVerifiedProtocolAccepted (by decide),
  generatedVerifiedProtocolMember 3 generatedCyclicRollChoreo
    generatedCyclicRollVerifiedProtocol generatedCyclicRollVerifiedProtocolAccepted (by decide)
]

theorem generatedVerifiedProtocolFamilyCapabilitiesAccepted :
    Hibana.checkVerifiedProtocolFamilyCapabilities
      generatedVerifiedProtocolFamily = true := by
  decide

theorem generated_verified_protocol_family_covers_core_capabilities :
    Hibana.VerifiedProtocolFamilyCapabilityCoverage
      generatedVerifiedProtocolFamily :=
  Hibana.verified_protocol_family_capability_checker_sound
    generatedVerifiedProtocolFamilyCapabilitiesAccepted

def generatedStaticDeploymentEntry
    (member : Hibana.VerifiedProtocolMember) : Hibana.StaticDeploymentEntry := {
  roleImages := member.certificate.descriptors.map
    Hibana.ExactDescriptorCertificate.image
}

def generatedPrimaryStaticDeploymentEntry : Hibana.StaticDeploymentEntry :=
  generatedStaticDeploymentEntry generatedVerifiedProtocolPrimary

def generatedStaticDeploymentCertificate : Hibana.StaticDeploymentCertificate := {
  entries := generatedVerifiedProtocolFamily.map generatedStaticDeploymentEntry
}

theorem generatedStaticDeploymentCertificateAccepted :
    generatedStaticDeploymentCertificate.check
      generatedVerifiedProtocolFamily = true := by
  decide

theorem generated_static_deployment_certificate_refines_exact_family :
    generatedStaticDeploymentCertificate.Refines generatedVerifiedProtocolFamily :=
  Hibana.static_deployment_certificate_sound
    generatedStaticDeploymentCertificateAccepted

def generatedMissingStaticDeploymentCertificate :
    Hibana.StaticDeploymentCertificate := {
  entries := generatedStaticDeploymentCertificate.entries.drop 1
}

theorem generatedMissingStaticDeploymentCertificateRejected :
    generatedMissingStaticDeploymentCertificate.check
    generatedVerifiedProtocolFamily = false := by
  decide

def generatedExtraStaticDeploymentCertificate :
    Hibana.StaticDeploymentCertificate := {
  entries := generatedStaticDeploymentCertificate.entries ++
    [generatedPrimaryStaticDeploymentEntry]
}

theorem generatedExtraStaticDeploymentCertificateRejected :
    generatedExtraStaticDeploymentCertificate.check
    generatedVerifiedProtocolFamily = false := by
  decide

def generatedCorruptStaticDeploymentCertificate :
    Hibana.StaticDeploymentCertificate := {
  entries :=
    { roleImages := generatedPrimaryStaticDeploymentEntry.roleImages.drop 1 } ::
      generatedStaticDeploymentCertificate.entries.drop 1
}

theorem generatedCorruptStaticDeploymentCertificateRejected :
    generatedCorruptStaticDeploymentCertificate.check
    generatedVerifiedProtocolFamily = false := by
  decide

def generatedProductionDeployment : Hibana.DeploymentEvidence := {
  roleImages := generatedVerifiedProtocol.descriptors.map
    Hibana.ExactDescriptorCertificate.image
  codecs := generatedProductionCodecs
  carrier := Hibana.referenceCarrierSemantics
  abstraction := id
}

theorem generatedProductionRoleImagesAccepted :
    Hibana.checkRoleImages generatedVerifiedProtocolPrimary.certificate
      generatedProductionDeployment.roleImages = true := by
  decide

theorem generated_production_closing_carrier :
    Hibana.CarrierProfile.closing.Holds
      generatedProductionDeployment.carrier
      generatedProductionDeployment.abstraction True :=
  Hibana.affine_carrier_refinement_supports_closing_profile
    Hibana.reference_carrier_refines_affine_boundary

def generatedProductionRefinement
    (kernel : Hibana.PreparedKernelSemantics)
    (kernelRefinement : Hibana.PreparedKernelRefinement kernel
      generatedVerifiedProtocolPrimary.session
      generatedVerifiedProtocolPrimary.roleCount
      generatedVerifiedProtocolPrimary.choreo)
    (OwnerVerified : Hibana.ProductionKernelOwner ->
      Hibana.PreparedKernelSemantics -> Prop)
    (ownerEvidence : Hibana.ProductionOwnerEvidence OwnerVerified
      generatedProductionKernelArtifact kernel) :
    Hibana.AssumptionIndexedProductionRefinement OwnerVerified .closing True
      generatedVerifiedProtocolPrimary generatedVerifiedProtocolFamily
      generatedProductionDeployment generatedProductionKernelArtifact kernel
      generatedStaticDeploymentCertificate :=
  Hibana.assumption_indexed_static_cross_tool_production_refinement
    (by simp [generatedVerifiedProtocolFamily])
    generatedVerifiedProtocolFamilyCapabilitiesAccepted
    generatedStaticDeploymentCertificateAccepted
    generatedProductionRoleImagesAccepted
    rfl
    generatedProductionKernelArtifactAccepted
    kernelRefinement
    ownerEvidence
    generated_production_closing_carrier

#eval IO.println "hibana Lean production artifact passed transitions=7 operations=6 owners=8 kernel-refinement=external-premise owner-evidence=external-premise codecs=3 family=8 deployments=8 deployment-rejections=3 capabilities=6 agreement=static-exact-family profile=closing"

#eval IO.println "hibana Lean generated certificate check passed traces=14 frames=66 projections=22 exact-descriptors=22 progress=4 projectability=8 distributed-progress=8 verified-protocols=8"
