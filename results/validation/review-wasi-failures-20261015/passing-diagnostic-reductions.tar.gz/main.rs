#[path="/Users/ovm/Code/hibanaworks/hibana-tracefix/src/imp/transport.rs"]
mod transport;
use hibana::{g, runtime::{SessionKitStorage,ids::SessionId,program::project,resolver::{ResolverRef,DecisionArm}}};
type Outer_A = g::Msg<1,()>;
type Inner_A = g::Msg<2,()>;
type Ready_A = g::Msg<3,()>;
type Request_A = g::Msg<4,()>;
type Open_A = g::Msg<15,()>;
type Opened_A = g::Msg<16,()>;
type Admitted_A = g::Msg<5,()>;
type Validate_A = g::Msg<17,()>;
type Rejected_A = g::Msg<18,()>;
type Result_A = g::Msg<6,()>;
type Done_A = g::Msg<7,()>;
type Merge_A = g::Msg<19,()>;
type RepoOpen_A = g::Msg<20,()>;
type RepoOpened_A = g::Msg<21,()>;
type RepoRequest_A = g::Msg<22,()>;
type RepoValidate_A = g::Msg<23,()>;
type RepoComplete_A = g::Msg<24,()>;
type RepoReject_A = g::Msg<25,()>;
type ApproveRepo_A = g::Msg<26,()>;
type ReviseRepo_A = g::Msg<27,()>;
type RepoRecorded_A = g::Msg<28,()>;
type BeginReview_A = g::Msg<8,()>;
type ReviewRequested_A = g::Msg<9,()>;
type CanReview_A = g::Msg<10,()>;
type Revise_A = g::Msg<11,()>;
type Approved_A = g::Msg<12,()>;
type ReviseFeedback_A = g::Msg<13,()>;
type ApproveFeedback_A = g::Msg<14,()>;
type Outer_B = g::Msg<41,()>;
type Inner_B = g::Msg<42,()>;
type Ready_B = g::Msg<43,()>;
type Request_B = g::Msg<44,()>;
type Open_B = g::Msg<55,()>;
type Opened_B = g::Msg<56,()>;
type Admitted_B = g::Msg<45,()>;
type Validate_B = g::Msg<57,()>;
type Rejected_B = g::Msg<58,()>;
type Result_B = g::Msg<46,()>;
type Done_B = g::Msg<47,()>;
type Merge_B = g::Msg<59,()>;
type RepoOpen_B = g::Msg<60,()>;
type RepoOpened_B = g::Msg<61,()>;
type RepoRequest_B = g::Msg<62,()>;
type RepoValidate_B = g::Msg<63,()>;
type RepoComplete_B = g::Msg<64,()>;
type RepoReject_B = g::Msg<65,()>;
type ApproveRepo_B = g::Msg<66,()>;
type ReviseRepo_B = g::Msg<67,()>;
type RepoRecorded_B = g::Msg<68,()>;
type BeginReview_B = g::Msg<48,()>;
type ReviewRequested_B = g::Msg<49,()>;
type CanReview_B = g::Msg<50,()>;
type Revise_B = g::Msg<51,()>;
type Approved_B = g::Msg<52,()>;
type ReviseFeedback_B = g::Msg<53,()>;
type ApproveFeedback_B = g::Msg<54,()>;
#[tokio::main(flavor="current_thread")]
async fn main() {
 let open_A=g::seq(g::send::<1,0,Open_A>(),g::seq(g::send::<0,3,RepoOpen_A>(),g::seq(g::send::<3,0,RepoOpened_A>(),g::send::<0,1,Opened_A>())));
 let request_A=g::seq(g::send::<1,0,Request_A>(),g::seq(g::send::<0,3,RepoRequest_A>(),g::route(g::seq(g::send::<3,3,RepoValidate_A>(),g::seq(g::send::<3,0,RepoComplete_A>(),g::send::<0,1,Admitted_A>())),g::seq(g::send::<3,0,RepoReject_A>(),g::send::<0,1,Rejected_A>())).resolve::<1>()));
 let body_A=g::seq(g::send::<0,0,Inner_A>(),g::seq(g::send::<0,1,Ready_A>(),g::route(open_A,request_A))).roll();
 let review_A=g::seq(g::send::<2,2,BeginReview_A>(),g::send::<2,0,ReviewRequested_A>());
 let prefix_A=g::par(g::seq(g::send::<0,0,Outer_A>(),body_A),review_A);
 let merge_A=g::seq(g::send::<0,0,Merge_A>(),g::seq(g::send::<0,1,Ready_A>(),g::seq(g::send::<1,0,Request_A>(),g::send::<0,1,Admitted_A>()))).roll();
 let accepted_A=g::seq(g::send::<2,2,Approved_A>(),g::seq(g::seq(g::send::<2,3,ApproveRepo_A>(),g::seq(g::send::<3,2,RepoRecorded_A>(),g::send::<2,0,ApproveFeedback_A>())),g::seq(g::send::<0,1,Result_A>(),g::seq(g::send::<0,1,Done_A>(),merge_A))));
 let rejected_A=g::seq(g::send::<2,2,Revise_A>(),g::seq(g::seq(g::send::<2,3,ReviseRepo_A>(),g::seq(g::send::<3,2,RepoRecorded_A>(),g::send::<2,0,ReviseFeedback_A>())),g::seq(g::send::<0,1,Result_A>(),g::send::<0,1,Done_A>())));
 let feature_a=g::seq(prefix_A,g::seq(g::send::<0,2,CanReview_A>(),g::route(accepted_A,rejected_A))).roll();
 let open_B=g::seq(g::send::<5,4,Open_B>(),g::seq(g::send::<4,3,RepoOpen_B>(),g::seq(g::send::<3,4,RepoOpened_B>(),g::send::<4,5,Opened_B>())));
 let request_B=g::seq(g::send::<5,4,Request_B>(),g::seq(g::send::<4,3,RepoRequest_B>(),g::route(g::seq(g::send::<3,3,RepoValidate_B>(),g::seq(g::send::<3,4,RepoComplete_B>(),g::send::<4,5,Admitted_B>())),g::seq(g::send::<3,4,RepoReject_B>(),g::send::<4,5,Rejected_B>())).resolve::<2>()));
 let body_B=g::seq(g::send::<4,4,Inner_B>(),g::seq(g::send::<4,5,Ready_B>(),g::route(open_B,request_B))).roll();
 let review_B=g::seq(g::send::<6,6,BeginReview_B>(),g::send::<6,4,ReviewRequested_B>());
 let prefix_B=g::par(g::seq(g::send::<4,4,Outer_B>(),body_B),review_B);
 let merge_B=g::seq(g::send::<4,4,Merge_B>(),g::seq(g::send::<4,5,Ready_B>(),g::seq(g::send::<5,4,Request_B>(),g::send::<4,5,Admitted_B>()))).roll();
 let accepted_B=g::seq(g::send::<6,6,Approved_B>(),g::seq(g::seq(g::send::<6,3,ApproveRepo_B>(),g::seq(g::send::<3,6,RepoRecorded_B>(),g::send::<6,4,ApproveFeedback_B>())),g::seq(g::send::<4,5,Result_B>(),g::seq(g::send::<4,5,Done_B>(),merge_B))));
 let rejected_B=g::seq(g::send::<6,6,Revise_B>(),g::seq(g::seq(g::send::<6,3,ReviseRepo_B>(),g::seq(g::send::<3,6,RepoRecorded_B>(),g::send::<6,4,ReviseFeedback_B>())),g::seq(g::send::<4,5,Result_B>(),g::send::<4,5,Done_B>())));
 let feature_b=g::seq(prefix_B,g::seq(g::send::<4,6,CanReview_B>(),g::route(accepted_B,rejected_B))).roll();
 let global=g::par(feature_a,feature_b);
 let p0=project::<0>(&global);
 let p1=project::<1>(&global);
 let p2=project::<2>(&global);
 let p3=project::<3>(&global);
 let p4=project::<4>(&global);
 let p5=project::<5>(&global);
 let p6=project::<6>(&global);

 let mut bytes=vec![0;1024*1024];
 let mut storage=SessionKitStorage::uninit(); let kit=storage.init();
 let carrier=transport::InMemoryTransport::new();
 let rv=kit.rendezvous(&mut bytes,carrier.clone()).unwrap();
 rv.set_resolver(&p3,ResolverRef::<1>::decision_state(&(),|_| Ok(DecisionArm::Left))).unwrap();
 rv.set_resolver(&p3,ResolverRef::<2>::decision_state(&(),|_| Ok(DecisionArm::Left))).unwrap();
 let mut repo=rv.enter(SessionId::new(1),&p3).unwrap();
 let mut a_A=rv.enter(SessionId::new(1),&p0).unwrap();
 let mut b_A=rv.enter(SessionId::new(1),&p1).unwrap();
 let mut c_A=rv.enter(SessionId::new(1),&p2).unwrap();
 let mut a_B=rv.enter(SessionId::new(1),&p4).unwrap();
 let mut b_B=rv.enter(SessionId::new(1),&p5).unwrap();
 let mut c_B=rv.enter(SessionId::new(1),&p6).unwrap();
 tokio::join!(
async {
   for visit in 0..3 {
     a_A.send::<Outer_A>(&()).await.expect("a_A outer");
     a_A.send::<Inner_A>(&()).await.expect("a_A inner open");
     a_A.send::<Ready_A>(&()).await.expect("a_A ready open");
     a_A.recv::<Open_A>().await.expect("a_A open");
     a_A.send::<RepoOpen_A>(&()).await.expect("a_A repo open");
     a_A.recv::<RepoOpened_A>().await.expect("a_A repo opened");
     a_A.send::<Opened_A>(&()).await.expect("a_A opened");
     a_A.send::<Inner_A>(&()).await.expect("a_A inner");
     a_A.send::<Ready_A>(&()).await.expect("a_A ready");
     a_A.recv::<Request_A>().await.expect("a_A request");
     a_A.send::<RepoRequest_A>(&()).await.expect("a_A repo request");
     a_A.recv::<RepoComplete_A>().await.expect("a_A repo completed");
     a_A.send::<Admitted_A>(&()).await.expect("a_A admitted");
     a_A.recv::<ReviewRequested_A>().await.expect("a_A review requested");
     a_A.send::<CanReview_A>(&()).await.expect("a_A can review");
     a_A.recv::<ReviseFeedback_A>().await.expect("a_A feedback");
     a_A.send::<Result_A>(&()).await.expect("a_A result");
     a_A.send::<Done_A>(&()).await.expect("a_A done");
     println!("sender visit {visit}");
   }
 },
async {
   for visit in 0..3 {
     b_A.recv::<Ready_A>().await.expect("b_A ready open");
     b_A.send::<Open_A>(&()).await.expect("b_A open");
     b_A.recv::<Opened_A>().await.expect("b_A opened");
     b_A.recv::<Ready_A>().await.expect("b_A ready");
     b_A.send::<Request_A>(&()).await.expect("b_A request");
     b_A.offer().await.expect("b_A offer admitted").recv::<Admitted_A>().await.expect("b_A admitted");
     b_A.recv::<Result_A>().await.expect("b_A result");
     b_A.recv::<Done_A>().await.expect("b_A done");
     println!("receiver visit {visit}");
   }
 },
async {
   for visit in 0..3 {
     c_A.send::<BeginReview_A>(&()).await.expect("c_A begin review");
     c_A.send::<ReviewRequested_A>(&()).await.expect("c_A review requested");
     c_A.recv::<CanReview_A>().await.expect("c_A can review");
     c_A.send::<Revise_A>(&()).await.expect("c_A revise");
     c_A.send::<ReviseRepo_A>(&()).await.expect("c_A revise repo");
     c_A.recv::<RepoRecorded_A>().await.expect("c_A repo recorded");
     c_A.send::<ReviseFeedback_A>(&()).await.expect("c_A revise feedback");
     println!("reviewer visit {visit}");
   }
 },
async {
   for visit in 0..3 {
     a_B.send::<Outer_B>(&()).await.expect("a_B outer");
     a_B.send::<Inner_B>(&()).await.expect("a_B inner open");
     a_B.send::<Ready_B>(&()).await.expect("a_B ready open");
     a_B.recv::<Open_B>().await.expect("a_B open");
     a_B.send::<RepoOpen_B>(&()).await.expect("a_B repo open");
     a_B.recv::<RepoOpened_B>().await.expect("a_B repo opened");
     a_B.send::<Opened_B>(&()).await.expect("a_B opened");
     a_B.send::<Inner_B>(&()).await.expect("a_B inner");
     a_B.send::<Ready_B>(&()).await.expect("a_B ready");
     a_B.recv::<Request_B>().await.expect("a_B request");
     a_B.send::<RepoRequest_B>(&()).await.expect("a_B repo request");
     a_B.recv::<RepoComplete_B>().await.expect("a_B repo completed");
     a_B.send::<Admitted_B>(&()).await.expect("a_B admitted");
     a_B.recv::<ReviewRequested_B>().await.expect("a_B review requested");
     a_B.send::<CanReview_B>(&()).await.expect("a_B can review");
     a_B.recv::<ReviseFeedback_B>().await.expect("a_B feedback");
     a_B.send::<Result_B>(&()).await.expect("a_B result");
     a_B.send::<Done_B>(&()).await.expect("a_B done");
     println!("sender visit {visit}");
   }
 },
async {
   for visit in 0..3 {
     b_B.recv::<Ready_B>().await.expect("b_B ready open");
     b_B.send::<Open_B>(&()).await.expect("b_B open");
     b_B.recv::<Opened_B>().await.expect("b_B opened");
     b_B.recv::<Ready_B>().await.expect("b_B ready");
     b_B.send::<Request_B>(&()).await.expect("b_B request");
     b_B.offer().await.expect("b_B offer admitted").recv::<Admitted_B>().await.expect("b_B admitted");
     b_B.recv::<Result_B>().await.expect("b_B result");
     b_B.recv::<Done_B>().await.expect("b_B done");
     println!("receiver visit {visit}");
   }
 },
async {
   for visit in 0..3 {
     c_B.send::<BeginReview_B>(&()).await.expect("c_B begin review");
     c_B.send::<ReviewRequested_B>(&()).await.expect("c_B review requested");
     c_B.recv::<CanReview_B>().await.expect("c_B can review");
     c_B.send::<Revise_B>(&()).await.expect("c_B revise");
     c_B.send::<ReviseRepo_B>(&()).await.expect("c_B revise repo");
     c_B.recv::<RepoRecorded_B>().await.expect("c_B repo recorded");
     c_B.send::<ReviseFeedback_B>(&()).await.expect("c_B revise feedback");
     println!("reviewer visit {visit}");
   }
 },
async {
   let mut recorded=0;
   while recorded<6 {
    let branch=repo.offer().await.expect("repo offer");
    match branch.label() {
     20=> {branch.recv::<RepoOpen_A>().await.expect("repo open");repo.send::<RepoOpened_A>(&()).await.expect("repo opened");},
     22=> {branch.recv::<RepoRequest_A>().await.expect("repo request");},
     23=> {branch.recv::<RepoValidate_A>().await.expect("repo validate");repo.send::<RepoComplete_A>(&()).await.expect("repo complete");},
     27=> {branch.recv::<ReviseRepo_A>().await.expect("repo revise");repo.send::<RepoRecorded_A>(&()).await.expect("repo recorded");recorded+=1;},

     60=> {branch.recv::<RepoOpen_B>().await.expect("repo open");repo.send::<RepoOpened_B>(&()).await.expect("repo opened");},
     62=> {branch.recv::<RepoRequest_B>().await.expect("repo request");},
     63=> {branch.recv::<RepoValidate_B>().await.expect("repo validate");repo.send::<RepoComplete_B>(&()).await.expect("repo complete");},
     67=> {branch.recv::<ReviseRepo_B>().await.expect("repo revise");repo.send::<RepoRecorded_B>(&()).await.expect("repo recorded");recorded+=1;},
     label=>panic!("unexpected repo branch {label}"),
    }
   }
 } );
 println!("observed {} frame events",carrier.take_observations().len());
}
