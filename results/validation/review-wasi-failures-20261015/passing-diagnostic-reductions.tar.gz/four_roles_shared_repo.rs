#[path="/Users/ovm/Code/hibanaworks/hibana-tracefix/src/imp/transport.rs"]
mod transport;
use hibana::{g, runtime::{SessionKitStorage,ids::SessionId,program::project,resolver::{ResolverRef,DecisionArm}}};
type Outer = g::Msg<1,()>;
type Inner = g::Msg<2,()>;
type Ready = g::Msg<3,()>;
type Request = g::Msg<4,()>;
type Open = g::Msg<15,()>;
type Opened = g::Msg<16,()>;
type Admitted = g::Msg<5,()>;
type Validate = g::Msg<17,()>;
type Rejected = g::Msg<18,()>;
type Result = g::Msg<6,()>;
type Done = g::Msg<7,()>;
type Merge = g::Msg<19,()>;
type RepoOpen = g::Msg<20,()>;
type RepoOpened = g::Msg<21,()>;
type RepoRequest = g::Msg<22,()>;
type RepoValidate = g::Msg<23,()>;
type RepoComplete = g::Msg<24,()>;
type RepoReject = g::Msg<25,()>;
type ApproveRepo = g::Msg<26,()>;
type ReviseRepo = g::Msg<27,()>;
type RepoRecorded = g::Msg<28,()>;
type BeginReview = g::Msg<8,()>;
type ReviewRequested = g::Msg<9,()>;
type CanReview = g::Msg<10,()>;
type Revise = g::Msg<11,()>;
type Approved = g::Msg<12,()>;
type ReviseFeedback = g::Msg<13,()>;
type ApproveFeedback = g::Msg<14,()>;
#[tokio::main(flavor="current_thread")]
async fn main() {
 let open=g::seq(g::send::<1,0,Open>(),g::seq(g::send::<0,3,RepoOpen>(),g::seq(g::send::<3,0,RepoOpened>(),g::send::<0,1,Opened>())));
 let request=g::seq(g::send::<1,0,Request>(),g::seq(g::send::<0,3,RepoRequest>(),g::route(g::seq(g::send::<3,3,RepoValidate>(),g::seq(g::send::<3,0,RepoComplete>(),g::send::<0,1,Admitted>())),g::seq(g::send::<3,0,RepoReject>(),g::send::<0,1,Rejected>())).resolve::<1>()));
 let body=g::seq(g::send::<0,0,Inner>(),g::seq(g::send::<0,1,Ready>(),g::route(open,request))).roll();
 let review=g::seq(g::send::<2,2,BeginReview>(),g::send::<2,0,ReviewRequested>());
 let prefix=g::par(g::seq(g::send::<0,0,Outer>(),body),review);
 let merge=g::seq(g::send::<0,0,Merge>(),g::seq(g::send::<0,1,Ready>(),g::seq(g::send::<1,0,Request>(),g::send::<0,1,Admitted>()))).roll();
 let accepted=g::seq(g::send::<2,2,Approved>(),g::seq(g::seq(g::send::<2,3,ApproveRepo>(),g::seq(g::send::<3,2,RepoRecorded>(),g::send::<2,0,ApproveFeedback>())),g::seq(g::send::<0,1,Result>(),g::seq(g::send::<0,1,Done>(),merge))));
 let rejected=g::seq(g::send::<2,2,Revise>(),g::seq(g::seq(g::send::<2,3,ReviseRepo>(),g::seq(g::send::<3,2,RepoRecorded>(),g::send::<2,0,ReviseFeedback>())),g::seq(g::send::<0,1,Result>(),g::send::<0,1,Done>())));
 let global=g::seq(prefix,g::seq(g::send::<0,2,CanReview>(),g::route(accepted,rejected))).roll();
 let p0=project::<0>(&global); let p1=project::<1>(&global); let p2=project::<2>(&global); let p3=project::<3>(&global);
 let mut bytes=vec![0;1024*1024];
 let mut storage=SessionKitStorage::uninit(); let kit=storage.init();
 let carrier=transport::InMemoryTransport::new();
 let rv=kit.rendezvous(&mut bytes,carrier.clone()).unwrap();
 rv.set_resolver(&p3,ResolverRef::<1>::decision_state(&(),|_| Ok(DecisionArm::Left))).unwrap();
 let mut repo=rv.enter(SessionId::new(1),&p3).unwrap();
 let mut a=rv.enter(SessionId::new(1),&p0).unwrap();
 let mut b=rv.enter(SessionId::new(1),&p1).unwrap();
 let mut c=rv.enter(SessionId::new(1),&p2).unwrap();
 tokio::join!(async {
   for visit in 0..3 {
     a.send::<Outer>(&()).await.expect("a outer");
     a.send::<Inner>(&()).await.expect("a inner open");
     a.send::<Ready>(&()).await.expect("a ready open");
     a.recv::<Open>().await.expect("a open");
     a.send::<RepoOpen>(&()).await.expect("a repo open");
     a.recv::<RepoOpened>().await.expect("a repo opened");
     a.send::<Opened>(&()).await.expect("a opened");
     a.send::<Inner>(&()).await.expect("a inner");
     a.send::<Ready>(&()).await.expect("a ready");
     a.recv::<Request>().await.expect("a request");
     a.send::<RepoRequest>(&()).await.expect("a repo request");
     a.recv::<RepoComplete>().await.expect("a repo completed");
     a.send::<Admitted>(&()).await.expect("a admitted");
     a.recv::<ReviewRequested>().await.expect("a review requested");
     a.send::<CanReview>(&()).await.expect("a can review");
     a.recv::<ReviseFeedback>().await.expect("a feedback");
     a.send::<Result>(&()).await.expect("a result");
     a.send::<Done>(&()).await.expect("a done");
     println!("sender visit {visit}");
   }
 },async {
   for visit in 0..3 {
     b.recv::<Ready>().await.expect("b ready open");
     b.send::<Open>(&()).await.expect("b open");
     b.recv::<Opened>().await.expect("b opened");
     b.recv::<Ready>().await.expect("b ready");
     b.send::<Request>(&()).await.expect("b request");
     b.offer().await.expect("b offer admitted").recv::<Admitted>().await.expect("b admitted");
     b.recv::<Result>().await.expect("b result");
     b.recv::<Done>().await.expect("b done");
     println!("receiver visit {visit}");
   }
 },async {
   for visit in 0..3 {
     c.send::<BeginReview>(&()).await.expect("c begin review");
     c.send::<ReviewRequested>(&()).await.expect("c review requested");
     c.recv::<CanReview>().await.expect("c can review");
     c.send::<Revise>(&()).await.expect("c revise");
     c.send::<ReviseRepo>(&()).await.expect("c revise repo");
     c.recv::<RepoRecorded>().await.expect("c repo recorded");
     c.send::<ReviseFeedback>(&()).await.expect("c revise feedback");
     println!("reviewer visit {visit}");
   }
 },async {
   let mut recorded=0;
   while recorded<3 {
    let branch=repo.offer().await.expect("repo offer");
    match branch.label() {
     20=> {branch.recv::<RepoOpen>().await.expect("repo open");repo.send::<RepoOpened>(&()).await.expect("repo opened");},
     22=> {branch.recv::<RepoRequest>().await.expect("repo request");},
     23=> {branch.recv::<RepoValidate>().await.expect("repo validate");repo.send::<RepoComplete>(&()).await.expect("repo complete");},
     27=> {branch.recv::<ReviseRepo>().await.expect("repo revise");repo.send::<RepoRecorded>(&()).await.expect("repo recorded");recorded+=1;},
     label=>panic!("unexpected repo branch {label}"),
    }
   }
 });
 println!("observed {} frame events",carrier.take_observations().len());
}
