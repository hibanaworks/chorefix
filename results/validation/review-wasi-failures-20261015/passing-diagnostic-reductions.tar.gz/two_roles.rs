#[path="/Users/ovm/Code/hibanaworks/hibana-tracefix/src/imp/transport.rs"]
mod transport;
use hibana::{g, runtime::{SessionKitStorage,ids::SessionId,program::project}};
type Outer = g::Msg<1,()>;
type Inner = g::Msg<2,()>;
type Ready = g::Msg<3,()>;
type Request = g::Msg<4,()>;
type Again = g::Msg<5,()>;
#[tokio::main(flavor="current_thread")]
async fn main() {
 let body=g::seq(g::send::<0,0,Inner>(),g::seq(g::send::<0,1,Ready>(),g::send::<1,0,Request>())).roll();
 let global=g::seq(g::send::<0,0,Outer>(),g::seq(body,g::send::<0,1,Again>())).roll();
 let p0=project::<0>(&global); let p1=project::<1>(&global);
 let mut bytes=vec![0;1024*1024];
 let mut storage=SessionKitStorage::uninit(); let kit=storage.init();
 let rv=kit.rendezvous(&mut bytes,transport::InMemoryTransport::new()).unwrap();
 let mut a=rv.enter(SessionId::new(1),&p0).unwrap();
 let mut b=rv.enter(SessionId::new(1),&p1).unwrap();
 tokio::join!(async {
   for visit in 0..3 {
     a.send::<Outer>(&()).await.expect("a outer");
     a.send::<Inner>(&()).await.expect("a inner");
     a.send::<Ready>(&()).await.expect("a ready");
     a.recv::<Request>().await.expect("a request");
     a.send::<Again>(&()).await.expect("a again");
     println!("sender visit {visit}");
   }
 },async {
   for visit in 0..3 {
     b.recv::<Ready>().await.expect("b ready");
     b.send::<Request>(&()).await.expect("b request");
     b.recv::<Again>().await.expect("b again");
     println!("receiver visit {visit}");
   }
 });
}
