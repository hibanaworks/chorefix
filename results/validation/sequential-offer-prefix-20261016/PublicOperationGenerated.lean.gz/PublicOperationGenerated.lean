import Hibana.MainTheorems

def generatedPublicOperationTable : List Hibana.PublicOperationTransition := [
  -- current=.idle edge=.beginOffer
  { lease := .held, phase := .offer },
  -- current=.idle edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.beginSend
  { lease := .held, phase := .send },
  -- current=.idle edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.beginRecv
  { lease := .held, phase := .recv },
  -- current=.idle edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.idle edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.poisoned edge=.beginOffer
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.resumeOffer
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.publishRouteBranch
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.finishOffer
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.parkOffer
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.parkRouteBranch
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.beginSend
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.beginBranchSend
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.finishSend
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.finishBranchSend
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.parkBranchSend
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.beginRecv
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.beginBranchRecv
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.finishRecv
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.finishBranchRecv
  { lease := .faulted, phase := .poisoned },
  -- current=.poisoned edge=.parkBranchRecv
  { lease := .faulted, phase := .poisoned },
  -- current=.send edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.finishSend
  { lease := .held, phase := .idle },
  -- current=.send edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.send edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.finishRecv
  { lease := .held, phase := .idle },
  -- current=.recv edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.recv edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.publishRouteBranch
  { lease := .held, phase := .routeBranch },
  -- current=.offer edge=.finishOffer
  { lease := .held, phase := .idle },
  -- current=.offer edge=.parkOffer
  { lease := .held, phase := .restoredRouteBranch },
  -- current=.offer edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.offer edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.parkRouteBranch
  { lease := .held, phase := .restoredRouteBranch },
  -- current=.routeBranch edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.beginBranchSend
  { lease := .held, phase := .branchSend },
  -- current=.routeBranch edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.beginBranchRecv
  { lease := .held, phase := .branchRecv },
  -- current=.routeBranch edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.routeBranch edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.resumeOffer
  { lease := .held, phase := .offer },
  -- current=.restoredRouteBranch edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.restoredRouteBranch edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.finishBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.parkBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchRecv edge=.finishBranchRecv
  { lease := .held, phase := .idle },
  -- current=.branchRecv edge=.parkBranchRecv
  { lease := .held, phase := .restoredRouteBranch },
  -- current=.branchSend edge=.beginOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.resumeOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.publishRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.finishOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.parkOffer
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.parkRouteBranch
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.beginSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.beginBranchSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.finishSend
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.finishBranchSend
  { lease := .held, phase := .idle },
  -- current=.branchSend edge=.parkBranchSend
  { lease := .held, phase := .restoredRouteBranch },
  -- current=.branchSend edge=.beginRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.beginBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.finishRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.finishBranchRecv
  { lease := .rejected, phase := .poisoned },
  -- current=.branchSend edge=.parkBranchRecv
  { lease := .rejected, phase := .poisoned }
]

set_option maxRecDepth 4096 in
theorem generatedPublicOperationTableAccepted :
  Hibana.checkPublicOperationTable generatedPublicOperationTable = true := by
  decide

theorem generatedPublicOperationTableExact :
  Hibana.PublicOperationTableExact generatedPublicOperationTable :=
  Hibana.public_operation_table_certificate_sound
    generatedPublicOperationTableAccepted

#eval IO.println "hibana Lean public-operation kernel proof passed states=9 edges=16 transitions=144"
