import Hibana.IterationErasure
open Hibana
theorem causal_case_000 :
  (((.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_001 :
  (((.seq (.send 0 1 0 0) (.seq (.route (.dynamic 7) (.send 1 2 0 0) (.send 3 4 0 0)) (.send 2 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 1 0 0) (.seq (.route (.dynamic 7) (.send 1 2 0 0) (.send 3 4 0 0)) (.send 2 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_002 :
  (((.seq (.send 0 1 0 0) (.seq (.par (.send 1 2 0 0) (.send 2 3 0 0)) (.send 3 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 1 0 0) (.seq (.par (.send 1 2 0 0) (.send 2 3 0 0)) (.send 3 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_003 :
  (((.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 1 2 0 0)) (.send 2 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 1 2 0 0)) (.send 2 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_004 :
  (((.roll (.seq (.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0))) (.send 1 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0))) (.send 1 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_005 :
  (((.roll (.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 0 1 0 0) (.seq (.route .intrinsic (.send 1 2 0 0) (.send 1 2 0 0)) (.send 2 1 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_006 :
  (((.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_007 :
  (((.seq (.send 0 2 0 0) (.seq (.route (.dynamic 7) (.send 2 1 0 0) (.send 3 4 0 0)) (.send 1 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 2 0 0) (.seq (.route (.dynamic 7) (.send 2 1 0 0) (.send 3 4 0 0)) (.send 1 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_008 :
  (((.seq (.send 0 2 0 0) (.seq (.par (.send 2 1 0 0) (.send 1 3 0 0)) (.send 3 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 2 0 0) (.seq (.par (.send 2 1 0 0) (.send 1 3 0 0)) (.send 3 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_009 :
  (((.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 2 1 0 0)) (.send 1 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 2 1 0 0)) (.send 1 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_010 :
  (((.roll (.seq (.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0))) (.send 2 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0))) (.send 2 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_011 :
  (((.roll (.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 0 2 0 0) (.seq (.route .intrinsic (.send 2 1 0 0) (.send 2 1 0 0)) (.send 1 2 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_012 :
  (((.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_013 :
  (((.seq (.send 1 0 0 0) (.seq (.route (.dynamic 7) (.send 0 2 0 0) (.send 3 4 0 0)) (.send 2 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 0 0 0) (.seq (.route (.dynamic 7) (.send 0 2 0 0) (.send 3 4 0 0)) (.send 2 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_014 :
  (((.seq (.send 1 0 0 0) (.seq (.par (.send 0 2 0 0) (.send 2 3 0 0)) (.send 3 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 0 0 0) (.seq (.par (.send 0 2 0 0) (.send 2 3 0 0)) (.send 3 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_015 :
  (((.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 0 2 0 0)) (.send 2 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 0 2 0 0)) (.send 2 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_016 :
  (((.roll (.seq (.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0))) (.send 0 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0))) (.send 0 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_017 :
  (((.roll (.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 1 0 0 0) (.seq (.route .intrinsic (.send 0 2 0 0) (.send 0 2 0 0)) (.send 2 0 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_018 :
  (((.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_019 :
  (((.seq (.send 1 2 0 0) (.seq (.route (.dynamic 7) (.send 2 0 0 0) (.send 3 4 0 0)) (.send 0 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 2 0 0) (.seq (.route (.dynamic 7) (.send 2 0 0 0) (.send 3 4 0 0)) (.send 0 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_020 :
  (((.seq (.send 1 2 0 0) (.seq (.par (.send 2 0 0 0) (.send 0 3 0 0)) (.send 3 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 2 0 0) (.seq (.par (.send 2 0 0 0) (.send 0 3 0 0)) (.send 3 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_021 :
  (((.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 2 0 0 0)) (.send 0 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 2 0 0 0)) (.send 0 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_022 :
  (((.roll (.seq (.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0))) (.send 2 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0))) (.send 2 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_023 :
  (((.roll (.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 1 2 0 0) (.seq (.route .intrinsic (.send 2 0 0 0) (.send 2 0 0 0)) (.send 0 2 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_024 :
  (((.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_025 :
  (((.seq (.send 2 0 0 0) (.seq (.route (.dynamic 7) (.send 0 1 0 0) (.send 3 4 0 0)) (.send 1 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 0 0 0) (.seq (.route (.dynamic 7) (.send 0 1 0 0) (.send 3 4 0 0)) (.send 1 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_026 :
  (((.seq (.send 2 0 0 0) (.seq (.par (.send 0 1 0 0) (.send 1 3 0 0)) (.send 3 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 0 0 0) (.seq (.par (.send 0 1 0 0) (.send 1 3 0 0)) (.send 3 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_027 :
  (((.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 0 1 0 0)) (.send 1 0 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 0 1 0 0)) (.send 1 0 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_028 :
  (((.roll (.seq (.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0))) (.send 0 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0))) (.send 0 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_029 :
  (((.roll (.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 2 0 0 0) (.seq (.route .intrinsic (.send 0 1 0 0) (.send 0 1 0 0)) (.send 1 0 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_030 :
  (((.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_031 :
  (((.seq (.send 2 1 0 0) (.seq (.route (.dynamic 7) (.send 1 0 0 0) (.send 3 4 0 0)) (.send 0 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 1 0 0) (.seq (.route (.dynamic 7) (.send 1 0 0 0) (.send 3 4 0 0)) (.send 0 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_032 :
  (((.seq (.send 2 1 0 0) (.seq (.par (.send 1 0 0 0) (.send 0 3 0 0)) (.send 3 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 1 0 0) (.seq (.par (.send 1 0 0 0) (.send 0 3 0 0)) (.send 3 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
theorem causal_case_033 :
  (((.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 1 0 0 0)) (.send 0 1 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 1 0 0 0)) (.send 0 1 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_034 :
  (((.roll (.seq (.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0))) (.send 1 2 0 0))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0))) (.send 1 2 0 0))) : Choreo).checkRollReceiveLaneCausality 5) = true := by decide
theorem causal_case_035 :
  (((.roll (.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0)))) : Choreo).checkReceiveLaneCausality 5 &&
    ((.roll (.seq (.send 2 1 0 0) (.seq (.route .intrinsic (.send 1 0 0 0) (.send 1 0 0 0)) (.send 0 1 0 0)))) : Choreo).checkRollReceiveLaneCausality 5) = false := by decide
