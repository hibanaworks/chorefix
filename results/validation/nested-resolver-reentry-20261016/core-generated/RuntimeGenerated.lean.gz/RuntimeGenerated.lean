import Hibana.MainTheorems

def generatedSlabLayout : Hibana.SlabLayoutCertificate := {
  base := 6105728292,
  capacity := 7788,
  imageFrontier := 148,
  workspaceBytes := 32,
  endpointFloor := 7660,
  regions := [
    { kind := .resident, offset := 4, bytes := 40, align := 8 },
    { kind := .resident, offset := 44, bytes := 22, align := 4 },
    { kind := .resident, offset := 68, bytes := 80, align := 8 },
    { kind := .endpoint, offset := 7660, bytes := 128, align := 16 }
  ]
}

theorem generatedSlabLayoutAccepted : generatedSlabLayout.check = true := by
  decide

theorem generatedSlabLayoutWellFormed : generatedSlabLayout.WellFormed :=
  Hibana.slab_layout_certificate_sound generatedSlabLayoutAccepted


def generatedPoisonTail : List Hibana.SessionGenerationAction := [
  .poison .decodeFailed,
  .releaseRemaining,
  .releaseLast
]

theorem generatedPoisonTailAccepted :
    Hibana.checkSessionGenerationTrace (.poisoned .transportClosed)
      generatedPoisonTail = true := by
  decide

theorem generatedPoisonTailRetires :
    Hibana.runSessionGenerationTrace (.poisoned .transportClosed)
      generatedPoisonTail = some .retired := by
  decide

theorem generatedPoisonTailTrace :
    Hibana.SessionGenerationTrace (.poisoned .transportClosed)
      generatedPoisonTail .retired :=
  Hibana.session_generation_run_sound generatedPoisonTailRetires

theorem generatedPoisonedAttachRejected :
    Hibana.applySessionGenerationAction (.poisoned .transportClosed) .attach = none :=
  Hibana.poisoned_generation_attach_rejected .transportClosed

theorem generatedNextLeaseGenerationMaximumAccepted :
    Hibana.nextLeaseGeneration? 4294967294 = some 4294967295 := by
  decide

theorem generatedMaximumLeaseGenerationExhausted :
    Hibana.nextLeaseGeneration? 4294967295 = none :=
  Hibana.max_lease_generation_is_exhausted

def generatedInitialFailureBefore : Hibana.LeaseAllocatorSnapshot := {
  generation := 0,
  tableBytes := 0,
  assocBytes := 0,
  resolverBytes := 0,
  imageFrontier := 0,
  workspaceBytes := 0,
  endpointFloor := 3692,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [

  ]
}

def generatedInitialFailureAfter : Hibana.LeaseAllocatorSnapshot := {
  generation := 0,
  tableBytes := 0,
  assocBytes := 0,
  resolverBytes := 0,
  imageFrontier := 0,
  workspaceBytes := 0,
  endpointFloor := 3692,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [

  ]
}

def generatedInitialAllocationFailure : Hibana.LeaseAllocationFailureCertificate := {
  before := generatedInitialFailureBefore,
  after := generatedInitialFailureAfter
}

def generatedGrowthFailureBefore : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 8,
  resolverBytes := 40,
  imageFrontier := 92,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 1 }
  ]
}

def generatedGrowthFailureAfter : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 8,
  resolverBytes := 40,
  imageFrontier := 92,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 1 }
  ]
}

def generatedGrowthAllocationFailure : Hibana.LeaseAllocationFailureCertificate := {
  before := generatedGrowthFailureBefore,
  after := generatedGrowthFailureAfter
}

def generatedAbortFailureBefore : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 0,
  resolverBytes := 0,
  imageFrontier := 44,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 2 }
  ]
}

def generatedAbortFailureAfter : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 0,
  resolverBytes := 0,
  imageFrontier := 44,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 0,
  associationWitnesses := [

  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 2 }
  ]
}

def generatedAbortedAllocation : Hibana.LeaseAllocationFailureCertificate := {
  before := generatedAbortFailureBefore,
  after := generatedAbortFailureAfter
}

def generatedCompactingAbortBefore : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 8,
  resolverBytes := 40,
  imageFrontier := 92,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 1,
  associationWitnesses := [
    { session := 1, lane := 0, attached := true }
  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 2 }
  ]
}

def generatedCompactingAbortAfter : Hibana.LeaseAllocatorSnapshot := {
  generation := 1,
  tableBytes := 40,
  assocBytes := 8,
  resolverBytes := 40,
  imageFrontier := 92,
  workspaceBytes := 0,
  endpointFloor := 3628,
  activeLaneAttachments := 1,
  associationWitnesses := [
    { session := 1, lane := 0, attached := true }
  ],
  slots := [
    { generation := 1, session := 1, role := 0, offset := 3628, bytes := 64, state := 2 }
  ]
}

def generatedCompactingAbort : Hibana.LeaseAllocationAbortCertificate := {
  before := generatedCompactingAbortBefore,
  after := generatedCompactingAbortAfter
}

theorem generatedInitialAllocationFailureAccepted :
  generatedInitialAllocationFailure.check = true := by decide

theorem generatedInitialAllocationFailurePreservesState :
  generatedInitialAllocationFailure.PreservesState :=
  Hibana.lease_allocation_failure_certificate_sound
    generatedInitialAllocationFailureAccepted

theorem generatedGrowthAllocationFailureAccepted :
  generatedGrowthAllocationFailure.check = true := by decide

theorem generatedGrowthAllocationFailurePreservesState :
  generatedGrowthAllocationFailure.PreservesState :=
  Hibana.lease_allocation_failure_certificate_sound
    generatedGrowthAllocationFailureAccepted

theorem generatedAbortedAllocationAccepted :
  generatedAbortedAllocation.check = true := by decide

theorem generatedAbortedAllocationPreservesState :
  generatedAbortedAllocation.PreservesState :=
  Hibana.lease_allocation_failure_certificate_sound
    generatedAbortedAllocationAccepted

theorem generatedCompactingAbortAccepted :
  generatedCompactingAbort.check = true := by decide

theorem generatedCompactingAbortPreservesAuthorityAndCapacity :
  generatedCompactingAbort.PreservesAuthorityAndCapacity :=
  Hibana.lease_allocation_abort_certificate_sound
    generatedCompactingAbortAccepted

#eval IO.println "hibana Lean runtime proof passed regions=4 poison=1 generation=1 atomic-failures=4"
