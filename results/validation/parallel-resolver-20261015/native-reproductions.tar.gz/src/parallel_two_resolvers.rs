#[path="/Users/ovm/Code/hibanaworks/hibana-tracefix/src/imp/transport.rs"]
mod transport;
use hibana::{g, runtime::{SessionKitStorage, ids::SessionId,program::project,resolver::{DecisionArm,ResolverRef}}};
type RequestA=g::Msg<1,()>;
type MaterializeA=g::Msg<2,()>;
type DoneA=g::Msg<3,()>;
type RejectA=g::Msg<4,()>;
type RequestB=g::Msg<11,()>;
type MaterializeB=g::Msg<12,()>;
type DoneB=g::Msg<13,()>;
type RejectB=g::Msg<14,()>;
#[tokio::main(flavor="current_thread")]
async fn main() {
 let a=g::route(g::seq(g::send::<1,0,RequestA>(),g::route(g::seq(g::send::<0,0,MaterializeA>(),g::send::<0,1,DoneA>()),g::send::<0,1,RejectA>()).resolve::<1>()),g::seq(g::send::<1,0,g::Msg<21,()>>(),g::send::<0,1,g::Msg<22,()>>())).roll();
 let b=g::route(g::seq(g::send::<2,0,RequestB>(),g::route(g::seq(g::send::<0,0,MaterializeB>(),g::send::<0,2,DoneB>()),g::send::<0,2,RejectB>()).resolve::<2>()),g::seq(g::send::<2,0,g::Msg<23,()>>(),g::send::<0,2,g::Msg<24,()>>())).roll();
 let global=g::par(a,b);
 let p0=project::<0>(&global);let p1=project::<1>(&global);let p2=project::<2>(&global);
 let mut slab=vec![0;1024*1024];let mut storage=SessionKitStorage::uninit();let kit=storage.init();let carrier=transport::InMemoryTransport::new();let rv=kit.rendezvous(&mut slab,carrier).unwrap();
 rv.set_resolver(&p0,ResolverRef::<1>::decision_state(&(),|_|Ok(DecisionArm::Left))).unwrap();
 rv.set_resolver(&p0,ResolverRef::<2>::decision_state(&(),|_|Ok(DecisionArm::Left))).unwrap();
 let mut repo=rv.enter(SessionId::new(1),&p0).unwrap();let mut a=rv.enter(SessionId::new(1),&p1).unwrap();let mut b=rv.enter(SessionId::new(1),&p2).unwrap();
 a.send::<RequestA>(&()).await.unwrap();b.send::<RequestB>(&()).await.unwrap();
 tokio::join!(async {
  for _ in 0..4 {
   let branch=repo.offer().await.unwrap();eprintln!("repo branch {}",branch.label());
   match branch.label() {
    1=>branch.recv::<RequestA>().await.unwrap(),
    11=>branch.recv::<RequestB>().await.unwrap(),
    2=>{branch.recv::<MaterializeA>().await.unwrap();repo.send::<DoneA>(&()).await.unwrap();},
    12=>{branch.recv::<MaterializeB>().await.unwrap();repo.send::<DoneB>(&()).await.unwrap();},
    label=>panic!("unexpected {label}")
   }
  }
 },async {a.recv::<DoneA>().await.unwrap();b.recv::<DoneB>().await.unwrap();});
}
